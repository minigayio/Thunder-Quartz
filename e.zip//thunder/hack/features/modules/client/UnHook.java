package thunder.hack.features.modules.client;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_155;
import net.minecraft.class_437;
import net.minecraft.class_8518;
import thunder.hack.core.Managers;
import thunder.hack.core.manager.client.ConfigManager;
import thunder.hack.features.modules.Module;
import thunder.hack.utility.math.MathUtility;

public class UnHook extends Module {
   List<Module> list;
   public int code = 0;
   private final String[] logStrinqsToRemove = new String[]{"- thunderhack 4", "thunderhack", "thunderhack:blur", "[ThunderHack dsc.gg/exploitcore]"};

   public UnHook() {
      super("UnHook", Module.Category.CLIENT);
   }

   public void onEnable() {
      this.code = (int)MathUtility.random(10.0F, 99.0F);

      for(int i = 0; i < 20; ++i) {
         this.sendMessage(ClientSettings.isRu() ? String.valueOf(class_124.field_1061) + "Ща все свернется, напиши в чат " + String.valueOf(class_124.field_1068) + this.code + String.valueOf(class_124.field_1061) + " чтобы все вернуть!" : String.valueOf(class_124.field_1061) + "It's all close now, write to the chat " + String.valueOf(class_124.field_1068) + this.code + String.valueOf(class_124.field_1061) + " to return everything!");
      }

      this.list = Managers.MODULE.getEnabledModules();
      mc.method_1507((class_437)null);
      Managers.ASYNC.run(() -> {
         mc.method_40000(() -> {
            Iterator var1 = this.list.iterator();

            while(var1.hasNext()) {
               Module module = (Module)var1.next();
               if (!module.equals(this)) {
                  module.disable();
               }
            }

            ClientSettings.customMainMenu.setValue(false);

            try {
               mc.method_22683().method_4491(mc.method_45573(), class_155.method_16673().method_48022() ? class_8518.field_44650 : class_8518.field_44651);
            } catch (Exception var4) {
            }

            mc.field_1705.method_1743().method_1808(true);
            this.setEnabled(true);
            this.cleanLogs();

            try {
               ConfigManager.MAIN_FOLDER.renameTo(new File("XaeroWaypoints_BACKUP092738"));
            } catch (Exception var3) {
            }

         });
      }, 5000L);
   }

   private void cleanLogs() {
      try {
         File logsFolder = new File("logs");
         if (!logsFolder.exists() || !logsFolder.isDirectory()) {
            return;
         }

         File[] logFiles = logsFolder.listFiles((dir, name) -> {
            return name.endsWith(".log") || name.endsWith(".log.gz");
         });
         if (logFiles == null) {
            return;
         }

         File[] var3 = logFiles;
         int var4 = logFiles.length;

         for(int var5 = 0; var5 < var4; ++var5) {
            File logFile = var3[var5];
            if (!logFile.getName().endsWith(".gz")) {
               try {
                  List<String> lines = Files.readAllLines(logFile.toPath(), StandardCharsets.UTF_8);
                  List<String> cleanedLines = new ArrayList();
                  boolean needsCleaning = false;
                  Iterator var10 = lines.iterator();

                  while(var10.hasNext()) {
                     String line = (String)var10.next();
                     boolean shouldRemove = false;
                     String[] var13 = this.logStrinqsToRemove;
                     int var14 = var13.length;

                     for(int var15 = 0; var15 < var14; ++var15) {
                        String removeString = var13[var15];
                        if (line.toLowerCase().contains(removeString.toLowerCase())) {
                           shouldRemove = true;
                           needsCleaning = true;
                           break;
                        }
                     }

                     if (!shouldRemove) {
                        cleanedLines.add(line);
                     }
                  }

                  if (needsCleaning) {
                     Files.write(logFile.toPath(), cleanedLines, StandardCharsets.UTF_8);
                  }
               } catch (Exception var17) {
               }
            }
         }
      } catch (Exception var18) {
      }

   }

   public void onDisable() {
      if (this.list != null) {
         Iterator var1 = this.list.iterator();

         while(var1.hasNext()) {
            Module module = (Module)var1.next();
            if (!module.equals(this)) {
               module.enable();
            }
         }

         ClientSettings.customMainMenu.setValue(true);

         try {
            (new File("XaeroWaypoints_BACKUP092739")).renameTo(new File("ThunderHackRecode"));
         } catch (Exception var3) {
         }

      }
   }
}
