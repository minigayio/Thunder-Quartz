package thunder.hack.features.modules.misc;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1802;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import thunder.hack.features.modules.Module;

public class RadyNotification extends Module {
   public RadyNotification() {
      super("RedyNotification", Module.Category.MISC);
   }

   @EventHandler
   public void onRender2D(class_332 context) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         if (mc.field_1724.method_6047().method_7909() == class_1802.field_8547) {
            int maxCharge = 15;
            int useTime = mc.field_1724.method_6048();
            float charge = mc.field_1724.method_6115() ? (float)useTime / (float)maxCharge : 0.0F;
            int level = class_3532.method_15340((int)(charge * 3.0F), 0, 4);
            boolean isReady = level >= 4;
            String message = isReady ? String.format("Trident ready [Max]") : String.format("Trident [%d/3]", level);
            int color = isReady ? -16711936 : -256;
            this.renderMessage(context, message, color);
         }

      }
   }

   private void renderMessage(class_332 context, String message, int color) {
      class_4587 matrices = context.method_51448();
      matrices.method_22903();
      int screenWidth = mc.method_22683().method_4486();
      int screenHeight = mc.method_22683().method_4502();
      float x = (float)screenWidth / 2.0F - (float)mc.field_1772.method_1727(message) / 2.0F;
      float y = (float)screenHeight / 2.0F - 20.0F;
      context.method_51433(mc.field_1772, message, (int)x, (int)y, color, true);
      matrices.method_22909();
   }
}
