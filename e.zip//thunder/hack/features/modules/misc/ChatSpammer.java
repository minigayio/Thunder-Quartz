package thunder.hack.features.modules.misc;

import java.util.Random;
import thunder.hack.features.modules.Module;
import thunder.hack.setting.Setting;

public class ChatSpammer extends Module {
   private final Setting<Integer> spamDaily = new Setting("SpamDaily", 10, 0, 60);
   private final Setting<Boolean> antiDetected = new Setting("Anti-Detected", true);
   private final Setting<String> spamText = new Setting("Text", "free komar + bypas --> dsc.gg/exploitcore");
   private long lastSpamTime = 0L;

   public ChatSpammer() {
      super("ChatSpammer", Module.Category.MISC);
   }

   public void onUpdate() {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         long currentTime = System.currentTimeMillis();
         if (currentTime - this.lastSpamTime >= (long)(Integer)this.spamDaily.getValue() * 1000L) {
            String message = (String)this.spamText.getValue();
            String processedMessage = this.processMessage(message);
            if ((Boolean)this.antiDetected.getValue()) {
               processedMessage = processedMessage + " [" + this.getRandomString(8) + "]";
            }

            mc.field_1724.field_3944.method_45729(processedMessage);
            this.lastSpamTime = currentTime;
         }

      }
   }

   private String processMessage(String input) {
      StringBuilder processed = new StringBuilder();
      char[] var3 = input.toCharArray();
      int var4 = var3.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         char c = var3[var5];
         processed.append(c);
         if (c == ' ') {
            processed.append(' ');
         }
      }

      return processed.toString();
   }

   private String getRandomString(int length) {
      String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
      StringBuilder randomString = new StringBuilder();
      Random random = new Random();

      for(int i = 0; i < length; ++i) {
         randomString.append(characters.charAt(random.nextInt(characters.length())));
      }

      return randomString.toString();
   }
}
