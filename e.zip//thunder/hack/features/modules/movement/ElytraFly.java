package thunder.hack.features.modules.movement;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1713;
import net.minecraft.class_1802;
import net.minecraft.class_2815;
import net.minecraft.class_2879;
import net.minecraft.class_2886;
import thunder.hack.core.Managers;
import thunder.hack.features.modules.Module;
import thunder.hack.gui.notification.Notification;
import thunder.hack.setting.Setting;
import thunder.hack.utility.player.InventoryUtility;
import thunder.hack.utility.player.SearchInvResult;

public class ElytraFly extends Module {
   private final Setting<Float> speed = new Setting("Speed", 1.0F, 0.1F, 5.0F);
   private final Setting<ElytraFly.Mode> bypassMode;
   private final Setting<Boolean> useFireworks;

   public ElytraFly() {
      super("ElytraFly", Module.Category.MOVEMENT);
      this.bypassMode = new Setting("Bypass", ElytraFly.Mode.None);
      this.useFireworks = new Setting("UseFireworks", true);
   }

   @EventHandler
   public void onTick() {
      if (mc.field_1724 != null && mc.field_1724.method_6128()) {
         this.handleMovement();
         if ((Boolean)this.useFireworks.getValue()) {
            this.useFireworkBasedOnSpeed();
         }

      }
   }

   private void handleMovement() {
      double forward = (double)mc.field_1724.field_3913.field_3905;
      double strafe = (double)mc.field_1724.field_3913.field_3907;
      float yaw = mc.field_1724.method_36454();
      double radians = Math.toRadians((double)yaw);
      double sinYaw = Math.sin(radians);
      double cosYaw = Math.cos(radians);
      double xSpeed = forward * cosYaw - strafe * sinYaw;
      double zSpeed = forward * sinYaw + strafe * cosYaw;
      mc.field_1724.method_18800(xSpeed * (double)(Float)this.speed.getValue(), mc.field_1724.method_18798().field_1351, zSpeed * (double)(Float)this.speed.getValue());
   }

   private void useFireworkBasedOnSpeed() {
      if (mc.field_1724.field_6012 % Math.max(1, (int)(20.0F / (Float)this.speed.getValue())) == 0) {
         this.useFirework();
      }

   }

   private void useFirework() {
      SearchInvResult hotbarFirework = InventoryUtility.findItemInHotBar(class_1802.field_8639);
      SearchInvResult inventoryFirework = InventoryUtility.findItemInInventory(class_1802.field_8639);
      InventoryUtility.saveSlot();
      if (hotbarFirework.found()) {
         hotbarFirework.switchTo();
      } else {
         if (!inventoryFirework.found()) {
            Managers.NOTIFICATION.publicity("ElytraFLY", "No fireworks found!", 1, Notification.Type.ERROR);
            return;
         }

         mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, inventoryFirework.slot(), mc.field_1724.method_31548().field_7545, class_1713.field_7791, mc.field_1724);
         this.sendPacket(new class_2815(mc.field_1724.field_7512.field_7763));
      }

      this.sendSequencedPacket((id) -> {
         return new class_2886(class_1268.field_5808, id, mc.field_1724.method_36454(), mc.field_1724.method_36455());
      });
      this.sendPacket(new class_2879(class_1268.field_5808));
   }

   private static enum Mode {
      None,
      Grim;

      // $FF: synthetic method
      private static ElytraFly.Mode[] $values() {
         return new ElytraFly.Mode[]{None, Grim};
      }
   }
}
