package thunder.hack.events.impl;

import thunder.hack.events.Event;

public class EventHandleBlockBreaking extends Event {
}
