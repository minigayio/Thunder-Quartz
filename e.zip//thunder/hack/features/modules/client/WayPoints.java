package thunder.hack.features.modules.client;

import java.util.Iterator;
import net.minecraft.class_243;
import net.minecraft.class_332;
import thunder.hack.core.Managers;
import thunder.hack.core.manager.world.WayPointManager;
import thunder.hack.features.modules.Module;
import thunder.hack.gui.font.FontRenderers;
import thunder.hack.utility.render.Render3DEngine;
import thunder.hack.utility.render.TextureStorage;

public final class WayPoints extends Module {
   public WayPoints() {
      super("WayPoints", Module.Category.CLIENT);
   }

   public void onEnable() {
      this.sendMessage(Managers.COMMAND.getPrefix() + "waypoint add x y z name");
   }

   public void onRender2D(class_332 context) {
      if (!Managers.WAYPOINT.getWayPoints().isEmpty() && !fullNullCheck()) {
         Iterator var2 = Managers.WAYPOINT.getWayPoints().iterator();

         while(true) {
            WayPointManager.WayPoint wp;
            do {
               do {
                  do {
                     if (!var2.hasNext()) {
                        return;
                     }

                     wp = (WayPointManager.WayPoint)var2.next();
                  } while(wp.getName() == null);
               } while(mc.method_1542() && wp.getServer().equals("SinglePlayer"));
            } while(mc.method_1562().method_45734() != null && !mc.method_1562().method_45734().field_3761.contains(wp.getServer()));

            if (mc.field_1687.method_27983().method_29177().method_12832().equals(wp.getDimension())) {
               class_243 vector = new class_243((double)wp.getX(), (double)wp.getY(), (double)wp.getZ());
               class_243 screenPos = Render3DEngine.worldSpaceToScreenSpace(vector);
               if (screenPos != null && !(screenPos.field_1350 < 0.0D) && !(screenPos.field_1350 >= 1.0D)) {
                  double posX = screenPos.field_1352;
                  double posY = screenPos.field_1351;
                  int var10000 = wp.getX();
                  String coords = var10000 + " " + wp.getZ();
                  Object[] var10001 = new Object[]{Math.sqrt(mc.field_1724.method_5649((double)wp.getX(), (double)wp.getY(), (double)wp.getZ()))};
                  String distance = String.format("%.0f", var10001) + "m";
                  float diff = FontRenderers.sf_bold_mini.getStringWidth(wp.getName()) / 2.0F;
                  float tagX = (float)(posX - (double)diff);
                  float tagX2 = (float)(posX - (double)(FontRenderers.sf_bold_mini.getStringWidth(coords) / 2.0F));
                  float tagX3 = (float)(posX - (double)(FontRenderers.sf_bold_mini.getStringWidth(distance) / 2.0F));
                  context.method_51448().method_22903();
                  context.method_51448().method_22904(posX - 10.0D, posY - 35.0D, 0.0D);
                  context.method_25293(TextureStorage.waypoint, 0, 0, 20, 20, 0.0F, 0.0F, 20, 20, 20, 20);
                  context.method_51448().method_22909();
                  FontRenderers.sf_bold_mini.drawString(context.method_51448(), wp.getName(), (double)tagX, (double)((float)posY - 10.0F), -1);
                  FontRenderers.sf_bold_mini.drawString(context.method_51448(), coords, (double)tagX2, (double)((float)posY - 2.0F), -1);
                  FontRenderers.sf_bold_mini.drawString(context.method_51448(), distance, (double)tagX3, (double)((float)posY + 6.0F), -1);
               }
            }
         }
      }
   }
}
