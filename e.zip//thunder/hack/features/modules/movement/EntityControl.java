package thunder.hack.features.modules.movement;

import thunder.hack.features.modules.Module;

public class EntityControl extends Module {
   public EntityControl() {
      super("EntityControl", Module.Category.MOVEMENT);
   }
}
