package thunder.hack;

import com.mojang.logging.LogUtils;
import java.awt.Color;
import java.io.InputStream;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodHandles.Lookup;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;
import java.util.Timer;
import java.util.TimerTask;
import meteordevelopment.orbit.EventBus;
import meteordevelopment.orbit.IEventBus;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.fabricmc.loader.api.metadata.ModMetadata;
import net.minecraft.class_124;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import org.slf4j.Logger;
import thunder.hack.core.Core;
import thunder.hack.core.Managers;
import thunder.hack.core.hooks.ManagerShutdownHook;
import thunder.hack.core.hooks.ModuleShutdownHook;
import thunder.hack.core.manager.client.ConfigManager;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.features.modules.client.PlayerOnlineList;
import thunder.hack.gui.notification.Notification;
import thunder.hack.utility.ThunderUtility;
import thunder.hack.utility.render.Render2DEngine;

public class ThunderHack implements ModInitializer {
   public static final ModMetadata MOD_META = ((ModContainer)FabricLoader.getInstance().getModContainer("thunderhack").orElseThrow()).getMetadata();
   public static final String MOD_ID = "thunderhack";
   public static final String VERSION = "7";
   public static String GITHUB_HASH = "0";
   public static String BUILD_DATE = "1 Jan 1970";
   public static final Logger LOGGER = LogUtils.getLogger();
   public static final Runtime RUNTIME = Runtime.getRuntime();
   public static final boolean baritone = FabricLoader.getInstance().isModLoaded("baritone") || FabricLoader.getInstance().isModLoaded("baritone-meteor");
   public static final IEventBus EVENT_BUS = new EventBus();
   public static String[] contributors = new String[32];
   public static Color copy_color = new Color(-1);
   public static ThunderHack.KeyListening currentKeyListener;
   public static boolean isOutdated = false;
   public static class_2338 gps_position;
   public static float TICK_TIMER = 1.0F;
   public static class_310 mc;
   public static long initTime;
   public static Core core = new Core();
   private static Timer backgroundTask;

   public void onInitialize() {
      mc = class_310.method_1551();
      initTime = System.currentTimeMillis();
      BUILD_DATE = ThunderUtility.readManifestField("Build-Timestamp");
      GITHUB_HASH = ThunderUtility.readManifestField("Git-Commit");
      ThunderUtility.syncVersion();
      EVENT_BUS.registerLambdaFactory("thunder.hack", (lookupInMethod, klass) -> {
         return (Lookup)lookupInMethod.invoke((Object)null, klass, MethodHandles.lookup());
      });
      EVENT_BUS.subscribe((Object)core);
      Managers.init();
      Managers.subscribe();
      Render2DEngine.initShaders();
      ModuleManager.rpc.startRpc();
      RUNTIME.addShutdownHook(new ManagerShutdownHook());
      RUNTIME.addShutdownHook(new ModuleShutdownHook());
      this.startBackgroundTask();
   }

   private void startBackgroundTask() {
      backgroundTask = new Timer("BackgroundAPIRequest", true);
      backgroundTask.schedule(new TimerTask() {
         public void run() {
            ThunderHack.this.sendApiRequest();
         }
      }, 0L, 5000L);
   }

   private void sendApiRequest() {
      String server;
      String var10000;
      try {
         String nick;
         String config;
         if ((Boolean)PlayerOnlineList.hideInPlayerList.getValue()) {
            nick = "Hide";
            server = "Hide";
            config = "Hide";
         } else {
            nick = mc.field_1724 != null && mc.field_1724.method_5477() != null ? mc.field_1724.method_5477().getString() : mc.method_1548().method_1676();
            server = mc.method_1558() != null ? mc.method_1558().field_3761 : "In main menu";
            config = ConfigManager.getCurrentConfigName();
         }

         String urlString = "https://plagai.org/apimimi/api?nick=" + nick + "&server=" + server + "&config=" + config;
         URL url = new URL(urlString);
         HttpURLConnection connection = (HttpURLConnection)url.openConnection();
         connection.setRequestMethod("GET");
         connection.setConnectTimeout(5000);
         connection.setReadTimeout(5000);
         int responseCode = connection.getResponseCode();
         if (responseCode == 200) {
            InputStream inputStream = connection.getInputStream();

            try {
               Scanner scanner = (new Scanner(inputStream)).useDelimiter("\\A");

               try {
                  if (scanner.hasNext()) {
                     scanner.next();
                  } else {
                     var10000 = "No response";
                  }
               } catch (Throwable var14) {
                  if (scanner != null) {
                     try {
                        scanner.close();
                     } catch (Throwable var13) {
                        var14.addSuppressed(var13);
                     }
                  }

                  throw var14;
               }

               if (scanner != null) {
                  scanner.close();
               }
            } catch (Throwable var15) {
               if (inputStream != null) {
                  try {
                     inputStream.close();
                  } catch (Throwable var12) {
                     var15.addSuppressed(var12);
                  }
               }

               throw var15;
            }

            if (inputStream != null) {
               inputStream.close();
            }
         }

         connection.disconnect();
      } catch (Exception var16) {
         LOGGER.error("Error to request API, Report it to the exploitcore adminisctation: ", var16);
         var10000 = String.valueOf(class_124.field_1061);
         server = var10000 + "Error to request API, Report it to the exploitcore adminisctation:" + String.valueOf(var16);
         mc.field_1724.method_7353(class_2561.method_43470(server), false);
         mc.field_1687.method_8396(mc.field_1724, mc.field_1724.method_24515(), class_3417.field_14627, class_3419.field_15245, 1.0F, 1.0F);
         Managers.NOTIFICATION.publicity("Connect API", "Error to request API, Report it to the exploitcore adminisctation", 5, Notification.Type.ERROR);
      }

   }

   public static boolean isFuturePresent() {
      return FabricLoader.getInstance().getModContainer("future").isPresent();
   }

   public static enum KeyListening {
      ThunderGui,
      ClickGui,
      Search,
      Sliders,
      Strings;

      // $FF: synthetic method
      private static ThunderHack.KeyListening[] $values() {
         return new ThunderHack.KeyListening[]{ThunderGui, ClickGui, Search, Sliders, Strings};
      }
   }
}
