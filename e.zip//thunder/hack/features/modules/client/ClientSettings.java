package thunder.hack.features.modules.client;

import java.awt.Color;
import thunder.hack.features.modules.Module;
import thunder.hack.setting.Setting;
import thunder.hack.setting.impl.ColorSetting;

public final class ClientSettings extends Module {
   public static Setting<Boolean> futureCompatibility = new Setting("FutureCompatibility", false);
   public static Setting<Boolean> customMainMenu = new Setting("CustomMainMenu", true);
   public static Setting<Boolean> customPanorama = new Setting("CustomPanorama", true);
   public static Setting<Boolean> customLoadingScreen = new Setting("CustomLoadingScreen", true);
   public static Setting<Boolean> scaleFactorFix = new Setting("ScaleFactorFix", false);
   public static Setting<Float> scaleFactorFixValue = new Setting("ScaleFactorFixValue", 2.0F, 0.0F, 4.0F);
   public static Setting<Boolean> renderRotations = new Setting("RenderRotations", true);
   public static Setting<Boolean> clientMessages = new Setting("ClientMessages", true);
   public static Setting<Boolean> debug = new Setting("Debug", false);
   public static Setting<Boolean> customBob = new Setting("CustomBob", true);
   public static Setting<Boolean> telemetry = new Setting("Telemetry", true);
   public static Setting<ClientSettings.Language> language;
   public static Setting<String> prefix;
   public static Setting<ClientSettings.ClipCommandMode> clipCommandMode;
   public static Setting<ColorSetting> auraESPColor;

   public ClientSettings() {
      super("ClientSettings", Module.Category.CLIENT);
   }

   public static boolean isRu() {
      return language.is(ClientSettings.Language.RU);
   }

   public boolean isToggleable() {
      return false;
   }

   static {
      language = new Setting("Language", ClientSettings.Language.ENG);
      prefix = new Setting("Prefix", "@");
      clipCommandMode = new Setting("ClipCommandMode", ClientSettings.ClipCommandMode.Matrix);
      auraESPColor = new Setting("AuraESPColor", new ColorSetting(new Color(255, 0, 0, 255)));
   }

   public static enum Language {
      RU,
      ENG;

      // $FF: synthetic method
      private static ClientSettings.Language[] $values() {
         return new ClientSettings.Language[]{RU, ENG};
      }
   }

   public static enum ClipCommandMode {
      Default,
      Matrix;

      // $FF: synthetic method
      private static ClientSettings.ClipCommandMode[] $values() {
         return new ClientSettings.ClipCommandMode[]{Default, Matrix};
      }
   }
}
