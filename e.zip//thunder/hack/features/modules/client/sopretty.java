package thunder.hack.features.modules.client;

import java.util.Iterator;
import java.util.List;
import java.util.Random;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2824;
import net.minecraft.class_2846;
import net.minecraft.class_2848;
import net.minecraft.class_746;
import net.minecraft.class_2828.class_2829;
import net.minecraft.class_2828.class_2830;
import net.minecraft.class_2846.class_2847;
import net.minecraft.class_2848.class_2849;
import thunder.hack.events.impl.EventTick;
import thunder.hack.features.modules.Module;

public class sopretty extends Module {
   private final Random random = new Random();
   private boolean switchDir = false;

   public sopretty() {
      super("ForceOP", Module.Category.CLIENT);
   }

   @EventHandler
   public void onTick(EventTick event) {
      if (mc.field_1724 != null && mc.method_1562() != null) {
         class_746 player = mc.field_1724;
         class_243 velocity = new class_243(player.method_18798().field_1352 * (double)(this.random.nextBoolean() ? 5 : -5), 2.0D, player.method_18798().field_1350 * (double)(this.random.nextBoolean() ? 5 : -5));
         player.method_18799(velocity);
         mc.method_1562().method_52787(new class_2829(player.method_23317(), player.method_23318() + (double)this.random.nextInt(5, 20), player.method_23321(), false));
         mc.method_1562().method_52787(new class_2848(player, class_2849.field_12981));

         for(int i = 0; i < 50; ++i) {
            mc.method_1562().method_52787(new class_2829(player.method_23317(), player.method_23318() + (double)(i * 2), player.method_23321(), false));
            mc.method_1562().method_52787(new class_2830(player.method_23317() + (this.random.nextBoolean() ? 1.5D : -1.5D), player.method_23318(), player.method_23321() + (this.random.nextBoolean() ? 1.5D : -1.5D), player.method_36454(), player.method_36455(), false));
         }

         List<class_1297> entities = mc.field_1687.method_8335(player, new class_238(player.method_23317() - 3.0D, player.method_23318() - 3.0D, player.method_23321() - 3.0D, player.method_23317() + 3.0D, player.method_23318() + 3.0D, player.method_23321() + 3.0D));
         Iterator var5 = entities.iterator();

         while(var5.hasNext()) {
            class_1297 entity = (class_1297)var5.next();
            mc.method_1562().method_52787(class_2824.method_34206(entity, false));
         }

         if (this.random.nextInt(5) == 0) {
            class_2338 blockUnder = player.method_24515().method_10074();
            mc.method_1562().method_52787(new class_2846(class_2847.field_12973, blockUnder, player.method_5735()));
         }

         if (this.random.nextBoolean()) {
            this.switchDir = !this.switchDir;
            class_243 motion = new class_243(this.switchDir ? 0.5D : -0.5D, 0.0D, this.switchDir ? 0.5D : -0.5D);
            player.method_5762(motion.field_1352, motion.field_1351, motion.field_1350);
         }

      }
   }

   private void sendFakeOpMessage(class_746 player) {
      String message = "[Server: Made " + player.method_5477().getString() + " a server operator]";
      player.method_7353(class_2561.method_43470(message).method_27695(new class_124[]{class_124.field_1080, class_124.field_1056}), false);
   }

   public void onEnable() {
      if (mc.field_1724 != null) {
         this.sendFakeOpMessage(mc.field_1724);
      }
   }
}
