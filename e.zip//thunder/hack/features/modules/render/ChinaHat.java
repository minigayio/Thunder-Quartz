package thunder.hack.features.modules.render;

import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import net.minecraft.class_293.class_5596;
import org.joml.Matrix4f;
import thunder.hack.features.modules.Module;
import thunder.hack.setting.Setting;
import thunder.hack.setting.impl.ColorSetting;
import thunder.hack.utility.render.Render2DEngine;
import thunder.hack.utility.render.Render3DEngine;

public class ChinaHat extends Module {
   private final Setting<Float> radius = new Setting("Radius", 0.8F, 0.1F, 2.0F);
   private final Setting<Float> height = new Setting("Height", 0.5F, 0.1F, 1.5F);
   private final Setting<Float> width = new Setting("Width", 1.0F, 0.1F, 3.0F);
   private final Setting<Float> length = new Setting("Length", 1.0F, 0.1F, 3.0F);
   private final Setting<Boolean> firstPerson = new Setting("FirstPerson", false);
   private final Setting<ColorSetting> color1 = new Setting("Color1", new ColorSetting(new Color(255, 0, 0, 150)));
   private final Setting<ColorSetting> color2 = new Setting("Color2", new ColorSetting(new Color(0, 255, 0, 150)));
   private final Setting<Boolean> gradient = new Setting("Gradient", true);
   private static final int SEGMENTS = 128;

   public ChinaHat() {
      super("ChinaHat", Module.Category.RENDER);
   }

   public void onRender3D(class_4587 stack) {
      if (mc.field_1724 != null) {
         if ((Boolean)this.firstPerson.getValue() || !mc.field_1690.method_31044().method_31034()) {
            double x = mc.field_1724.field_6014 + (mc.field_1724.method_23317() - mc.field_1724.field_6014) * (double)Render3DEngine.getTickDelta() - mc.method_1561().field_4686.method_19326().method_10216();
            double y = mc.field_1724.field_6036 + (mc.field_1724.method_23318() - mc.field_1724.field_6036) * (double)Render3DEngine.getTickDelta() - mc.method_1561().field_4686.method_19326().method_10214() + (double)mc.field_1724.method_17682();
            double z = mc.field_1724.field_5969 + (mc.field_1724.method_23321() - mc.field_1724.field_5969) * (double)Render3DEngine.getTickDelta() - mc.method_1561().field_4686.method_19326().method_10215();
            stack.method_22903();
            stack.method_22904(x, y, z);
            Render3DEngine.setupRender();
            RenderSystem.disableCull();
            RenderSystem.disableDepthTest();
            RenderSystem.setShader(class_757::method_34540);
            class_287 bufferBuilder = class_289.method_1348().method_60827(class_5596.field_27381, class_290.field_1576);
            Matrix4f matrix = stack.method_23760().method_23761();
            long time = System.currentTimeMillis();
            Color centerColor;
            if ((Boolean)this.gradient.getValue()) {
               float centerProgress = (float)(Math.sin((double)time * 0.002D) + 1.0D) / 2.0F;
               centerColor = Render2DEngine.interpolateColorHue(((ColorSetting)this.color1.getValue()).getColorObject(), ((ColorSetting)this.color2.getValue()).getColorObject(), centerProgress);
            } else {
               centerColor = ((ColorSetting)this.color1.getValue()).getColorObject();
            }

            bufferBuilder.method_22918(matrix, 0.0F, (Float)this.height.getValue(), 0.0F).method_39415(centerColor.getRGB());

            for(int i = 0; i <= 128; ++i) {
               double angle = (double)i / 128.0D * 3.141592653589793D * 2.0D;
               float cos = (float)Math.cos(angle);
               float sin = (float)Math.sin(angle);
               float x1 = cos * (Float)this.radius.getValue() * (Float)this.width.getValue();
               float z1 = sin * (Float)this.radius.getValue() * (Float)this.length.getValue();
               Color segmentColor;
               if ((Boolean)this.gradient.getValue()) {
                  float baseProgress = (float)i / 128.0F;
                  float fadeWave1 = (float)(Math.sin((double)time * 0.004D + (double)baseProgress * 3.141592653589793D * 2.0D) + 1.0D) / 2.0F;
                  float fadeWave2 = (float)(Math.cos((double)time * 0.003D + (double)baseProgress * 3.141592653589793D * 2.0D) + 1.0D) / 2.0F;
                  float combinedWave = (fadeWave1 + fadeWave2) / 2.0F;
                  segmentColor = Render2DEngine.interpolateColorHue(((ColorSetting)this.color1.getValue()).getColorObject(), ((ColorSetting)this.color2.getValue()).getColorObject(), combinedWave);
               } else {
                  segmentColor = ((ColorSetting)this.color2.getValue()).getColorObject();
               }

               bufferBuilder.method_22918(matrix, x1, 0.0F, z1).method_39415(segmentColor.getRGB());
            }

            Render2DEngine.endBuilding(bufferBuilder);
            RenderSystem.enableCull();
            RenderSystem.enableDepthTest();
            Render3DEngine.endRender();
            stack.method_22909();
         }
      }
   }
}
