package thunder.hack.utility.render.shaders.satin.api.managed.uniform;

public interface Uniform1i {
   void set(int var1);
}
