package thunder.hack.features.modules.render;

import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.Iterator;
import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_4587;
import net.minecraft.class_742;
import net.minecraft.class_757;
import net.minecraft.class_293.class_5596;
import org.joml.Matrix4f;
import thunder.hack.core.Managers;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.client.HudEditor;
import thunder.hack.setting.Setting;
import thunder.hack.setting.impl.BooleanSettingGroup;
import thunder.hack.setting.impl.ColorSetting;
import thunder.hack.utility.render.Render2DEngine;
import thunder.hack.utility.render.Render3DEngine;

public class AuraRageDisplay extends Module {
   private final Setting<Boolean> onlySelf = new Setting("OnlySelf", false);
   private final Setting<ColorSetting> defaultColor;
   private final Setting<ColorSetting> enemyInRangeColor;
   private final Setting<ColorSetting> otherPlayerColor;
   private final Setting<BooleanSettingGroup> glowSettings;
   private final Setting<Integer> glowRadius;
   private final Setting<Float> glowIntensity;
   private final Setting<Integer> circlePoints;
   private final Setting<Float> lineWidth;
   private final Setting<Boolean> hudColorMode;
   private final Setting<Integer> colorOffset;
   private final Setting<Boolean> ignoreJump;

   public AuraRageDisplay() {
      super("AuraRageDisplay", Module.Category.RENDER);
      this.defaultColor = new Setting("DefaultColor", new ColorSetting(Color.MAGENTA));
      this.enemyInRangeColor = new Setting("EnemyInRangeColor", new ColorSetting(Color.RED));
      this.otherPlayerColor = new Setting("OtherPlayerColor", new ColorSetting(Color.YELLOW), (v) -> {
         return !(Boolean)this.onlySelf.getValue();
      });
      this.glowSettings = new Setting("Glow", new BooleanSettingGroup(true));
      this.glowRadius = (new Setting("GlowRadius", 8, 1, 20)).addToGroup(this.glowSettings);
      this.glowIntensity = (new Setting("GlowIntensity", 0.8F, 0.1F, 2.0F)).addToGroup(this.glowSettings);
      this.circlePoints = new Setting("CirclePoints", 64, 8, 128);
      this.lineWidth = new Setting("LineWidth", 2.0F, 0.5F, 10.0F);
      this.hudColorMode = new Setting("HudColorMode", false);
      this.colorOffset = new Setting("ColorOffset", 10, 1, 50, (v) -> {
         return (Boolean)this.hudColorMode.getValue();
      });
      this.ignoreJump = new Setting("IgnoreJump", false);
   }

   public void onRender3D(class_4587 stack) {
      if (ModuleManager.aura.isEnabled() && mc.field_1724 != null && mc.field_1687 != null) {
         List<class_742> players = mc.field_1687.method_18456();
         Iterator var3 = players.iterator();

         while(true) {
            class_742 player;
            do {
               do {
                  if (!var3.hasNext()) {
                     return;
                  }

                  player = (class_742)var3.next();
               } while(player == mc.field_1724 && !(Boolean)this.onlySelf.getValue());
            } while(player != mc.field_1724 && (Boolean)this.onlySelf.getValue());

            if (!player.method_29504() && player.method_5805()) {
               float range = this.getAuraRange();
               Color circleColor = this.CircleColor(player, range);
               if (((BooleanSettingGroup)this.glowSettings.getValue()).isEnabled()) {
                  this.renderGlowCircle(stack, player, range, circleColor);
               }

               this.renderCircle(stack, player, range, circleColor);
            }
         }
      }
   }

   private float getAuraRange() {
      return mc.field_1724.method_6128() && (Boolean)ModuleManager.aura.elytra.getValue() ? (Float)ModuleManager.aura.elytraAttackRange.getValue() : (Float)ModuleManager.aura.attackRange.getValue();
   }

   private Color CircleColor(class_742 player, float range) {
      if (player == mc.field_1724) {
         List<class_742> enemiesInRange = this.getEnemiesInRange(player, range);
         return !enemiesInRange.isEmpty() ? ((ColorSetting)this.enemyInRangeColor.getValue()).getColorObject() : ((ColorSetting)this.defaultColor.getValue()).getColorObject();
      } else {
         return ((ColorSetting)this.otherPlayerColor.getValue()).getColorObject();
      }
   }

   private List<class_742> getEnemiesInRange(class_742 centerPlayer, float range) {
      return mc.field_1687.method_18456().stream().filter((p) -> {
         return p != centerPlayer;
      }).filter((p) -> {
         return !p.method_29504() && p.method_5805();
      }).filter((p) -> {
         return centerPlayer.method_5858(p) <= (double)(range * range);
      }).filter(this::isEnemy).toList();
   }

   private boolean isEnemy(class_742 player) {
      return player != mc.field_1724 && !Managers.FRIEND.isFriend((class_1657)player) && !player.method_7337();
   }

   private void renderGlowCircle(class_4587 stack, class_742 player, float range, Color color) {
      double x = player.field_6014 + (player.method_23317() - player.field_6014) * (double)Render3DEngine.getTickDelta() - mc.method_1561().field_4686.method_19326().method_10216();
      double y = (Boolean)this.ignoreJump.getValue() ? (double)player.method_31478() + 0.1D - mc.method_1561().field_4686.method_19326().method_10214() : player.field_6036 + (player.method_23318() - player.field_6036) * (double)Render3DEngine.getTickDelta() - mc.method_1561().field_4686.method_19326().method_10214();
      double z = player.field_5969 + (player.method_23321() - player.field_5969) * (double)Render3DEngine.getTickDelta() - mc.method_1561().field_4686.method_19326().method_10215();
      stack.method_22903();
      stack.method_22904(x, y, z);
      RenderSystem.enableBlend();
      RenderSystem.blendFunc(770, 1);
      RenderSystem.setShader(class_757::method_34540);

      for(int i = 0; i < (Integer)this.glowRadius.getValue(); ++i) {
         float glowRange = range + (float)i * 0.1F;
         float alpha = (1.0F - (float)i / (float)(Integer)this.glowRadius.getValue()) * (Float)this.glowIntensity.getValue() * 0.3F;
         Color glowColor = Render2DEngine.applyOpacity(color, alpha);
         this.renderSingleCircle(stack, glowRange, glowColor, (Integer)this.circlePoints.getValue(), (Float)this.lineWidth.getValue() + (float)i * 0.5F);
      }

      RenderSystem.defaultBlendFunc();
      RenderSystem.disableBlend();
      stack.method_22909();
   }

   private void renderCircle(class_4587 stack, class_742 player, float range, Color color) {
      double x = player.field_6014 + (player.method_23317() - player.field_6014) * (double)Render3DEngine.getTickDelta() - mc.method_1561().field_4686.method_19326().method_10216();
      double y = (Boolean)this.ignoreJump.getValue() ? (double)player.method_31478() + 0.1D - mc.method_1561().field_4686.method_19326().method_10214() : player.field_6036 + (player.method_23318() - player.field_6036) * (double)Render3DEngine.getTickDelta() - mc.method_1561().field_4686.method_19326().method_10214();
      double z = player.field_5969 + (player.method_23321() - player.field_5969) * (double)Render3DEngine.getTickDelta() - mc.method_1561().field_4686.method_19326().method_10215();
      stack.method_22903();
      stack.method_22904(x, y, z);
      RenderSystem.enableBlend();
      RenderSystem.setShader(class_757::method_34540);
      this.renderSingleCircle(stack, range, color, (Integer)this.circlePoints.getValue(), (Float)this.lineWidth.getValue());
      RenderSystem.disableBlend();
      stack.method_22909();
   }

   private void renderSingleCircle(class_4587 stack, float radius, Color color, int points, float width) {
      class_287 bufferBuilder = class_289.method_1348().method_60827(class_5596.field_29345, class_290.field_1576);
      Matrix4f matrix = stack.method_23760().method_23761();

      for(int i = 0; i <= points; ++i) {
         Color currentColor = color;
         if ((Boolean)this.hudColorMode.getValue()) {
            currentColor = HudEditor.getColor(i * (Integer)this.colorOffset.getValue());
         }

         float angle = (float)((double)(i * 2) * 3.141592653589793D / (double)points);
         float x = (float)((double)radius * Math.cos((double)angle));
         float z = (float)((double)radius * Math.sin((double)angle));
         bufferBuilder.method_22918(matrix, x, 0.0F, z).method_39415(currentColor.getRGB());
      }

      class_286.method_43433(bufferBuilder.method_60800());
   }
}
