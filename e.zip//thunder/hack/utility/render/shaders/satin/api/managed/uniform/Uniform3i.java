package thunder.hack.utility.render.shaders.satin.api.managed.uniform;

public interface Uniform3i {
   void set(int var1, int var2, int var3);
}
