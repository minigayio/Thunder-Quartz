package thunder.hack.utility.render.shaders.satin.api.managed.uniform;

public interface Uniform1f {
   void set(float var1);
}
