package thunder.hack.features.modules.misc;

import net.minecraft.class_2828.class_2829;
import thunder.hack.features.modules.Module;
import thunder.hack.setting.Setting;

public class Damage extends Module {
   private final Setting<Damage.DamageMode> mode;
   private final Setting<Integer> damage;

   public Damage() {
      super("Damage", Module.Category.MISC);
      this.mode = new Setting("Mode", Damage.DamageMode.NCP);
      this.damage = new Setting("Damage", 1, 0, 20);
   }

   public void onEnable() {
      this.damage((Damage.DamageMode)this.mode.getValue());
      this.disable();
   }

   private void damage(Damage.DamageMode mode) {
      mode.run();
   }

   private static enum DamageMode {
      NCP("NCP", () -> {
         if (Module.mc.field_1724 != null && Module.mc.method_1562() != null) {
            double x = Module.mc.field_1724.method_23317();
            double y = Module.mc.field_1724.method_23318();
            double z = Module.mc.field_1724.method_23321();

            for(int i = 0; i < 5; ++i) {
               Module.mc.method_1562().method_52787(new class_2829(x, y + 3.0D, z, false));
               Module.mc.method_1562().method_52787(new class_2829(x, y, z, false));
            }

            Module.mc.method_1562().method_52787(new class_2829(x, y, z, true));
         }
      }),
      AAC("AAC", () -> {
         if (Module.mc.field_1724 != null && Module.mc.method_1562() != null) {
            Module.mc.method_1562().method_52787(new class_2829(Module.mc.field_1724.method_23317(), Module.mc.field_1724.method_23318() + 3.5D, Module.mc.field_1724.method_23321(), false));
            Module.mc.method_1562().method_52787(new class_2829(Module.mc.field_1724.method_23317(), Module.mc.field_1724.method_23318(), Module.mc.field_1724.method_23321(), false));
            Module.mc.method_1562().method_52787(new class_2829(Module.mc.field_1724.method_23317(), Module.mc.field_1724.method_23318(), Module.mc.field_1724.method_23321(), true));
         }
      }),
      Verus("Verus", () -> {
         if (Module.mc.field_1724 != null && Module.mc.method_1562() != null) {
            Module.mc.method_1562().method_52787(new class_2829(Module.mc.field_1724.method_23317(), Module.mc.field_1724.method_23318() + 5.0D, Module.mc.field_1724.method_23321(), false));
            Module.mc.method_1562().method_52787(new class_2829(Module.mc.field_1724.method_23317(), Module.mc.field_1724.method_23318(), Module.mc.field_1724.method_23321(), false));
            Module.mc.method_1562().method_52787(new class_2829(Module.mc.field_1724.method_23317(), Module.mc.field_1724.method_23318(), Module.mc.field_1724.method_23321(), true));
         }
      });

      private final String name;
      private final Runnable action;

      private DamageMode(String name, Runnable action) {
         this.name = name;
         this.action = action;
      }

      public void run() {
         this.action.run();
      }

      public String toString() {
         return this.name;
      }

      // $FF: synthetic method
      private static Damage.DamageMode[] $values() {
         return new Damage.DamageMode[]{NCP, AAC, Verus};
      }
   }
}
