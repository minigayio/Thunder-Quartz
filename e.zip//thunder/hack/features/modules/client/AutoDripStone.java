package thunder.hack.features.modules.client;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2533;
import net.minecraft.class_2596;
import net.minecraft.class_2680;
import net.minecraft.class_2868;
import net.minecraft.class_2879;
import net.minecraft.class_2885;
import net.minecraft.class_3965;
import thunder.hack.events.impl.EventTick;
import thunder.hack.features.modules.Module;
import thunder.hack.setting.Setting;
import thunder.hack.utility.Timer;
import thunder.hack.utility.player.InteractionUtility;
import thunder.hack.utility.player.InventoryUtility;

public class AutoDripStone extends Module {
   Setting<Integer> range = new Setting("Range", 3, 1, 5);
   Setting<Integer> delay = new Setting("Delay", 1, 1, 1500);
   Setting<Boolean> silentSwitch = new Setting("SilentSwitch", true);
   Timer timer = new Timer();

   public AutoDripStone() {
      super("AutoDripStone", Module.Category.MISC);
   }

   @EventHandler
   public void onTick(EventTick event) {
      if (mc.field_1724 != null && mc.field_1687 != null && this.timer.passedMs((long)(Integer)this.delay.getValue())) {
         class_2338 playerPos = mc.field_1724.method_24515();

         for(int x = -(Integer)this.range.getValue(); x <= (Integer)this.range.getValue(); ++x) {
            for(int y = -(Integer)this.range.getValue(); y <= (Integer)this.range.getValue(); ++y) {
               for(int z = -(Integer)this.range.getValue(); z <= (Integer)this.range.getValue(); ++z) {
                  class_2338 pos = playerPos.method_10069(x, y, z);
                  class_2680 state = mc.field_1687.method_8320(pos);
                  if (state.method_26204() instanceof class_2533 && !(Boolean)state.method_11654(class_2533.field_11631) && this.handleDripstonePlacement(pos)) {
                     this.timer.reset();
                     return;
                  }
               }
            }
         }

      }
   }

   boolean handleDripstonePlacement(class_2338 trapdoorPos) {
      class_2338 placePos = trapdoorPos.method_10074();
      if (!mc.field_1687.method_8320(placePos).method_26215()) {
         return false;
      } else {
         int dripstoneSlot = InventoryUtility.findInHotBar((i) -> {
            return i.method_7909() == class_1802.field_28042;
         }).slot();
         if (dripstoneSlot == -1) {
            return false;
         } else {
            int prevSlot = mc.field_1724.method_31548().field_7545;
            if ((Boolean)this.silentSwitch.getValue()) {
               this.switchToSlotSilent(dripstoneSlot);
            } else {
               this.switchToSlot(dripstoneSlot);
            }

            InteractionUtility.BlockPosWithFacing targetBlock = InteractionUtility.checkNearBlocks(placePos);
            if (targetBlock == null) {
               return false;
            } else {
               this.placeBlock(targetBlock);
               this.timer.reset();
               mc.field_1724.method_31548().field_7545 = prevSlot;
               this.holdRightClickOnTrapdoor(trapdoorPos);
               return true;
            }
         }
      }
   }

   void holdRightClickOnTrapdoor(class_2338 trapdoorPos) {
      if (this.timer.passedMs(1L)) {
         class_3965 hitResult = new class_3965(mc.field_1724.method_19538(), class_2350.field_11036, trapdoorPos, false);
         this.sendPacket(new class_2885(class_1268.field_5808, hitResult, 0));
         this.sendPacket(new class_2879(class_1268.field_5808));
      }
   }

   void switchToSlotSilent(int slot) {
      mc.field_1724.field_3944.method_52787(new class_2868(slot));
   }

   void switchToSlot(int slot) {
      mc.field_1724.method_31548().field_7545 = slot;
   }

   void placeBlock(InteractionUtility.BlockPosWithFacing block) {
      class_3965 bhr = new class_3965(block.position().method_46558().method_1019((new class_243(block.facing().method_23955())).method_1021(0.5D)), block.facing(), block.position(), false);
      if (this.timer.passedMs(1L)) {
         this.sendPacket(new class_2885(class_1268.field_5808, bhr, 0));
         this.sendPacket(new class_2879(class_1268.field_5808));
      }
   }

   public void sendPacket(class_2596<?> packet) {
      mc.field_1724.field_3944.method_52787(packet);
   }
}
