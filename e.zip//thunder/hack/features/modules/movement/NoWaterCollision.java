package thunder.hack.features.modules.movement;

import thunder.hack.features.modules.Module;

public class NoWaterCollision extends Module {
   public NoWaterCollision() {
      super("NoWaterCollision", Module.Category.MOVEMENT);
   }
}
