package thunder.hack.core.manager.client;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import org.lwjgl.glfw.GLFW;
import thunder.hack.ThunderHack;
import thunder.hack.core.manager.IManager;
import thunder.hack.features.hud.HudElement;
import thunder.hack.features.hud.impl.ArmorHud;
import thunder.hack.features.hud.impl.AutoCrystalInfo;
import thunder.hack.features.hud.impl.CandleHud;
import thunder.hack.features.hud.impl.ChestCounter;
import thunder.hack.features.hud.impl.Companion;
import thunder.hack.features.hud.impl.Cooldowns;
import thunder.hack.features.hud.impl.Coords;
import thunder.hack.features.hud.impl.Crosshair;
import thunder.hack.features.hud.impl.CrosshairArrows;
import thunder.hack.features.hud.impl.FpsCounter;
import thunder.hack.features.hud.impl.GapplesHud;
import thunder.hack.features.hud.impl.Hotbar;
import thunder.hack.features.hud.impl.KeyBinds;
import thunder.hack.features.hud.impl.KillFeed;
import thunder.hack.features.hud.impl.KillStats;
import thunder.hack.features.hud.impl.LegacyHud;
import thunder.hack.features.hud.impl.MemoryHud;
import thunder.hack.features.hud.impl.ModuleList;
import thunder.hack.features.hud.impl.PVPResources;
import thunder.hack.features.hud.impl.PingHud;
import thunder.hack.features.hud.impl.PotionHud;
import thunder.hack.features.hud.impl.Radar;
import thunder.hack.features.hud.impl.RadarRewrite;
import thunder.hack.features.hud.impl.Speedometer;
import thunder.hack.features.hud.impl.StaffBoard;
import thunder.hack.features.hud.impl.TPSCounter;
import thunder.hack.features.hud.impl.TargetHud;
import thunder.hack.features.hud.impl.TimerIndicator;
import thunder.hack.features.hud.impl.TotemCounter;
import thunder.hack.features.hud.impl.WaterMark;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.client.AntiCrash;
import thunder.hack.features.modules.client.AntiPacketException;
import thunder.hack.features.modules.client.AntiServerAdd;
import thunder.hack.features.modules.client.AntiServerRP;
import thunder.hack.features.modules.client.AutoDripStone;
import thunder.hack.features.modules.client.BaritoneSettings;
import thunder.hack.features.modules.client.Cape;
import thunder.hack.features.modules.client.ChatTranslator;
import thunder.hack.features.modules.client.ClickGui;
import thunder.hack.features.modules.client.ClientSettings;
import thunder.hack.features.modules.client.ClientSpoof;
import thunder.hack.features.modules.client.FastLatency;
import thunder.hack.features.modules.client.HudEditor;
import thunder.hack.features.modules.client.Media;
import thunder.hack.features.modules.client.Notifications;
import thunder.hack.features.modules.client.OptifineCapes;
import thunder.hack.features.modules.client.PlayerOnlineList;
import thunder.hack.features.modules.client.RPC;
import thunder.hack.features.modules.client.Rotations;
import thunder.hack.features.modules.client.SoundFX;
import thunder.hack.features.modules.client.ThunderHackGui;
import thunder.hack.features.modules.client.UnHook;
import thunder.hack.features.modules.client.WayPoints;
import thunder.hack.features.modules.client.Windows;
import thunder.hack.features.modules.client.sopretty;
import thunder.hack.features.modules.combat.AimBot;
import thunder.hack.features.modules.combat.AntiBot;
import thunder.hack.features.modules.combat.AntiLegitMiss;
import thunder.hack.features.modules.combat.Aura;
import thunder.hack.features.modules.combat.AutoAnchor;
import thunder.hack.features.modules.combat.AutoAnvil;
import thunder.hack.features.modules.combat.AutoBed;
import thunder.hack.features.modules.combat.AutoBuff;
import thunder.hack.features.modules.combat.AutoClicker;
import thunder.hack.features.modules.combat.AutoCrystal;
import thunder.hack.features.modules.combat.AutoCrystalBase;
import thunder.hack.features.modules.combat.AutoGApple;
import thunder.hack.features.modules.combat.AutoShield;
import thunder.hack.features.modules.combat.AutoTotem;
import thunder.hack.features.modules.combat.AutoTrap;
import thunder.hack.features.modules.combat.AutoWeb;
import thunder.hack.features.modules.combat.Blocker;
import thunder.hack.features.modules.combat.BowPop;
import thunder.hack.features.modules.combat.BowSpam;
import thunder.hack.features.modules.combat.Breaker;
import thunder.hack.features.modules.combat.Burrow;
import thunder.hack.features.modules.combat.Criticals;
import thunder.hack.features.modules.combat.FakeLag;
import thunder.hack.features.modules.combat.FireSpam;
import thunder.hack.features.modules.combat.HitBox;
import thunder.hack.features.modules.combat.HoleFill;
import thunder.hack.features.modules.combat.LegitHelper;
import thunder.hack.features.modules.combat.MoreKnockback;
import thunder.hack.features.modules.combat.PistonAura;
import thunder.hack.features.modules.combat.PistonPush;
import thunder.hack.features.modules.combat.Quiver;
import thunder.hack.features.modules.combat.Reach;
import thunder.hack.features.modules.combat.SelfTrap;
import thunder.hack.features.modules.combat.Surround;
import thunder.hack.features.modules.combat.TNTAura;
import thunder.hack.features.modules.combat.TargetSpeed;
import thunder.hack.features.modules.combat.TargetStrafe;
import thunder.hack.features.modules.combat.TriggerBot;
import thunder.hack.features.modules.misc.ACDetector;
import thunder.hack.features.modules.misc.AntiAFK;
import thunder.hack.features.modules.misc.AntiAttack;
import thunder.hack.features.modules.misc.AntiFireBall;
import thunder.hack.features.modules.misc.AntiTrap;
import thunder.hack.features.modules.misc.AutoAuth;
import thunder.hack.features.modules.misc.AutoCommand;
import thunder.hack.features.modules.misc.AutoEZ;
import thunder.hack.features.modules.misc.AutoFish;
import thunder.hack.features.modules.misc.AutoFlyme;
import thunder.hack.features.modules.misc.AutoGear;
import thunder.hack.features.modules.misc.AutoLeave;
import thunder.hack.features.modules.misc.AutoSign;
import thunder.hack.features.modules.misc.AutoSoup;
import thunder.hack.features.modules.misc.AutoTpAccept;
import thunder.hack.features.modules.misc.AutoTrader;
import thunder.hack.features.modules.misc.ChatSpammer;
import thunder.hack.features.modules.misc.ChatUtils;
import thunder.hack.features.modules.misc.ChestStealer;
import thunder.hack.features.modules.misc.ChorusExploit;
import thunder.hack.features.modules.misc.Damage;
import thunder.hack.features.modules.misc.Disabler;
import thunder.hack.features.modules.misc.EbatteSratte;
import thunder.hack.features.modules.misc.ExtraTab;
import thunder.hack.features.modules.misc.FakePlayer;
import thunder.hack.features.modules.misc.FastTrident;
import thunder.hack.features.modules.misc.Ghost;
import thunder.hack.features.modules.misc.ItemScroller;
import thunder.hack.features.modules.misc.KillCommand;
import thunder.hack.features.modules.misc.LagNotifier;
import thunder.hack.features.modules.misc.MessageAppend;
import thunder.hack.features.modules.misc.MiddleClick;
import thunder.hack.features.modules.misc.NameProtect;
import thunder.hack.features.modules.misc.NoCommentExploit;
import thunder.hack.features.modules.misc.Nuker;
import thunder.hack.features.modules.misc.PacketCanceler;
import thunder.hack.features.modules.misc.PearlChaser;
import thunder.hack.features.modules.misc.PingSpoofTest;
import thunder.hack.features.modules.misc.RadyNotification;
import thunder.hack.features.modules.misc.ServerHelper;
import thunder.hack.features.modules.misc.Spammer;
import thunder.hack.features.modules.misc.StashLogger;
import thunder.hack.features.modules.misc.TapeMouse;
import thunder.hack.features.modules.misc.TotemPopCounter;
import thunder.hack.features.modules.misc.Tracker;
import thunder.hack.features.modules.misc.VisualRange;
import thunder.hack.features.modules.movement.AntiVoid;
import thunder.hack.features.modules.movement.AntiWeb;
import thunder.hack.features.modules.movement.AutoSprint;
import thunder.hack.features.modules.movement.AutoWalk;
import thunder.hack.features.modules.movement.Avoid;
import thunder.hack.features.modules.movement.Blink;
import thunder.hack.features.modules.movement.BoatFly;
import thunder.hack.features.modules.movement.ClickTP;
import thunder.hack.features.modules.movement.ElytraPlus;
import thunder.hack.features.modules.movement.ElytraRecast;
import thunder.hack.features.modules.movement.ElytraSpeed;
import thunder.hack.features.modules.movement.EntityControl;
import thunder.hack.features.modules.movement.EntitySpeed;
import thunder.hack.features.modules.movement.Flight;
import thunder.hack.features.modules.movement.GuiMove;
import thunder.hack.features.modules.movement.HoleAnchor;
import thunder.hack.features.modules.movement.HoleSnap;
import thunder.hack.features.modules.movement.Jesus;
import thunder.hack.features.modules.movement.LevitationControl;
import thunder.hack.features.modules.movement.LongJump;
import thunder.hack.features.modules.movement.NoFall;
import thunder.hack.features.modules.movement.NoPush;
import thunder.hack.features.modules.movement.NoSlow;
import thunder.hack.features.modules.movement.NoWaterCollision;
import thunder.hack.features.modules.movement.PacketFly;
import thunder.hack.features.modules.movement.Parkour;
import thunder.hack.features.modules.movement.Phase;
import thunder.hack.features.modules.movement.ReverseStep;
import thunder.hack.features.modules.movement.SafeWalk;
import thunder.hack.features.modules.movement.Scaffold;
import thunder.hack.features.modules.movement.Speed;
import thunder.hack.features.modules.movement.Spider;
import thunder.hack.features.modules.movement.Step;
import thunder.hack.features.modules.movement.Strafe;
import thunder.hack.features.modules.movement.TickShift;
import thunder.hack.features.modules.movement.Timer;
import thunder.hack.features.modules.movement.TridentBoost;
import thunder.hack.features.modules.movement.TridentFly;
import thunder.hack.features.modules.movement.Velocity;
import thunder.hack.features.modules.movement.WaterSpeed;
import thunder.hack.features.modules.player.AirPlace;
import thunder.hack.features.modules.player.AntiAim;
import thunder.hack.features.modules.player.AntiBadEffects;
import thunder.hack.features.modules.player.AntiBallPlace;
import thunder.hack.features.modules.player.AntiHunger;
import thunder.hack.features.modules.player.AutoArmor;
import thunder.hack.features.modules.player.AutoEat;
import thunder.hack.features.modules.player.AutoRespawn;
import thunder.hack.features.modules.player.AutoSex;
import thunder.hack.features.modules.player.AutoTool;
import thunder.hack.features.modules.player.DurabilityAlert;
import thunder.hack.features.modules.player.ElytraReplace;
import thunder.hack.features.modules.player.ElytraSwap;
import thunder.hack.features.modules.player.FastUse;
import thunder.hack.features.modules.player.HotbarReplenish;
import thunder.hack.features.modules.player.InventoryCleaner;
import thunder.hack.features.modules.player.MouseElytraFix;
import thunder.hack.features.modules.player.MultiTask;
import thunder.hack.features.modules.player.NoEntityTrace;
import thunder.hack.features.modules.player.NoInteract;
import thunder.hack.features.modules.player.NoJumpDelay;
import thunder.hack.features.modules.player.NoServerRotate;
import thunder.hack.features.modules.player.NoServerSlot;
import thunder.hack.features.modules.player.PearlBait;
import thunder.hack.features.modules.player.PearlBlockThrow;
import thunder.hack.features.modules.player.PerfectDelay;
import thunder.hack.features.modules.player.PortalGodMode;
import thunder.hack.features.modules.player.PortalInventory;
import thunder.hack.features.modules.player.Regen;
import thunder.hack.features.modules.player.SpeedMine;
import thunder.hack.features.modules.player.ToolSaver;
import thunder.hack.features.modules.player.TpsSync;
import thunder.hack.features.modules.player.ViewLock;
import thunder.hack.features.modules.player.XCarry;
import thunder.hack.features.modules.render.Animations;
import thunder.hack.features.modules.render.AspectRatio;
import thunder.hack.features.modules.render.AuraRageDisplay;
import thunder.hack.features.modules.render.BlockESP;
import thunder.hack.features.modules.render.BlockHighLight;
import thunder.hack.features.modules.render.BreadCrumbs;
import thunder.hack.features.modules.render.BreakHighLight;
import thunder.hack.features.modules.render.Chams;
import thunder.hack.features.modules.render.ChinaHat;
import thunder.hack.features.modules.render.DamageTint;
import thunder.hack.features.modules.render.ESP;
import thunder.hack.features.modules.render.FOV;
import thunder.hack.features.modules.render.FreeCam;
import thunder.hack.features.modules.render.Fullbright;
import thunder.hack.features.modules.render.HitBubbles;
import thunder.hack.features.modules.render.HitParticles;
import thunder.hack.features.modules.render.HoleESP;
import thunder.hack.features.modules.render.ItemESP;
import thunder.hack.features.modules.render.JumpCircle;
import thunder.hack.features.modules.render.KillEffect;
import thunder.hack.features.modules.render.LogoutSpots;
import thunder.hack.features.modules.render.NameTags;
import thunder.hack.features.modules.render.NoBob;
import thunder.hack.features.modules.render.NoCameraClip;
import thunder.hack.features.modules.render.NoRender;
import thunder.hack.features.modules.render.Particles;
import thunder.hack.features.modules.render.PopChams;
import thunder.hack.features.modules.render.Shaders;
import thunder.hack.features.modules.render.SoundESP;
import thunder.hack.features.modules.render.StorageEsp;
import thunder.hack.features.modules.render.Tooltips;
import thunder.hack.features.modules.render.TotemAnimation;
import thunder.hack.features.modules.render.Tracers;
import thunder.hack.features.modules.render.Trails;
import thunder.hack.features.modules.render.Trajectories;
import thunder.hack.features.modules.render.TunnelEsp;
import thunder.hack.features.modules.render.ViewModel;
import thunder.hack.features.modules.render.VoidESP;
import thunder.hack.features.modules.render.WorldTweaks;
import thunder.hack.features.modules.render.XRay;
import thunder.hack.gui.clickui.ClickGUI;
import thunder.hack.gui.font.FontRenderers;

public class ModuleManager implements IManager {
   public ArrayList<Module> modules = new ArrayList();
   public List<Module> sortedModules = new ArrayList();
   public List<Integer> activeMouseKeys = new ArrayList();
   public static AntiPacketException antiPacketException = new AntiPacketException();
   public static LevitationControl levitationControl = new LevitationControl();
   public static InventoryCleaner inventoryCleaner = new InventoryCleaner();
   public static NoCommentExploit noCommentExploit = new NoCommentExploit();
   public static NoWaterCollision noWaterCollision = new NoWaterCollision();
   public static BaritoneSettings baritoneSettings = new BaritoneSettings();
   public static PortalInventory portalInventory = new PortalInventory();
   public static TotemPopCounter totemPopCounter = new TotemPopCounter();
   public static HotbarReplenish hotbarReplenish = new HotbarReplenish();
   public static DurabilityAlert durabilityAlert = new DurabilityAlert();
   public static AutoCrystalBase autoCrystalBase = new AutoCrystalBase();
   public static CrosshairArrows crosshairArrows = new CrosshairArrows();
   public static PearlBlockThrow pearlBlockThrow = new PearlBlockThrow();
   public static AutoCrystalInfo autoCrystalInfo = new AutoCrystalInfo();
   public static ChatTranslator chatTranslator = new ChatTranslator();
   public static PacketCanceler packetCanceler = new PacketCanceler();
   public static ClientSettings clientSettings = new ClientSettings();
   public static TimerIndicator timerIndicator = new TimerIndicator();
   public static ThunderHackGui thunderHackGui = new ThunderHackGui();
   public static NoServerRotate noServerRotate = new NoServerRotate();
   public static BreakHighLight breakHighLight = new BreakHighLight();
   public static BlockHighLight blockHighLight = new BlockHighLight();
   public static AntiBadEffects antiBadEffects = new AntiBadEffects();
   public static MouseElytraFix mouseElytraFix = new MouseElytraFix();
   public static TotemAnimation totemAnimation = new TotemAnimation();
   public static PortalGodMode portalGodMode = new PortalGodMode();
   public static OptifineCapes optifineCapes = new OptifineCapes();
   public static Notifications notifications = new Notifications();
   public static AntiAim antiAim = new AntiAim();
   public static NoEntityTrace noEntityTrace = new NoEntityTrace();
   public static MessageAppend messageAppend = new MessageAppend();
   public static PlayerOnlineList playerOnlineList = new PlayerOnlineList();
   public static EntityControl entityControl = new EntityControl();
   public static ElytraReplace elytraReplace = new ElytraReplace();
   public static ChorusExploit chorusExploit = new ChorusExploit();
   public static MoreKnockback moreKnockback = new MoreKnockback();
   public static AntiServerAdd antiServerAdd = new AntiServerAdd();
   public static AntiLegitMiss antiLegitMiss = new AntiLegitMiss();
   public static AntiBallPlace antiBallPlace = new AntiBallPlace();
   public static TridentBoost tridentBoost = new TridentBoost();
   public static AutoShield autoShield = new AutoShield();
   public static TridentFly tridentFly = new TridentFly();
   public static Trajectories trajectories = new Trajectories();
   public static TargetStrafe targetStrafe = new TargetStrafe();
   public static RadarRewrite radarRewrite = new RadarRewrite();
   public static PVPResources pvpResources = new PVPResources();
   public static NoServerSlot noServerSlot = new NoServerSlot();
   public static NoCameraClip noCameraClip = new NoCameraClip();
   public static ItemScroller itemScroller = new ItemScroller();
   public static HitParticles hitParticles = new HitParticles();
   public static ElytraRecast elytraRecast = new ElytraRecast();
   public static EbatteSratte ebatteSratte = new EbatteSratte();
   public static ChestStealer chestStealer = new ChestStealer();
   public static AutoTpAccept autoTpAccept = new AutoTpAccept();
   public static AntiServerRP antiServerRP = new AntiServerRP();
   public static TotemCounter totemCounter = new TotemCounter();
   public static PerfectDelay perfectDelay = new PerfectDelay();
   public static ServerHelper serverHelper = new ServerHelper();
   public static RadyNotification radyNotification = new RadyNotification();
   public static KillCommand killCommand = new KillCommand();
   public static ChestCounter chestCounter = new ChestCounter();
   public static Damage damage = new Damage();
   public static StashLogger stashLogger = new StashLogger();
   public static FastLatency fastLatency = new FastLatency();
   public static PearlChaser pearlChaser = new PearlChaser();
   public static PingSpoofTest pingSpoofTest = new PingSpoofTest();
   public static WorldTweaks worldTweaks = new WorldTweaks();
   public static VisualRange visualRange = new VisualRange();
   public static Speedometer speedometer = new Speedometer();
   public static ReverseStep reverseStep = new ReverseStep();
   public static NoJumpDelay noJumpDelay = new NoJumpDelay();
   public static NameProtect nameProtect = new NameProtect();
   public static MiddleClick middleClick = new MiddleClick();
   public static LogoutSpots logoutSpots = new LogoutSpots();
   public static LagNotifier lagNotifier = new LagNotifier();
   public static BreadCrumbs breadCrumbs = new BreadCrumbs();
   public static AutoRespawn autoRespawn = new AutoRespawn();
   public static AutoCrystal autoCrystal = new AutoCrystal();
   public static EntitySpeed entitySpeed = new EntitySpeed();
   public static AspectRatio aspectRatio = new AspectRatio();
   public static ClientSpoof clientSpoof = new ClientSpoof();
   public static LegitHelper legitHelper = new LegitHelper();
   public static AutoAnchor autoAnchor = new AutoAnchor();
   public static WaterSpeed waterSpeed = new WaterSpeed();
   public static TriggerBot triggerBot = new TriggerBot();
   public static TPSCounter tpsCounter = new TPSCounter();
   public static StorageEsp storageEsp = new StorageEsp();
   public static StaffBoard staffBoard = new StaffBoard();
   public static PistonPush pistonPush = new PistonPush();
   public static PistonAura pistonAura = new PistonAura();
   public static NoInteract noInteract = new NoInteract();
   public static ModuleList moduleList = new ModuleList();
   public static KillEffect killEffect = new KillEffect();
   public static JumpCircle jumpCircle = new JumpCircle();
   public static AuraRageDisplay auraRageDisplay = new AuraRageDisplay();
   public static HoleAnchor holeAnchor = new HoleAnchor();
   public static Fullbright fullbright = new Fullbright();
   public static FpsCounter fpsCounter = new FpsCounter();
   public static FakePlayer fakePlayer = new FakePlayer();
   public static ElytraSwap elytraSwap = new ElytraSwap();
   public static ElytraPlus elytraPlus = new ElytraPlus();
   public static FastTrident fastTrident = new FastTrident();
   public static AutoSprint autoSprint = new AutoSprint();
   public static AutoGApple autoGApple = new AutoGApple();
   public static AntiHunger antiHunger = new AntiHunger();
   public static AutoClicker autoClicker = new AutoClicker();
   public static ElytraSpeed elytraSpeed = new ElytraSpeed();
   public static Animations animations = new Animations();
   public static DamageTint damageTint = new DamageTint();
   public static AntiAttack antiAttack = new AntiAttack();
   public static GapplesHud gapplesHud = new GapplesHud();
   public static HitBubbles hitBubbles = new HitBubbles();
   public static AutoTrader autoTrader = new AutoTrader();
   public static KillStats killStats = new KillStats();
   public static AutoAnvil autoAnvil = new AutoAnvil();
   public static CandleHud candleHud = new CandleHud();
   public static Particles particles = new Particles();
   public static ToolSaver toolSaver = new ToolSaver();
   public static WayPoints wayPoints = new WayPoints();
   public static WaterMark waterMark = new WaterMark();
   public static ViewModel viewModel = new ViewModel();
   public static TunnelEsp tunnelEsp = new TunnelEsp();
   public static TickShift tickShift = new TickShift();
   public static TargetHud targetHud = new TargetHud();
   public static SpeedMine speedMine = new SpeedMine();
   public static PotionHud potionHud = new PotionHud();
   public static PearlBait pearlBait = new PearlBait();
   public static PacketFly packetFly = new PacketFly();
   public static MultiTask multitask = new MultiTask();
   public static LegacyHud legacyHud = new LegacyHud();
   public static HudEditor hudEditor = new HudEditor();
   public static Crosshair crosshair = new Crosshair();
   public static Criticals criticals = new Criticals();
   public static ChatUtils chatUtils = new ChatUtils();
   public static AutoTotem autoTotem = new AutoTotem();
   public static AutoLeave autoLeave = new AutoLeave();
   public static AutoFlyme autoFlyme = new AutoFlyme();
   public static AutoArmor autoArmor = new AutoArmor();
   public static Cooldowns cooldowns = new Cooldowns();
   public static TapeMouse tapeMouse = new TapeMouse();
   public static Rotations rotations = new Rotations();
   public static MemoryHud memoryHud = new MemoryHud();
   public static Companion companion = new Companion();
   public static AntiCrash antiCrash = new AntiCrash();
   public static AutoGear autoGear = new AutoGear();
   public static ViewLock viewLock = new ViewLock();
   public static Velocity velocity = new Velocity();
   public static Disabler disabler = new Disabler();
   public static Tooltips tooltips = new Tooltips();
   public static Surround surround = new Surround();
   public static Scaffold scaffold = new Scaffold();
   public static PopChams popChams = new PopChams();
   public static NoRender noRender = new NoRender();
   public static NameTags nameTags = new NameTags();
   public static LongJump longJump = new LongJump();
   public static KeyBinds keyBinds = new KeyBinds();
   public static HoleSnap holeSnap = new HoleSnap();
   public static HoleFill holeFill = new HoleFill();
   public static ExtraTab extraTab = new ExtraTab();
   public static ClickGui clickGui = new ClickGui();
   public static AutoTrap autoTrap = new AutoTrap();
   public static AutoTool autoTool = new AutoTool();
   public static SoundESP soundESP = new SoundESP();
   public static AutoSoup autoSoup = new AutoSoup();
   public static AutoFish autoFish = new AutoFish();
   public static AutoBuff autoBuff = new AutoBuff();
   public static AutoAuth autoAuth = new AutoAuth();
   public static ArmorHud armorHud = new ArmorHud();
   public static AirPlace airPlace = new AirPlace();
   public static AutoCommand autoCommand = new AutoCommand();
   public static SelfTrap selfTrap = new SelfTrap();
   public static ChatSpammer chatspammer = new ChatSpammer();
   public static AntiVoid antiVoid = new AntiVoid();
   public static KillFeed killFeed = new KillFeed();
   public static AutoWalk autoWalk = new AutoWalk();
   public static AutoSign autoSign = new AutoSign();
   public static BlockESP blockESP = new BlockESP();
   public static SafeWalk safeWalk = new SafeWalk();
   public static Windows windows = new Windows();
   public static Breaker breaker = new Breaker();
   public static AutoEat autoEat = new AutoEat();
   public static AntiAFK antiAFK = new AntiAFK();
   public static SoundFX soundFX = new SoundFX();
   public static AutoBed autoBed = new AutoBed();
   public static TNTAura tntAura = new TNTAura();
   public static VoidESP voidESP = new VoidESP();
   public static Tracker tracker = new Tracker();
   public static TpsSync tpsSync = new TpsSync();
   public static Spammer spammer = new Spammer();
   public static Shaders shaders = new Shaders();
   public static PingHud pingHud = new PingHud();
   public static ItemESP itemESP = new ItemESP();
   public static HoleESP holeESP = new HoleESP();
   public static GuiMove guiMove = new GuiMove();
   public static FreeCam freeCam = new FreeCam();
   public static FastUse fastUse = new FastUse();
   public static BowSpam bowSpam = new BowSpam();
   public static BoatFly boatFly = new BoatFly();
   public static Blocker blocker = new Blocker();
   public static AutoWeb autoWeb = new AutoWeb();
   public static AntiWeb antiWeb = new AntiWeb();
   public static FakeLag fakeLag = new FakeLag();
   public static TargetSpeed targetSpeed = new TargetSpeed();
   public static AntiBot antiBot = new AntiBot();
   public static AutoSex autoSex = new AutoSex();
   public static Tracers tracers = new Tracers();
   public static FireSpam fireSpam = new FireSpam();
   public static Parkour parkour = new Parkour();
   public static ClickTP clickTP = new ClickTP();
   public static BowPop bowPop = new BowPop();
   public static XCarry xCarry = new XCarry();
   public static Trails trails = new Trails();
   public static Strafe strafe = new Strafe();
   public static Spider spider = new Spider();
   public static NoSlow noSlow = new NoSlow();
   public static NoFall noFall = new NoFall();
   public static Hotbar hotbar = new Hotbar();
   public static HitBox hitBox = new HitBox();
   public static Flight flight = new Flight();
   public static Coords coords = new Coords();
   public static Burrow burrow = new Burrow();
   public static AutoEZ autoEZ = new AutoEZ();
   public static AimBot aimBot = new AimBot();
   public static AntiFireBall antiFireBall = new AntiFireBall();
   public static Quiver quiver = new Quiver();
   public static AntiTrap antiTrap = new AntiTrap();
   public static NoPush noPush = new NoPush();
   public static UnHook unHook = new UnHook();
   public static Avoid avoid = new Avoid();
   public static Timer timer = new Timer();
   public static Regen regen = new Regen();
   public static Speed speed = new Speed();
   public static Reach reach = new Reach();
   public static ACDetector grimACDetector = new ACDetector();
   public static Radar radar = new Radar();
   public static Nuker nuker = new Nuker();
   public static Media media = new Media();
   public static Cape cape = new Cape();
   public static Ghost ghost = new Ghost();
   public static Chams chams = new Chams();
   public static ChinaHat chinaHat = new ChinaHat();
   public static Blink blink = new Blink();
   public static Phase phase = new Phase();
   public static NoBob noBob = new NoBob();
   public static Jesus jesus = new Jesus();
   public static XRay xray = new XRay();
   public static Step step = new Step();
   public static Aura aura = new Aura();
   public static FOV fov = new FOV();
   public static AutoDripStone autoDripStone = new AutoDripStone();
   public static sopretty sopretty = new sopretty();
   public static ESP esp = new ESP();
   public static RPC rpc = new RPC();

   public ModuleManager() {
      Field[] var1 = this.getClass().getDeclaredFields();
      int var2 = var1.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         Field field = var1[var3];
         if (Module.class.isAssignableFrom(field.getType())) {
            field.setAccessible(true);

            try {
               this.modules.add((Module)field.get(this));
            } catch (IllegalAccessException var6) {
               var6.printStackTrace();
            }
         }
      }

   }

   public Module get(String name) {
      Iterator var2 = this.modules.iterator();

      Module module;
      do {
         if (!var2.hasNext()) {
            return null;
         }

         module = (Module)var2.next();
      } while(!module.getName().equalsIgnoreCase(name));

      return module;
   }

   public ArrayList<Module> getEnabledModules() {
      ArrayList<Module> enabledModules = new ArrayList();
      Iterator var2 = this.modules.iterator();

      while(var2.hasNext()) {
         Module module = (Module)var2.next();
         if (module.isEnabled()) {
            enabledModules.add(module);
         }
      }

      return enabledModules;
   }

   public ArrayList<Module> getModulesByCategory(Module.Category category) {
      ArrayList<Module> modulesCategory = new ArrayList();
      this.modules.forEach((module) -> {
         if (module.getCategory() == category) {
            modulesCategory.add(module);
         }

      });
      return modulesCategory;
   }

   public List<Module.Category> getCategories() {
      return new ArrayList(Module.Category.values());
   }

   public void onLoad(String category) {
      try {
         ThunderHack.EVENT_BUS.unsubscribe((Object)unHook);
      } catch (Exception var3) {
      }

      unHook.setEnabled(false);
      this.modules.sort(Comparator.comparing(Module::getName));
      this.modules.forEach((m) -> {
         if (m.isEnabled() && (m.getCategory().getName().equalsIgnoreCase(category) || category.equals("none"))) {
            ThunderHack.EVENT_BUS.subscribe((Object)m);
         }

      });
      if (ConfigManager.firstLaunch) {
         notifications.enable();
         rpc.enable();
         soundFX.enable();
      }

   }

   public void onUpdate() {
      if (!Module.fullNullCheck()) {
         this.modules.stream().filter(Module::isEnabled).forEach(Module::onUpdate);
      }
   }

   public void onRender2D(class_332 context) {
      if (!mc.method_53526().method_53536() && !mc.field_1690.field_1842) {
         HudElement.anyHovered = false;
         this.modules.stream().filter(Module::isEnabled).forEach((module) -> {
            module.onRender2D(context);
         });
         if (!HudElement.anyHovered && !ClickGUI.anyHovered && GLFW.glfwGetPlatform() != 393219) {
            GLFW.glfwSetCursor(mc.method_22683().method_4490(), GLFW.glfwCreateStandardCursor(221185));
         }

         ThunderHack.core.onRender2D(context);
      }
   }

   public void onRender3D(class_4587 stack) {
      this.modules.stream().filter(Module::isEnabled).forEach((module) -> {
         module.onRender3D(stack);
      });
   }

   public void sortModules() {
      this.sortedModules = (List)this.getEnabledModules().stream().filter(Module::isDrawn).sorted(Comparator.comparing((module) -> {
         return FontRenderers.getModulesRenderer().getStringWidth(module.getFullArrayString()) * -1.0F;
      })).collect(Collectors.toList());
   }

   public void onLogout() {
      this.modules.forEach(Module::onLogout);
   }

   public void onLogin() {
      this.modules.forEach(Module::onLogin);
   }

   public void onUnload(String category) {
      this.modules.forEach((module) -> {
         if (module.isEnabled() && (module.getCategory().getName().equalsIgnoreCase(category) || category.equals("none"))) {
            ThunderHack.EVENT_BUS.unsubscribe((Object)module);
            module.setEnabled(false);
         }

      });
      this.modules.forEach(Module::onUnload);
   }

   public void onKeyPressed(int eventKey) {
      if (eventKey != -1 && eventKey != 0 && !(mc.field_1755 instanceof ClickGUI)) {
         this.modules.forEach((module) -> {
            if (module.getBind().getKey() == eventKey) {
               module.toggle();
            }

         });
      }
   }

   public void onKeyReleased(int eventKey) {
      if (eventKey != -1 && eventKey != 0 && !(mc.field_1755 instanceof ClickGUI)) {
         this.modules.forEach((module) -> {
            if (module.getBind().getKey() == eventKey && module.getBind().isHold()) {
               module.disable();
            }

         });
      }
   }

   public void onMoseKeyPressed(int eventKey) {
      if (eventKey != -1 && !(mc.field_1755 instanceof ClickGUI)) {
         this.modules.forEach((module) -> {
            if (Objects.equals(module.getBind().getBind(), "M" + eventKey)) {
               module.toggle();
            }

         });
      }
   }

   public void onMoseKeyReleased(int eventKey) {
      if (eventKey != -1 && !(mc.field_1755 instanceof ClickGUI)) {
         this.activeMouseKeys.add(eventKey);
         this.modules.forEach((module) -> {
            if (Objects.equals(module.getBind().getBind(), "M" + eventKey) && module.getBind().isHold()) {
               module.disable();
            }

         });
      }
   }

   public ArrayList<Module> getModulesSearch(String string) {
      ArrayList<Module> modulesCategory = new ArrayList();
      this.modules.forEach((module) -> {
         if (module.getName().toLowerCase().contains(string.toLowerCase())) {
            modulesCategory.add(module);
         }

      });
      return modulesCategory;
   }

   public void registerModule(Module module) {
      if (module != null) {
         this.modules.add(module);
         if (module.isEnabled()) {
            ThunderHack.EVENT_BUS.subscribe((Object)module);
         }

      }
   }

   public void registerHudElement(HudElement hudElement) {
      if (hudElement != null) {
         this.modules.add(hudElement);
      }
   }
}
