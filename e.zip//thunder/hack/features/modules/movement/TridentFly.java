package thunder.hack.features.modules.movement;

import java.util.Random;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_3532;
import net.minecraft.class_746;
import thunder.hack.ThunderHack;
import thunder.hack.events.impl.EventTick;
import thunder.hack.features.modules.Module;
import thunder.hack.setting.Setting;

public class TridentFly extends Module {
   private final Setting<TridentFly.modeBypass> bypassMode;
   private final Setting<Float> speedMultiplier;
   private final Setting<Float> timerSpeed;
   private float currentSpeedMultiplier;
   private final Random random;

   public TridentFly() {
      super("TridentFly", Module.Category.MOVEMENT);
      this.bypassMode = new Setting("BypassMode", TridentFly.modeBypass.Grim);
      this.speedMultiplier = new Setting("SpeedMultiplier", 1.05F, 1.0F, 1.2F);
      this.timerSpeed = new Setting("TimerSpeed", 1.0F, 0.9F, 1.2F);
      this.currentSpeedMultiplier = 1.0F;
      this.random = new Random();
   }

   public void onEnable() {
      ThunderHack.TICK_TIMER = (Float)this.timerSpeed.getValue();
   }

   public void onDisable() {
      ThunderHack.TICK_TIMER = 1.0F;
   }

   @EventHandler
   public void onTick(EventTick event) {
      class_746 player = mc.field_1724;
      if (player != null) {
         if (this.bypassMode.getValue() == TridentFly.modeBypass.Grim) {
            this.handleGrimMode(player);
         } else {
            this.handleVulcanMode(player);
         }

      }
   }

   private void handleVulcanMode(class_746 player) {
      this.adjustVelocity(player, (Float)this.speedMultiplier.getValue());
   }

   private void handleGrimMode(class_746 player) {
      if (Math.abs(player.method_18798().field_1351) > 0.1D) {
         float randomizedSpeed = (Float)this.speedMultiplier.getValue() + this.random.nextFloat() * 0.01F;
         this.adjustVelocity(player, class_3532.method_15363(this.currentSpeedMultiplier + 0.01F, 1.0F, randomizedSpeed));
         player.field_6017 = 0.0F;
         if (player.field_5976) {
            player.method_18800(player.method_18798().field_1352 * 0.95D, player.method_18798().field_1351, player.method_18798().field_1350 * 0.95D);
         }
      } else {
         this.currentSpeedMultiplier = 1.0F;
      }

      if (this.random.nextInt(100) > 95) {
         ThunderHack.TICK_TIMER = (Float)this.timerSpeed.getValue() + this.random.nextFloat() * 0.02F;
      }

   }

   private void adjustVelocity(class_746 player, float multiplier) {
      player.method_18800(player.method_18798().field_1352 * (double)multiplier, player.method_18798().field_1351, player.method_18798().field_1350 * (double)multiplier);
   }

   public static enum modeBypass {
      Vulcan,
      Grim,
      Both;

      // $FF: synthetic method
      private static TridentFly.modeBypass[] $values() {
         return new TridentFly.modeBypass[]{Vulcan, Grim, Both};
      }
   }
}
