package thunder.hack.utility.render.shaders.satin.api.managed.uniform;

import net.minecraft.class_1044;
import net.minecraft.class_276;

public interface SamplerUniform {
   void set(class_1044 var1);

   void set(class_276 var1);

   void set(int var1);
}
