package thunder.hack.features.modules.misc;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_7439;
import thunder.hack.core.Managers;
import thunder.hack.events.impl.PacketEvent;
import thunder.hack.features.modules.Module;
import thunder.hack.setting.Setting;

public class AutoTpAccept extends Module {
   public Setting<Boolean> onlyFriends = new Setting("onlyFriends", true);

   public AutoTpAccept() {
      super("AutoTPaccept", Module.Category.MISC);
   }

   @EventHandler
   public void onPacketReceive(PacketEvent.Receive event) {
      if (!fullNullCheck()) {
         if (event.getPacket() instanceof class_7439) {
            class_7439 packet = (class_7439)event.getPacket();
            String message = packet.comp_763().getString();
            if (message.contains("Gracz") && message.contains("wysłał prośbę o teleportację!")) {
               String playerName = this.extractPlayerName(message);
               if ((Boolean)this.onlyFriends.getValue()) {
                  if (Managers.FRIEND.isFriend(playerName)) {
                     this.sendTpAccept(playerName);
                  }
               } else {
                  this.sendTpAccept(playerName);
               }
            }
         }

      }
   }

   private void sendTpAccept(String playerName) {
      if (playerName != null && !playerName.isEmpty()) {
         mc.method_1562().method_45730("tpaccept " + playerName);
      }

   }

   private String extractPlayerName(String message) {
      String regex = "Gracz (\\w+) wysłał prośbę o teleportację!";
      Pattern pattern = Pattern.compile(regex);
      Matcher matcher = pattern.matcher(message);
      return matcher.find() ? matcher.group(1) : null;
   }
}
