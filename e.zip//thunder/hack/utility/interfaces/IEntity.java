package thunder.hack.utility.interfaces;

import java.util.List;
import net.minecraft.class_2338;
import thunder.hack.features.modules.render.Trails;

public interface IEntity {
   List<Trails.Trail> getTrails();

   class_2338 thunderHack_Recode$getVelocityBP();
}
