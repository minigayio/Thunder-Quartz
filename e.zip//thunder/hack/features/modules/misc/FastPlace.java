package thunder.hack.features.modules.misc;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_315;
import thunder.hack.events.impl.EventTick;
import thunder.hack.features.modules.Module;

public class FastPlace extends Module {
   private final class_315 gameOptions;

   public FastPlace() {
      super("FastPlace", Module.Category.MISC);
      this.gameOptions = mc.field_1690;
   }

   @EventHandler
   public void onTick(EventTick event) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         this.gameOptions.field_1904.method_23481(true);
      }

   }

   public void onDisable() {
      if (this.gameOptions != null) {
         this.gameOptions.field_1904.method_23481(false);
      }

   }
}
