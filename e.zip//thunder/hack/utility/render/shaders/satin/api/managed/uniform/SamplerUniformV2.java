package thunder.hack.utility.render.shaders.satin.api.managed.uniform;

import java.util.function.IntSupplier;

public interface SamplerUniformV2 extends SamplerUniform {
   void set(IntSupplier var1);
}
