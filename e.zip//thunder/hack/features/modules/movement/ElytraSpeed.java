package thunder.hack.features.modules.movement;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_1802;
import net.minecraft.class_243;
import net.minecraft.class_2815;
import net.minecraft.class_2879;
import net.minecraft.class_2886;
import net.minecraft.class_2828.class_2829;
import thunder.hack.ThunderHack;
import thunder.hack.core.Managers;
import thunder.hack.events.impl.EventAttack;
import thunder.hack.events.impl.EventPlayerTravel;
import thunder.hack.features.modules.Module;
import thunder.hack.gui.notification.Notification;
import thunder.hack.setting.Setting;
import thunder.hack.utility.player.InventoryUtility;
import thunder.hack.utility.player.SearchInvResult;

public class ElytraSpeed extends Module {
   private final Setting<Integer> delay = new Setting("Delay", 500, 0, 1000);
   private final Setting<Boolean> log = new Setting("Log", false);
   private final Setting<ElytraSpeed.BypassMode> bypass;
   private final Setting<ElytraSpeed.DoubleTapMode> doubleTap;
   private final Setting<ElytraSpeed.SpeedMethod> speedMethod;
   private final Setting<Float> speedMultiplier;
   private final Setting<Float> maxSpeed;
   private final Setting<Float> minDistance;
   private final Setting<Boolean> useTimer;
   private final Setting<Float> timerSpeed;
   private final Setting<Boolean> autoDisable;
   private final Setting<Integer> disableTime;
   private final thunder.hack.utility.Timer autoDisableTimer;
   private final thunder.hack.utility.Timer fireworkTimer;

   public ElytraSpeed() {
      super("ElytraSpeed", Module.Category.MOVEMENT);
      this.bypass = new Setting("Bypass", ElytraSpeed.BypassMode.None);
      this.doubleTap = new Setting("DoubleTap", ElytraSpeed.DoubleTapMode.None);
      this.speedMethod = new Setting("Speed Method", ElytraSpeed.SpeedMethod.GRIM);
      this.speedMultiplier = new Setting("Speed Multiplier", 1.5F, 0.1F, 5.0F, (v) -> {
         return this.speedMethod.getValue() != ElytraSpeed.SpeedMethod.PACKET;
      });
      this.maxSpeed = new Setting("Max Speed", 5.0F, 0.1F, 20.0F, (v) -> {
         return this.speedMethod.getValue() == ElytraSpeed.SpeedMethod.CUSTOM;
      });
      this.minDistance = new Setting("Min Distance", 2.0F, 0.1F, 10.0F);
      this.useTimer = new Setting("Use Timer", false);
      this.timerSpeed = new Setting("Timer Speed", 1.0F, 0.1F, 10.0F, (v) -> {
         return (Boolean)this.useTimer.getValue();
      });
      this.autoDisable = new Setting("AutoDisable", true);
      this.disableTime = new Setting("Disable Time", 5, 1, 30);
      this.autoDisableTimer = new thunder.hack.utility.Timer();
      this.fireworkTimer = new thunder.hack.utility.Timer();
   }

   public void onEnable() {
      super.onEnable();
      if ((Boolean)this.autoDisable.getValue()) {
         this.autoDisableTimer.reset();
      }

   }

   @EventHandler
   public void onUpdate() {
      if ((Boolean)this.autoDisable.getValue() && this.autoDisableTimer.passedS((double)(Integer)this.disableTime.getValue())) {
         this.disable();
      }

      if (this.fireworkTimer.passedMs((long)(Integer)this.delay.getValue())) {
         if (this.doubleTap.getValue() == ElytraSpeed.DoubleTapMode.Auto && !this.hasMaxElytraSpeed()) {
            this.useDoubleFirework();
            this.logNotification("Double tap used", Notification.Type.SUCCESS);
         } else {
            this.useFirework();
         }

         this.fireworkTimer.reset();
      }
   }

   @EventHandler
   public void onPlayerAttack(EventAttack event) {
      if ((Boolean)this.autoDisable.getValue() && event.getEntity() instanceof class_1657) {
         this.disable();
      }

   }

   @EventHandler
   public void modifyVelocity(EventPlayerTravel e) {
      class_243 currentVelocity;
      if (this.speedMethod.getValue() == ElytraSpeed.SpeedMethod.GRIM) {
         if (this.bypass.getValue() == ElytraSpeed.BypassMode.Grim && !e.isPre() && ThunderHack.core.getSetBackTime() > 1000L && mc.field_1724.method_6128()) {
            currentVelocity = mc.field_1724.method_18798();
            class_243 motionVector = new class_243(currentVelocity.field_1352 * (double)(Float)this.speedMultiplier.getValue(), currentVelocity.field_1351, currentVelocity.field_1350 * (double)(Float)this.speedMultiplier.getValue());
            if (motionVector.method_1027() > (double)((Float)this.maxSpeed.getValue() * (Float)this.maxSpeed.getValue())) {
               double scaleFactor = (double)(Float)this.maxSpeed.getValue() / motionVector.method_1033();
               motionVector = new class_243(motionVector.field_1352 * scaleFactor, motionVector.field_1351, motionVector.field_1350 * scaleFactor);
            }

            mc.field_1724.method_18799(motionVector);
         }
      } else if (this.speedMethod.getValue() == ElytraSpeed.SpeedMethod.PACKET) {
         currentVelocity = new class_243(mc.field_1724.method_18798().field_1352 * (double)(Float)this.speedMultiplier.getValue(), mc.field_1724.method_18798().field_1351, mc.field_1724.method_18798().field_1350 * (double)(Float)this.speedMultiplier.getValue());
         mc.field_1724.method_18799(currentVelocity);
         this.sendVelocityPacket(currentVelocity);
      } else if (this.speedMethod.getValue() == ElytraSpeed.SpeedMethod.CUSTOM) {
         currentVelocity = mc.field_1724.method_18798();
         double currentSpeed = Math.sqrt(currentVelocity.field_1352 * currentVelocity.field_1352 + currentVelocity.field_1350 * currentVelocity.field_1350);
         if (currentSpeed > (double)(Float)this.maxSpeed.getValue()) {
            double scaleFactor = (double)(Float)this.maxSpeed.getValue() / currentSpeed;
            currentVelocity = new class_243(currentVelocity.field_1352 * scaleFactor, currentVelocity.field_1351, currentVelocity.field_1350 * scaleFactor);
            this.logNotification("Speed capped to Max Speed", Notification.Type.WARNING);
         } else {
            currentVelocity = new class_243(currentVelocity.field_1352 * (double)(Float)this.speedMultiplier.getValue(), currentVelocity.field_1351, currentVelocity.field_1350 * (double)(Float)this.speedMultiplier.getValue());
         }

         mc.field_1724.method_18799(currentVelocity);
      }

      if ((Boolean)this.useTimer.getValue()) {
         ThunderHack.TICK_TIMER = (Float)this.timerSpeed.getValue();
      }

   }

   private boolean hasMaxElytraSpeed() {
      double speed = Math.sqrt(mc.field_1724.method_18798().field_1352 * mc.field_1724.method_18798().field_1352 + mc.field_1724.method_18798().field_1350 * mc.field_1724.method_18798().field_1350);
      return speed >= 33.5D;
   }

   private void useDoubleFirework() {
      this.useFirework();

      try {
         Thread.sleep(10L);
      } catch (InterruptedException var2) {
         var2.printStackTrace();
      }

      this.useFirework();
   }

   private void useFirework() {
      SearchInvResult hotbarFirework = InventoryUtility.findItemInHotBar(class_1802.field_8639);
      SearchInvResult inventoryFirework = InventoryUtility.findItemInInventory(class_1802.field_8639);
      InventoryUtility.saveSlot();
      if (hotbarFirework.found()) {
         hotbarFirework.switchTo();
      } else {
         if (!inventoryFirework.found()) {
            this.logNotification("No fireworks found!", Notification.Type.ERROR);
            return;
         }

         mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, inventoryFirework.slot(), mc.field_1724.method_31548().field_7545, class_1713.field_7791, mc.field_1724);
         this.sendPacket(new class_2815(mc.field_1724.field_7512.field_7763));
      }

      this.sendSequencedPacket((id) -> {
         return new class_2886(class_1268.field_5808, id, mc.field_1724.method_36454(), mc.field_1724.method_36455());
      });
      this.sendPacket(new class_2879(class_1268.field_5808));
      InventoryUtility.returnSlot();
      if (!hotbarFirework.found() && inventoryFirework.found()) {
         mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, inventoryFirework.slot(), mc.field_1724.method_31548().field_7545, class_1713.field_7791, mc.field_1724);
         this.sendPacket(new class_2815(mc.field_1724.field_7512.field_7763));
      }

   }

   private void sendVelocityPacket(class_243 velocity) {
      mc.method_1562().method_52787(new class_2829(mc.field_1724.method_23317() + velocity.field_1352, mc.field_1724.method_23318(), mc.field_1724.method_23321() + velocity.field_1350, mc.field_1724.method_24828()));
   }

   public void onDisable() {
      if ((Boolean)this.useTimer.getValue()) {
         ThunderHack.TICK_TIMER = 1.0F;
      }

   }

   private void logNotification(String message, Notification.Type type) {
      if ((Boolean)this.log.getValue()) {
         Managers.NOTIFICATION.publicity("ElytraSpeed", message, 1, type);
      }

   }

   public static enum BypassMode {
      None,
      Grim;

      // $FF: synthetic method
      private static ElytraSpeed.BypassMode[] $values() {
         return new ElytraSpeed.BypassMode[]{None, Grim};
      }
   }

   public static enum DoubleTapMode {
      None,
      Auto;

      // $FF: synthetic method
      private static ElytraSpeed.DoubleTapMode[] $values() {
         return new ElytraSpeed.DoubleTapMode[]{None, Auto};
      }
   }

   public static enum SpeedMethod {
      PACKET,
      GRIM,
      CUSTOM;

      // $FF: synthetic method
      private static ElytraSpeed.SpeedMethod[] $values() {
         return new ElytraSpeed.SpeedMethod[]{PACKET, GRIM, CUSTOM};
      }
   }
}
