package thunder.hack.features.modules.player;

import thunder.hack.features.modules.Module;

public class PortalInventory extends Module {
   public PortalInventory() {
      super("PortalInventory", Module.Category.PLAYER);
   }
}
