package thunder.hack.utility;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicReference;
import java.util.jar.Manifest;
import net.fabricmc.loader.api.metadata.Person;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_1060;
import net.minecraft.class_2960;
import net.minecraft.class_634;
import org.jetbrains.annotations.NotNull;
import thunder.hack.ThunderHack;
import thunder.hack.core.manager.client.ConfigManager;
import thunder.hack.features.modules.Module;
import thunder.hack.utility.math.MathUtility;

public final class ThunderUtility {
   public static List<String> changeLog = new ArrayList();
   public static List<String> starGazer = new ArrayList();

   @NotNull
   public static String getAuthors() {
      List<String> names = ThunderHack.MOD_META.getAuthors().stream().map(Person::getName).toList();
      return String.join(", ", names);
   }

   public static String solveName(String notSolved) {
      AtomicReference<String> mb = new AtomicReference("FATAL ERROR");
      ((class_634)Objects.requireNonNull(Module.mc.method_1562())).method_45732().forEach((player) -> {
         if (notSolved.contains(player.method_2966().getName())) {
            mb.set(player.method_2966().getName());
         }

      });
      return (String)mb.get();
   }

   public static class_2960 getCustomImg(String name) throws IOException {
      class_1060 var10000 = Module.mc.method_1531();
      String var10001 = "th-" + name + "-" + (int)MathUtility.random(0.0F, 1000.0F);
      String var10006 = String.valueOf(ConfigManager.IMAGES_FOLDER);
      return var10000.method_4617(var10001, new class_1043(class_1011.method_4309(new FileInputStream(var10006 + "/" + name + ".png"))));
   }

   public static void syncVersion() {
      try {
         if (!(new BufferedReader(new InputStreamReader((new URL("https://pastebin.com/raw/RnmVPCmW")).openStream()))).readLine().equals("7")) {
            ThunderHack.isOutdated = true;
         }
      } catch (Exception var1) {
      }

   }

   public static void syncContributors() {
      try {
         URL list = new URL("https://pastebin.com/raw/AByKnyxM");
         BufferedReader in = new BufferedReader(new InputStreamReader(list.openStream(), StandardCharsets.UTF_8));

         String inputLine;
         for(int i = 0; (inputLine = in.readLine()) != null; ++i) {
            ThunderHack.contributors[i] = inputLine.trim();
         }

         in.close();
      } catch (Exception var4) {
         var4.printStackTrace();
      }

   }

   public static String readManifestField(String fieldName) {
      try {
         Enumeration en = Thread.currentThread().getContextClassLoader().getResources("META-INF/MANIFEST.MF");

         while(en.hasMoreElements()) {
            try {
               URL url = (URL)en.nextElement();
               InputStream is = url.openStream();
               if (is != null) {
                  String s = (new Manifest(is)).getMainAttributes().getValue(fieldName);
                  if (s != null) {
                     return s;
                  }
               }
            } catch (Exception var5) {
            }
         }
      } catch (Exception var6) {
      }

      return "0";
   }
}
