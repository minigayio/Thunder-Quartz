package thunder.hack.features.modules.movement;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2828.class_2829;
import thunder.hack.ThunderHack;
import thunder.hack.events.impl.EventMove;
import thunder.hack.features.modules.Module;
import thunder.hack.setting.Setting;

public class AntiVoid extends Module {
   private static final Setting<AntiVoid.Mode> mode;
   private final Setting<Boolean> sendPacket = new Setting("SendPacket", true, (v) -> {
      return mode.getValue() == AntiVoid.Mode.NCP;
   });
   private static final Setting<AntiVoid.ExtraMode> extraMode;
   boolean timerFlag;

   public AntiVoid() {
      super("AntiVoid", Module.Category.MOVEMENT);
   }

   public void onDisable() {
      if (this.timerFlag) {
         ThunderHack.TICK_TIMER = 1.0F;
      }

   }

   @EventHandler(
      priority = -200
   )
   public void onMove(EventMove e) {
      if (!fullNullCheck()) {
         if (this.shouldTriggerProtection()) {
            if (mode.getValue() == AntiVoid.Mode.NCP) {
               e.cancel();
               e.setY(0.0D);
               if ((Boolean)this.sendPacket.getValue()) {
                  this.sendPacket(new class_2829(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321(), true));
               }
            } else {
               ThunderHack.TICK_TIMER = 0.2F;
               this.timerFlag = true;
            }
         } else if (this.timerFlag) {
            ThunderHack.TICK_TIMER = 1.0F;
            this.timerFlag = false;
         }

      }
   }

   private boolean shouldTriggerProtection() {
      AntiVoid.ExtraMode currentExtraMode = (AntiVoid.ExtraMode)extraMode.getValue();
      boolean isFallingToVoid = this.fallingToVoid();
      boolean isDangerAboveLava = this.dangerAboveLava();
      return currentExtraMode == AntiVoid.ExtraMode.Both && (isFallingToVoid || isDangerAboveLava) || currentExtraMode == AntiVoid.ExtraMode.Lava && isDangerAboveLava || currentExtraMode == AntiVoid.ExtraMode.Death && isFallingToVoid;
   }

   private boolean fallingToVoid() {
      for(int i = (int)mc.field_1724.method_23318() - 1; i >= -64; --i) {
         class_2338 pos = class_2338.method_49637(mc.field_1724.method_23317(), (double)i, mc.field_1724.method_23321());
         if (!mc.field_1687.method_22347(pos)) {
            return false;
         }
      }

      return mc.field_1724.field_6017 > 10.0F;
   }

   private boolean dangerAboveLava() {
      for(int i = 1; i <= 5; ++i) {
         class_2338 pos = class_2338.method_49637(mc.field_1724.method_23317(), mc.field_1724.method_23318() - (double)i, mc.field_1724.method_23321());
         if (mc.field_1687.method_8320(pos).method_27852(class_2246.field_10164)) {
            return true;
         }

         if (!mc.field_1687.method_22347(pos)) {
            return false;
         }
      }

      return false;
   }

   static {
      mode = new Setting("Mode", AntiVoid.Mode.NCP);
      extraMode = new Setting("Lava/Death", AntiVoid.ExtraMode.Disabled);
   }

   private static enum Mode {
      NCP,
      Timer;

      // $FF: synthetic method
      private static AntiVoid.Mode[] $values() {
         return new AntiVoid.Mode[]{NCP, Timer};
      }
   }

   private static enum ExtraMode {
      Disabled,
      Lava,
      Death,
      Both;

      // $FF: synthetic method
      private static AntiVoid.ExtraMode[] $values() {
         return new AntiVoid.ExtraMode[]{Disabled, Lava, Death, Both};
      }
   }
}
