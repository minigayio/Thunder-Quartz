package thunder.hack.features.modules.player;

import java.util.LinkedList;
import java.util.Queue;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2596;
import net.minecraft.class_7439;
import thunder.hack.events.impl.PacketEvent;
import thunder.hack.features.modules.Module;
import thunder.hack.utility.Timer;

public class AutoGG extends Module {
   private final Timer timer = new Timer();
   private final Queue<String> recentMessages = new LinkedList();
   private boolean waitingMode = false;

   public AutoGG() {
      super("AutoGG", Module.Category.PLAYER);
   }

   public void onEnable() {
      this.recentMessages.clear();
      this.waitingMode = false;
      this.timer.reset();
   }

   @EventHandler
   public void onPacketReceive(PacketEvent.Receive event) {
      if (!fullNullCheck()) {
         class_2596 var3 = event.getPacket();
         if (var3 instanceof class_7439) {
            class_7439 packet = (class_7439)var3;
            String messageText = packet.comp_763().getString();
            String cleanText = messageText.replaceAll("§[0-9a-fk-or]", "");
            this.recentMessages.offer(cleanText);
            if (this.recentMessages.size() > 6) {
               this.recentMessages.poll();
            }

            if (!this.waitingMode && this.containsGameEnd(cleanText)) {
               mc.field_1724.field_3944.method_45729("gg");
               this.waitingMode = true;
               this.timer.reset();
            }
         }

      }
   }

   public void onUpdate() {
      if (this.waitingMode && this.timer.passedS(20.0D)) {
         this.waitingMode = false;
      }

   }

   private boolean containsGameEnd(String message) {
      String lowerMessage = message.toLowerCase();
      return lowerMessage.contains("you got:") || lowerMessage.contains("thank you for playing") || lowerMessage.contains("game length:");
   }
}
