package thunder.hack.features.modules.combat;

import java.util.Random;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_239;
import net.minecraft.class_310;
import net.minecraft.class_3966;
import thunder.hack.events.impl.EventTick;
import thunder.hack.features.modules.Module;
import thunder.hack.setting.Setting;

public class AutoClicker extends Module {
   private final Setting<Integer> minCPS = new Setting("Min CPS", 8, 0, 20);
   private final Setting<Integer> maxCPS = new Setting("Max CPS", 17, 0, 20);
   private final Setting<Boolean> onlyClick = new Setting("Only Click", true);
   private final Random random = new Random();
   private long nextClick;
   private long lastClick;

   public AutoClicker() {
      super("AutoClicker", Module.Category.COMBAT);
   }

   @EventHandler
   public void onTick(EventTick event) {
      class_310 mc = class_310.method_1551();
      if (mc.field_1724 != null && mc.field_1755 == null) {
         boolean isClicking = mc.field_1690.field_1886.method_1434();
         if (!(Boolean)this.onlyClick.getValue() || isClicking) {
            if (System.currentTimeMillis() - this.lastClick >= this.nextClick) {
               this.performClick(mc);
               this.lastClick = System.currentTimeMillis();
               this.nextClick = this.calculateNextClickDelay();
            }

         }
      }
   }

   private void performClick(class_310 mc) {
      class_239 hitResult = mc.field_1765;
      if (hitResult instanceof class_3966) {
         class_3966 entityHitResult = (class_3966)hitResult;
         mc.field_1761.method_2918(mc.field_1724, entityHitResult.method_17782());
         mc.field_1724.method_6104(mc.field_1724.method_6058());
      }

   }

   private long calculateNextClickDelay() {
      int minDelay = 1000 / (Integer)this.maxCPS.getValue();
      int maxDelay = 1000 / (Integer)this.minCPS.getValue();
      return (long)(this.random.nextInt(maxDelay - minDelay + 1) + minDelay);
   }
}
