package thunder.hack.features.modules.misc;

import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import thunder.hack.features.modules.Module;
import thunder.hack.setting.Setting;

public class AntiTooManyPacket extends Module {
   public final Setting<Integer> maxPacketsPerTick = new Setting("MaxPacketsPerTick", 10, 1, 100);
   public final Setting<Boolean> debug = new Setting("Debug", false);
   private int packetCount = 0;

   public AntiTooManyPacket() {
      super("AntiTooManyPacket", Module.Category.MISC);
   }

   public void onEnable() {
      this.packetCount = 0;
   }

   public void onDisable() {
      this.packetCount = 0;
   }

   public void onUpdate() {
      if (this.packetCount > (Integer)this.maxPacketsPerTick.getValue()) {
         mc.field_1705.method_1743().method_1812(class_2561.method_43470("AntiPacket > Too many packets detected!").method_27692(class_124.field_1061));
      }

      if ((Boolean)this.debug.getValue()) {
         mc.field_1705.method_1743().method_1812(class_2561.method_43470("AntiPacket Debug > Packets this tick: " + this.packetCount).method_27692(class_124.field_1080));
      }

      this.packetCount = 0;
   }

   public void sendPacket(class_2596<?> packet) {
      ++this.packetCount;
      if (this.packetCount <= (Integer)this.maxPacketsPerTick.getValue()) {
         super.sendPacket(packet);
      } else if ((Boolean)this.debug.getValue()) {
         mc.field_1705.method_1743().method_1812(class_2561.method_43470("AntiPacket Debug > Packet blocked due to limit").method_27692(class_124.field_1054));
      }

   }
}
