package thunder.hack.utility.interfaces;

public interface ICrystal {
   boolean canAttack();

   void attack();
}
