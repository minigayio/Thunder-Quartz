package thunder.hack.features.modules.player;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2815;
import thunder.hack.events.impl.PacketEvent;
import thunder.hack.features.modules.Module;

public class XCarry extends Module {
   public XCarry() {
      super("XCarry", Module.Category.PLAYER);
   }

   @EventHandler
   public void onPacketSend(PacketEvent.Send e) {
      if (e.getPacket() instanceof class_2815) {
         e.cancel();
      }

   }
}
