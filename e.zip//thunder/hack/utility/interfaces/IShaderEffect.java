package thunder.hack.utility.interfaces;

import net.minecraft.class_276;

public interface IShaderEffect {
   void addFakeTargetHook(String var1, class_276 var2);
}
