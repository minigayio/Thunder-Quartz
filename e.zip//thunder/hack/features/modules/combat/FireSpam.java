package thunder.hack.features.modules.combat;

import java.util.Random;
import net.minecraft.class_1268;
import net.minecraft.class_1713;
import net.minecraft.class_1802;
import net.minecraft.class_243;
import net.minecraft.class_2815;
import net.minecraft.class_2879;
import net.minecraft.class_2886;
import thunder.hack.core.Managers;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.features.modules.Module;
import thunder.hack.gui.notification.Notification;
import thunder.hack.setting.Setting;
import thunder.hack.utility.Timer;
import thunder.hack.utility.player.InventoryUtility;
import thunder.hack.utility.player.SearchInvResult;

public class FireSpam extends Module {
   private final Setting<Integer> delay = new Setting("Delay", 500, -1, 2000);
   private final Setting<Boolean> synchAura = new Setting("SynchAura", false);
   private final Timer fireworkTimer = new Timer();
   private final Random random = new Random();

   public FireSpam() {
      super("FireSpam", Module.Category.COMBAT);
   }

   public void onUpdate() {
      if (!(Boolean)this.synchAura.getValue() || !this.isAuraHittingSoon()) {
         if (this.fireworkTimer.passedMs((long)this.getDelayValue())) {
            this.useFirework();
            this.fireworkTimer.reset();
         }
      }
   }

   private int getDelayValue() {
      if ((Integer)this.delay.getValue() == -1) {
         int randomValue = this.random.nextInt(100);
         if (randomValue < 50) {
            return 700 + this.random.nextInt(201);
         } else {
            return randomValue < 80 ? 900 + this.random.nextInt(101) : 50 + this.random.nextInt(650);
         }
      } else {
         return (Integer)this.delay.getValue();
      }
   }

   private void useFirework() {
      SearchInvResult hotbarFireWorkResult = InventoryUtility.findItemInHotBar(class_1802.field_8639);
      SearchInvResult fireWorkResult = InventoryUtility.findItemInInventory(class_1802.field_8639);
      InventoryUtility.saveSlot();
      if (hotbarFireWorkResult.found()) {
         hotbarFireWorkResult.switchTo();
      } else {
         if (!fireWorkResult.found()) {
            this.logNotification("No fireworks available!", Notification.Type.ERROR);
            return;
         }

         mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, fireWorkResult.slot(), mc.field_1724.method_31548().field_7545, class_1713.field_7791, mc.field_1724);
         this.sendPacket(new class_2815(mc.field_1724.field_7512.field_7763));
      }

      this.sendSequencedPacket((id) -> {
         return new class_2886(class_1268.field_5808, id, mc.field_1724.method_36454(), mc.field_1724.method_36455());
      });
      this.sendPacket(new class_2879(class_1268.field_5808));
      InventoryUtility.returnSlot();
      if (!hotbarFireWorkResult.found() && fireWorkResult.found()) {
         mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, fireWorkResult.slot(), mc.field_1724.method_31548().field_7545, class_1713.field_7791, mc.field_1724);
         this.sendPacket(new class_2815(mc.field_1724.field_7512.field_7763));
      }

   }

   private boolean isAuraHittingSoon() {
      if (ModuleManager.aura.isEnabled() && Aura.target != null) {
         double distanceToTarget = mc.field_1724.method_19538().method_1022(Aura.target.method_19538());
         if (distanceToTarget <= (double)(Float)ModuleManager.aura.attackRange.getValue()) {
            return true;
         }

         if (Aura.target.method_18798().method_1027() > 0.0D) {
            class_243 predictedPosition = Aura.target.method_19538().method_1019(Aura.target.method_18798().method_1021(1.5D));
            if (mc.field_1724.method_19538().method_1022(predictedPosition) <= (double)(Float)ModuleManager.aura.attackRange.getValue()) {
               return true;
            }
         }

         if ((Integer)ModuleManager.aura.minCPS.getValue() > 0 && (Integer)ModuleManager.aura.maxCPS.getValue() > 0) {
            int averageCPS = ((Integer)ModuleManager.aura.minCPS.getValue() + (Integer)ModuleManager.aura.maxCPS.getValue()) / 2;
            double attackDelay = 1000.0D / (double)averageCPS;
            if (mc.field_1724.field_6012 % (int)attackDelay == 0) {
               return true;
            }
         }
      }

      return false;
   }

   private void logNotification(String message, Notification.Type type) {
      Managers.NOTIFICATION.publicity("FireSpam", message, 2, type);
   }
}
