package thunder.hack.features.modules.client;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import thunder.hack.features.modules.Module;
import thunder.hack.setting.Setting;

public class PlayerOnlineList extends Module {
   public static List<PlayerOnlineList.PlayerInfo> onlinePlayers = new ArrayList();
   public static int totalPlayers = 0;
   public static Setting<Boolean> hideInPlayerList = new Setting("HideInPlayerList", false);

   public PlayerOnlineList() {
      super("PlayerOnlineList", Module.Category.CLIENT);
   }

   public void onEnable() {
      fetchOnlinePlayers();
      class_310 client = class_310.method_1551();
      if (client.field_1724 != null) {
         if (onlinePlayers.isEmpty()) {
            client.field_1724.method_7353(class_2561.method_43470("No players online.").method_27692(class_124.field_1061), false);
         } else {
            client.field_1724.method_7353(class_2561.method_43470("=-=-=-=-=-=-=").method_27692(class_124.field_1064).method_10852(class_2561.method_43470(" Exploit Core ").method_27692(class_124.field_1076)).method_10852(class_2561.method_43470("=-=-=-=-=-=-=").method_27692(class_124.field_1064)), false);
            Iterator var2 = onlinePlayers.iterator();

            while(var2.hasNext()) {
               PlayerOnlineList.PlayerInfo player = (PlayerOnlineList.PlayerInfo)var2.next();
               client.field_1724.method_7353(class_2561.method_43470(" | ").method_27692(class_124.field_1060).method_10852(class_2561.method_43470("Nick: ").method_27692(class_124.field_1068)).method_10852(class_2561.method_43470(maskNick(player.nick)).method_27692(class_124.field_1060)).method_10852(class_2561.method_43470(", ").method_27692(class_124.field_1068)).method_10852(class_2561.method_43470("Server: ").method_27692(class_124.field_1068)).method_10852(class_2561.method_43470(player.server).method_27692(class_124.field_1060)).method_10852(class_2561.method_43470(", ").method_27692(class_124.field_1068)).method_10852(class_2561.method_43470("Config: ").method_27692(class_124.field_1068)).method_10852(class_2561.method_43470(player.config).method_27692(class_124.field_1060)), false);
            }

            client.field_1724.method_7353(class_2561.method_43470("").method_27692(class_124.field_1070), false);
            client.field_1724.method_7353(class_2561.method_43470("").method_10852(class_2561.method_43470("              ").method_27692(class_124.field_1070)).method_10852(class_2561.method_43470("Online: ").method_27692(class_124.field_1060)).method_10852(class_2561.method_43470(String.valueOf(totalPlayers)).method_27692(class_124.field_1077)), false);
            client.field_1724.method_7353(class_2561.method_43470("").method_27692(class_124.field_1070), false);
            client.field_1724.method_7353(class_2561.method_43470("=-=-=-=-=-=-=").method_27692(class_124.field_1064).method_10852(class_2561.method_43470(" Exploit Core ").method_27692(class_124.field_1076)).method_10852(class_2561.method_43470("=-=-=-=-=-=-=").method_27692(class_124.field_1064)), false);
         }
      }

      this.disable();
   }

   public static void fetchOnlinePlayers() {
      try {
         URL url = new URL("https://plagai.org/apimimi/api?viev");
         HttpURLConnection connection = (HttpURLConnection)url.openConnection();
         connection.setRequestMethod("GET");
         connection.setConnectTimeout(5000);
         connection.setReadTimeout(5000);
         InputStreamReader reader = new InputStreamReader(connection.getInputStream());
         JsonObject response = JsonParser.parseReader(reader).getAsJsonObject();
         if (response.get("status").getAsString().equals("success")) {
            onlinePlayers.clear();
            totalPlayers = response.get("total_players").getAsInt();
            response.getAsJsonArray("users").forEach((element) -> {
               JsonObject user = element.getAsJsonObject();
               String nick = user.get("nick").getAsString();
               String server = user.get("server").getAsString();
               String config = user.get("config").getAsString();
               long timestamp = user.get("timestamp").getAsLong();
               onlinePlayers.add(new PlayerOnlineList.PlayerInfo(nick, server, config, timestamp));
            });
         }
      } catch (Exception var4) {
         var4.printStackTrace();
      }

   }

   private static String maskNick(String nick) {
      return nick != null && !nick.isEmpty() ? nick.charAt(0) + "*****" : "*****";
   }

   public static class PlayerInfo {
      public String nick;
      public String server;
      public String config;
      public long timestamp;

      public PlayerInfo(String nick, String server, String config, long timestamp) {
         this.nick = nick;
         this.server = server;
         this.config = config;
         this.timestamp = timestamp;
      }
   }
}
