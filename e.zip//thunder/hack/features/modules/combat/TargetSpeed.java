package thunder.hack.features.modules.combat;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.events.impl.EventMove;
import thunder.hack.events.impl.EventSync;
import thunder.hack.features.modules.Module;
import thunder.hack.setting.Setting;
import thunder.hack.utility.player.MovementUtility;

public class TargetSpeed extends Module {
   public Setting<Boolean> autoJump = new Setting("AutoJump", true);
   public Setting<Float> distance = new Setting("Distance", 1.3F, 0.2F, 7.0F);
   public Setting<Float> circleSpeed = new Setting("CircleSpeed", 0.15F, 0.05F, 0.5F);
   private static TargetSpeed instance;

   public TargetSpeed() {
      super("TargetHelper", Module.Category.COMBAT);
      instance = this;
   }

   public static TargetSpeed getInstance() {
      return instance;
   }

   @EventHandler
   public void onMove(EventMove event) {
      if (this.canMove()) {
         class_1309 target = this.getTarget();
         if (target != null) {
            if (MovementUtility.isMoving()) {
               double speedMultiplier = 1.0D;
               if (mc.field_1724.method_5858(target) > (double)((Float)this.distance.getValue() * (Float)this.distance.getValue())) {
                  speedMultiplier = 1.15D;
               } else if (mc.field_1724.method_5858(target) < ((double)(Float)this.distance.getValue() - 0.5D) * ((double)(Float)this.distance.getValue() - 0.5D)) {
                  speedMultiplier = 0.85D;
               }

               double dx = target.method_23317() - mc.field_1724.method_23317();
               double dz = target.method_23321() - mc.field_1724.method_23321();
               double angle = Math.atan2(dz, dx);
               if (mc.field_1690.field_1913.method_1434()) {
                  --angle;
               } else if (mc.field_1690.field_1849.method_1434()) {
                  ++angle;
               }

               double moveX = Math.cos(angle) * (double)(Float)this.circleSpeed.getValue() * speedMultiplier;
               double moveZ = Math.sin(angle) * (double)(Float)this.circleSpeed.getValue() * speedMultiplier;
               double[] moveArray = MovementUtility.forward(0.1D * speedMultiplier);
               class_243 moveVec = new class_243(moveArray[0] + moveX, 0.0D, moveArray[1] + moveZ);
               event.setX(moveVec.field_1352);
               event.setZ(moveVec.field_1350);
            }
         }
      }
   }

   @EventHandler
   public void updateValues(EventSync e) {
      if (mc.field_1724.method_24828() && (Boolean)this.autoJump.getValue() && this.getTarget() != null) {
         mc.field_1724.method_6043();
      }

   }

   private boolean canMove() {
      return mc.field_1724 != null && !mc.field_1724.method_5715() && MovementUtility.isMoving();
   }

   private class_1309 getTarget() {
      if (ModuleManager.aura.isEnabled()) {
         Aura var10000 = ModuleManager.aura;
         class_1297 target = Aura.target;
         if (target instanceof class_1309) {
            return (class_1309)target;
         }
      }

      return null;
   }
}
