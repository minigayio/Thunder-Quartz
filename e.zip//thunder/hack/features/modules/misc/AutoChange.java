package thunder.hack.features.modules.misc;

import java.util.Arrays;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1713;
import net.minecraft.class_1714;
import net.minecraft.class_1723;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_746;
import thunder.hack.core.Managers;
import thunder.hack.features.modules.Module;
import thunder.hack.gui.notification.Notification;
import thunder.hack.setting.Setting;
import thunder.hack.utility.Timer;
import thunder.hack.utility.player.MovementUtility;

public class AutoChange extends Module {
   private final Setting<Boolean> requireOpenEq = new Setting("RequireOpenEQ", true);
   private final Setting<Integer> delay = new Setting("Delay", 100, 0, 1000);
   private final Setting<Boolean> requireStill = new Setting("RequireStill", true);
   private final Setting<Boolean> debug = new Setting("Debug", true);
   private final Timer timer = new Timer();
   private final Timer debugTimer = new Timer();
   private static final List<class_1792> WOOD_LOGS;

   public AutoChange() {
      super("AutoChange", Module.Category.MISC);
   }

   public void onUpdate() {
      if (!fullNullCheck()) {
         boolean isCraftingScreen = mc.field_1724.field_7512 instanceof class_1714;
         boolean isPlayerScreen = mc.field_1724.field_7512 instanceof class_1723;
         if (!(Boolean)this.requireOpenEq.getValue() || isCraftingScreen || isPlayerScreen) {
            if (!(Boolean)this.requireStill.getValue() || !MovementUtility.isMoving()) {
               if (this.timer.every((long)(Integer)this.delay.getValue())) {
                  if (isCraftingScreen || isPlayerScreen) {
                     if (mc.field_1724.field_7512.method_7611(0).method_7681()) {
                        try {
                           mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, 0, 0, class_1713.field_7794, mc.field_1724);
                           Managers.NOTIFICATION.publicity("", "Drewno przerobione!", 5, Notification.Type.WARNING);
                           return;
                        } catch (Exception var10) {
                        }
                     }

                     int craftingStartSlot = 1;
                     int craftingEndSlot = 5;
                     if (isCraftingScreen) {
                        craftingStartSlot = 1;
                        craftingEndSlot = 10;
                     }

                     int woodSlotInInventory = this.findWoodInInventory();
                     if (woodSlotInInventory != -1) {
                        int emptyCraftingSlot = this.findEmptyCraftingSlot(craftingStartSlot, craftingEndSlot);
                        if (emptyCraftingSlot != -1) {
                           if ((Boolean)this.debug.getValue()) {
                              class_1792 woodItem = mc.field_1724.method_31548().method_5438(woodSlotInInventory).method_7909();
                              this.sendDebugMessage("Przenoszę drewno ze slotu " + woodSlotInInventory + " do crafting slotu " + emptyCraftingSlot + ": " + woodItem.toString());
                           }

                           int inventorySlotId = woodSlotInInventory < 9 ? 36 + woodSlotInInventory : woodSlotInInventory;

                           try {
                              mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, inventorySlotId, 0, class_1713.field_7790, mc.field_1724);
                              mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, emptyCraftingSlot, 0, class_1713.field_7790, mc.field_1724);
                              mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, inventorySlotId, 0, class_1713.field_7790, mc.field_1724);
                              if ((Boolean)this.debug.getValue()) {
                                 this.sendDebugMessage("Przeniesiono drewno do crafting slotu!");
                              }
                           } catch (Exception var9) {
                              if ((Boolean)this.debug.getValue()) {
                                 this.sendDebugMessage("Błąd przy przenoszeniu: " + var9.getMessage());
                              }
                           }
                        } else if ((Boolean)this.debug.getValue() && this.debugTimer.every(3000L)) {
                           this.sendDebugMessage("Brak wolnych slotów w craftingu!");
                        }
                     } else if ((Boolean)this.debug.getValue() && this.debugTimer.every(3000L)) {
                        this.sendDebugMessage("Brak drewna w inventory!");
                     }
                  }

               }
            }
         }
      }
   }

   private int findWoodInInventory() {
      for(int i = 0; i < 36; ++i) {
         if (!mc.field_1724.method_31548().method_5438(i).method_7960()) {
            class_1792 item = mc.field_1724.method_31548().method_5438(i).method_7909();
            if (WOOD_LOGS.contains(item)) {
               return i;
            }
         }
      }

      return -1;
   }

   private int findEmptyCraftingSlot(int startSlot, int endSlot) {
      for(int i = startSlot; i < endSlot; ++i) {
         if (!mc.field_1724.field_7512.method_7611(i).method_7681()) {
            return i;
         }
      }

      return -1;
   }

   private void sendDebugMessage(String message) {
      if (mc.field_1724 != null) {
         class_746 var10000 = mc.field_1724;
         String var10001 = String.valueOf(class_124.field_1078);
         var10000.method_7353(class_2561.method_43470("[" + var10001 + "AutoChange" + String.valueOf(class_124.field_1070) + "] " + message), false);
      }

   }

   static {
      WOOD_LOGS = Arrays.asList(class_1802.field_8583, class_1802.field_8684, class_1802.field_8170, class_1802.field_8125, class_1802.field_8820, class_1802.field_8652, class_1802.field_37512, class_1802.field_42692, class_1802.field_21981, class_1802.field_21982, class_1802.field_8415, class_1802.field_8624, class_1802.field_8767, class_1802.field_8334, class_1802.field_8072, class_1802.field_8808, class_1802.field_37515, class_1802.field_42693, class_1802.field_21983, class_1802.field_21984, class_1802.field_8888, class_1802.field_8210, class_1802.field_8201, class_1802.field_8439, class_1802.field_8587, class_1802.field_8458, class_1802.field_37510, class_1802.field_42691, class_1802.field_22489, class_1802.field_22490, class_1802.field_8248, class_1802.field_8362, class_1802.field_8472, class_1802.field_8785, class_1802.field_8284, class_1802.field_8219, class_1802.field_37509, class_1802.field_42690, class_1802.field_22487, class_1802.field_22488);
   }
}
