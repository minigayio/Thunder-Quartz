package thunder.hack.features.modules.misc;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1802;
import net.minecraft.class_746;
import thunder.hack.events.impl.EventTick;
import thunder.hack.features.modules.Module;

public class FastTrident extends Module {
   public FastTrident() {
      super("FastTrident", Module.Category.MISC);
   }

   @EventHandler
   public void onTick(EventTick event) {
      class_746 player = mc.field_1724;
      if (player != null && player.method_6047().method_7909() == class_1802.field_8547) {
         if (player.method_6115() && player.method_6058() == class_1268.field_5808 && player.method_6048() >= 10) {
            player.method_6075();
         }

      }
   }
}
