package thunder.hack.features.modules.client;

import meteordevelopment.orbit.EventHandler;
import org.jetbrains.annotations.NotNull;
import thunder.hack.core.Managers;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.events.impl.EventAttack;
import thunder.hack.events.impl.EventDeath;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.combat.Aura;
import thunder.hack.features.modules.combat.AutoCrystal;
import thunder.hack.setting.Setting;

public final class SoundFX extends Module {
   public final Setting<Integer> volume = new Setting("Volume", 100, 0, 100);
   public final Setting<SoundFX.OnOffSound> enableMode;
   public final Setting<SoundFX.OnOffSound> disableMode;
   public final Setting<SoundFX.HitSound> hitSound;
   public final Setting<Boolean> critSound;
   public final Setting<SoundFX.KillSound> killSound;
   public final Setting<SoundFX.ScrollSound> scrollSound;

   public SoundFX() {
      super("SoundFX", Module.Category.CLIENT);
      this.enableMode = new Setting("EnableMode", SoundFX.OnOffSound.Inertia);
      this.disableMode = new Setting("DisableMode", SoundFX.OnOffSound.Inertia);
      this.hitSound = new Setting("HitSound", SoundFX.HitSound.OFF);
      this.critSound = new Setting("CritSound", false);
      this.killSound = new Setting("KillSound", SoundFX.KillSound.OFF);
      this.scrollSound = new Setting("ScrollSound", SoundFX.ScrollSound.KeyBoard);
   }

   @EventHandler
   public void onAttack(@NotNull EventAttack event) {
      if (!event.isPre()) {
         boolean isCrit = (Boolean)this.critSound.getValue() && (mc.field_1724.field_6017 > 0.0F || ModuleManager.criticals.isEnabled());
         if (isCrit) {
            Managers.SOUND.playCritSound();
         } else {
            Managers.SOUND.playHitSound((SoundFX.HitSound)this.hitSound.getValue());
         }
      }

   }

   @EventHandler
   public void onDeath(EventDeath e) {
      if (Aura.target != null && Aura.target == e.getPlayer() && this.killSound.is(SoundFX.KillSound.Custom)) {
         Managers.SOUND.playSound("kill");
      } else {
         if (AutoCrystal.target != null && AutoCrystal.target == e.getPlayer() && this.killSound.is(SoundFX.KillSound.Custom)) {
            Managers.SOUND.playSound("kill");
         }

      }
   }

   public static enum OnOffSound {
      Custom,
      Inertia,
      Enable1,
      Enable2,
      Enable3,
      Enable4,
      Disable1,
      Disable2,
      Disable3,
      Disable4,
      OFF;

      // $FF: synthetic method
      private static SoundFX.OnOffSound[] $values() {
         return new SoundFX.OnOffSound[]{Custom, Inertia, Enable1, Enable2, Enable3, Enable4, Disable1, Disable2, Disable3, Disable4, OFF};
      }
   }

   public static enum HitSound {
      UWU,
      MOAN,
      SKEET,
      RIFK,
      KEYBOARD,
      CUTIE,
      SUCCESS,
      CUSTOM,
      OFF;

      // $FF: synthetic method
      private static SoundFX.HitSound[] $values() {
         return new SoundFX.HitSound[]{UWU, MOAN, SKEET, RIFK, KEYBOARD, CUTIE, SUCCESS, CUSTOM, OFF};
      }
   }

   public static enum KillSound {
      Custom,
      OFF;

      // $FF: synthetic method
      private static SoundFX.KillSound[] $values() {
         return new SoundFX.KillSound[]{Custom, OFF};
      }
   }

   public static enum ScrollSound {
      Custom,
      OFF,
      KeyBoard;

      // $FF: synthetic method
      private static SoundFX.ScrollSound[] $values() {
         return new SoundFX.ScrollSound[]{Custom, OFF, KeyBoard};
      }
   }
}
