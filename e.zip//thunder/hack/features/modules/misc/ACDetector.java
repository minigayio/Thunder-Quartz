package thunder.hack.features.modules.misc;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2680;
import net.minecraft.class_2708;
import net.minecraft.class_2743;
import net.minecraft.class_2828;
import net.minecraft.class_2846;
import net.minecraft.class_2886;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_2846.class_2847;
import thunder.hack.core.Managers;
import thunder.hack.events.impl.EventAttack;
import thunder.hack.events.impl.EventSync;
import thunder.hack.events.impl.PacketEvent;
import thunder.hack.features.modules.Module;
import thunder.hack.gui.notification.Notification;
import thunder.hack.setting.Setting;
import thunder.hack.setting.impl.SettingGroup;

public class ACDetector extends Module {
   public final Setting<SettingGroup> checksGroup = new Setting("Flags", new SettingGroup(false, 0));
   private final Setting<Boolean> speedCheck;
   private final Setting<Boolean> reachCheck;
   private final Setting<Boolean> timerCheck;
   private final Setting<Boolean> simulationCheck;
   private final Setting<Boolean> velocityCheck;
   private final Setting<Boolean> badPacketsCheck;
   private final Setting<Boolean> fastBreakCheck;
   private final Setting<Boolean> flyCheck;
   private final Setting<Boolean> noFallCheck;
   private final Setting<Boolean> jesusCheck;
   private final Setting<Boolean> inventoryMoveCheck;
   private final Setting<Boolean> notfoundcheck;
   public final Setting<Boolean> notify;
   public final Setting<Boolean> song;
   private final Setting<Boolean> antiFakeFlag;
   private class_243 lastPos;
   private class_243 lastServerPos;
   private class_2338 lastBlockPos;
   private long lastBlockBreakTime;
   private double lastFallDistance;
   private int airTicks;
   private boolean gotHit;
   private int speedVerbose;
   private int reachVerbose;
   private int timerVerbose;
   private int simulationVerbose;
   private int velocityVerbose;
   private int badPacketsVerbose;
   private int fastBreakVerbose;
   private int flyVerbose;
   private int noFallVerbose;
   private int jesusVerbose;
   private int inventoryMoveVerbose;
   private boolean enderPearlThrown;
   private long lastPearlTime;
   private long lastVelocityTick;
   private boolean expectingVelocity;
   private long lastTimerCheckTime;
   private int clientTicks;
   private boolean wasKnockedByFireball;
   private long lastFireballTime;
   private long lastPPLPacketTime;

   public ACDetector() {
      super("AntiCheatDetector", Module.Category.MISC);
      this.speedCheck = (new Setting("Speedk", true)).addToGroup(this.checksGroup);
      this.reachCheck = (new Setting("Reach", true)).addToGroup(this.checksGroup);
      this.timerCheck = (new Setting("Timer", true)).addToGroup(this.checksGroup);
      this.simulationCheck = (new Setting("Simulation", true)).addToGroup(this.checksGroup);
      this.velocityCheck = (new Setting("Velocity", true)).addToGroup(this.checksGroup);
      this.badPacketsCheck = (new Setting("BadPackets", true)).addToGroup(this.checksGroup);
      this.fastBreakCheck = (new Setting("FastBreak", true)).addToGroup(this.checksGroup);
      this.flyCheck = (new Setting("Fly", true)).addToGroup(this.checksGroup);
      this.noFallCheck = (new Setting("NoFall", true)).addToGroup(this.checksGroup);
      this.jesusCheck = (new Setting("Jesus", true)).addToGroup(this.checksGroup);
      this.inventoryMoveCheck = (new Setting("InventoryMove", true)).addToGroup(this.checksGroup);
      this.notfoundcheck = new Setting("NotFoundChecks", true);
      this.notify = new Setting("Notify", true);
      this.song = new Setting("Song", false);
      this.antiFakeFlag = new Setting("AntiFakeFlag", false);
      this.lastPos = class_243.field_1353;
      this.lastServerPos = class_243.field_1353;
      this.lastFallDistance = 0.0D;
      this.airTicks = 0;
      this.gotHit = false;
      this.speedVerbose = 0;
      this.reachVerbose = 0;
      this.timerVerbose = 0;
      this.simulationVerbose = 0;
      this.velocityVerbose = 0;
      this.badPacketsVerbose = 0;
      this.fastBreakVerbose = 0;
      this.flyVerbose = 0;
      this.noFallVerbose = 0;
      this.jesusVerbose = 0;
      this.inventoryMoveVerbose = 0;
      this.enderPearlThrown = false;
      this.lastPearlTime = 0L;
      this.lastVelocityTick = -1L;
      this.expectingVelocity = false;
      this.lastTimerCheckTime = System.currentTimeMillis();
      this.clientTicks = 0;
      this.wasKnockedByFireball = false;
      this.lastFireballTime = 0L;
      this.lastPPLPacketTime = 0L;
   }

   @EventHandler
   public void onSync(EventSync e) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         ++this.clientTicks;
         if (this.wasKnockedByFireball && System.currentTimeMillis() - this.lastFireballTime >= 1000L) {
            this.wasKnockedByFireball = false;
         }

         if ((Boolean)this.speedCheck.getValue()) {
            this.checkSpeed();
         }

         if ((Boolean)this.timerCheck.getValue()) {
            this.checkTimer();
         }

         if ((Boolean)this.simulationCheck.getValue()) {
            this.checkSimulation();
         }

         if ((Boolean)this.flyCheck.getValue()) {
            this.checkFly();
         }

         if ((Boolean)this.noFallCheck.getValue()) {
            this.checkNoFall();
         }

         if ((Boolean)this.jesusCheck.getValue()) {
            this.checkJesus();
         }

         if ((Boolean)this.inventoryMoveCheck.getValue()) {
            this.checkInventoryMove();
         }

      }
   }

   @EventHandler
   public void onAttack(EventAttack e) {
      if ((Boolean)this.reachCheck.getValue()) {
         if (e.getEntity() != null) {
            String entityStr = e.getEntity().toString().toLowerCase();
            if (entityStr.contains("fireball")) {
               this.wasKnockedByFireball = true;
               this.lastFireballTime = System.currentTimeMillis();
            } else {
               double distance = (double)mc.field_1724.method_5739(e.getEntity());
               if (distance > 3.5D && Managers.SERVER.getPing() < 150 && Managers.SERVER.getTPS() > 18.0F) {
                  ++this.reachVerbose;
                  if (this.reachVerbose >= 5) {
                     String info = String.format("%.5f blocks", distance);
                     this.sendClientGrimFlag("Reach", this.reachVerbose, info);
                     this.reachVerbose = 0;
                  }
               } else {
                  this.reachVerbose = Math.max(this.reachVerbose - 1, 0);
               }

               if (e.getEntity() instanceof class_1297 && e.isPre()) {
                  this.gotHit = true;
               }

            }
         }
      }
   }

   @EventHandler
   public void onPacketReceive(PacketEvent.Receive e) {
      if (e.getPacket() instanceof class_2708) {
         this.lastPPLPacketTime = System.currentTimeMillis();
         if (this.enderPearlThrown && System.currentTimeMillis() - this.lastPearlTime < 1000L) {
            return;
         }

         if (!(Boolean)this.antiFakeFlag.getValue()) {
            this.sendClientGrimFlag("Flag not found", this.velocityVerbose, "You are flagged but not found flag.");
         }
      }

      class_2596 var3 = e.getPacket();
      if (var3 instanceof class_2743) {
         class_2743 packet = (class_2743)var3;
         if (packet.method_11818() == mc.field_1724.method_5628() && this.gotHit) {
            this.expectingVelocity = true;
            this.lastVelocityTick = (long)mc.field_1724.field_6012;
            this.gotHit = false;
         }
      }

      if (this.expectingVelocity && (long)mc.field_1724.field_6012 - this.lastVelocityTick > 1L) {
         if (mc.field_1724.method_18798().method_1033() < 0.08D && mc.field_1724.method_24828()) {
            ++this.velocityVerbose;
            if (this.velocityVerbose >= 3) {
               String info = String.format("No knockback %.3f", mc.field_1724.method_18798().method_1033());
               this.sendClientGrimFlag("Velocity", this.velocityVerbose, info);
               this.velocityVerbose = 0;
            }
         } else {
            this.velocityVerbose = Math.max(this.velocityVerbose - 1, 0);
         }

         this.expectingVelocity = false;
      }

   }

   @EventHandler
   public void onPacketSend(PacketEvent.Send e) {
      class_2596 var3 = e.getPacket();
      if (var3 instanceof class_2886) {
         class_2886 packet = (class_2886)var3;
         if (mc.field_1724.method_5998(packet.method_12551()).method_7909().toString().toLowerCase().contains("ender_pearl")) {
            this.enderPearlThrown = true;
            this.lastPearlTime = System.currentTimeMillis();
         }
      }

      if ((Boolean)this.badPacketsCheck.getValue() && e.getPacket() instanceof class_2828) {
         if (mc.field_1724.method_18798().method_1027() > 15.0D) {
            ++this.badPacketsVerbose;
            if (this.badPacketsVerbose >= 5) {
               String info = "Invalid motion state=true";
               this.sendClientGrimFlag("BadPackets", this.badPacketsVerbose, info);
               this.badPacketsVerbose = 0;
            }
         } else {
            this.badPacketsVerbose = Math.max(this.badPacketsVerbose - 1, 0);
         }
      }

      if ((Boolean)this.fastBreakCheck.getValue()) {
         var3 = e.getPacket();
         if (var3 instanceof class_2846) {
            class_2846 packet = (class_2846)var3;
            if (packet.method_12363() == class_2847.field_12973) {
               class_2338 pos = packet.method_12362();
               class_2680 state = mc.field_1687.method_8320(pos);
               if (state.method_26215()) {
                  return;
               }

               float hardness = state.method_26204().method_36555();
               if (hardness <= 0.0F) {
                  return;
               }

               double expectedBreakTime = (double)hardness * 1.5D;
               long breakTime = System.currentTimeMillis() - this.lastBlockBreakTime;
               if (this.lastBlockPos != null && this.lastBlockPos.equals(pos)) {
                  if ((double)breakTime < expectedBreakTime * 0.15D && !mc.field_1724.method_6059(class_1294.field_5917)) {
                     ++this.fastBreakVerbose;
                     if (this.fastBreakVerbose >= 3) {
                        String info = String.format("%.2fms < %.2fms", (double)breakTime, expectedBreakTime * 0.15D);
                        this.sendClientGrimFlag("FastBreak", this.fastBreakVerbose, info);
                        this.fastBreakVerbose = 0;
                     }
                  } else {
                     this.fastBreakVerbose = Math.max(this.fastBreakVerbose - 1, 0);
                  }
               }

               this.lastBlockPos = pos;
               this.lastBlockBreakTime = System.currentTimeMillis();
            }
         }
      }

   }

   private void checkFly() {
      if (!mc.field_1724.method_6128() && !mc.field_1724.method_31549().field_7479 && !mc.field_1724.method_6059(class_1294.field_5902)) {
         boolean inCobweb = mc.field_1687.method_8320(mc.field_1724.method_24515()).method_26204().method_9539().contains("cobweb");
         boolean inWater = mc.field_1724.method_5799();
         boolean onLadder = mc.field_1724.method_6101();
         if (!inCobweb && !inWater && !onLadder) {
            if (!mc.field_1724.method_24828()) {
               ++this.airTicks;
            } else {
               this.airTicks = 0;
               this.flyVerbose = Math.max(this.flyVerbose - 1, 0);
            }

            if (this.airTicks > 15) {
               double motionY = mc.field_1724.method_18798().field_1351;
               boolean invalidMotionY = motionY > 0.42D || motionY == 0.0D;
               boolean noGravity = !mc.field_1724.method_5740();
               if (invalidMotionY && noGravity) {
                  ++this.flyVerbose;
                  if (this.flyVerbose >= 5) {
                     String info = "Flying > 15 ticks (" + this.airTicks + " ticks)";
                     this.sendClientGrimFlag("Fly", this.flyVerbose, info);
                     this.flyVerbose = 0;
                     this.airTicks = 0;
                  }
               } else {
                  this.flyVerbose = Math.max(this.flyVerbose - 1, 0);
               }
            }

         } else {
            this.flyVerbose = 0;
            this.airTicks = 0;
         }
      } else {
         this.flyVerbose = 0;
         this.airTicks = 0;
      }
   }

   private void checkNoFall() {
      if (!this.enderPearlThrown || System.currentTimeMillis() - this.lastPearlTime >= 1000L) {
         if (!this.wasKnockedByFireball || System.currentTimeMillis() - this.lastFireballTime >= 1000L) {
            if (!mc.field_1724.method_6128() && !mc.field_1724.method_31549().field_7479 && !mc.field_1724.method_6059(class_1294.field_5902)) {
               if (this.lastFallDistance > 3.5D && mc.field_1724.field_6017 == 0.0F && mc.field_1724.method_24828()) {
                  boolean isOnSlime = mc.field_1687.method_8320(mc.field_1724.method_24515().method_10074()).method_26204().method_9539().contains("slime");
                  if (!isOnSlime && mc.field_1724.field_6235 <= 0) {
                     ++this.noFallVerbose;
                     if (this.noFallVerbose >= 5) {
                        String info = "Fall > 3.5, no damage";
                        this.sendClientGrimFlag("NoFall", this.noFallVerbose, info);
                        this.noFallVerbose = 0;
                     }
                  } else {
                     this.noFallVerbose = Math.max(this.noFallVerbose - 1, 0);
                  }
               }

               this.lastFallDistance = (double)mc.field_1724.field_6017;
            } else {
               this.noFallVerbose = 0;
            }
         }
      }
   }

   private void checkJesus() {
      if (!mc.field_1724.method_6128() && !mc.field_1724.method_31549().field_7479 && !mc.field_1724.method_5765()) {
         if (mc.field_1724.method_5799() && !mc.field_1724.method_5681() && Math.abs(mc.field_1724.method_18798().field_1351) < 0.005D) {
            ++this.jesusVerbose;
            if (this.jesusVerbose >= 8) {
               String info = "Water Y stable";
               this.sendClientGrimFlag("Jesus", this.jesusVerbose, info);
               this.jesusVerbose = 0;
            }
         } else {
            this.jesusVerbose = Math.max(this.jesusVerbose - 1, 0);
         }

      } else {
         this.jesusVerbose = 0;
      }
   }

   private void checkInventoryMove() {
      if (mc.field_1755 != null && mc.field_1724.field_7512 != mc.field_1724.field_7498) {
         boolean isMoving = mc.field_1690.field_1894.method_1434() || mc.field_1690.field_1881.method_1434() || mc.field_1690.field_1913.method_1434() || mc.field_1690.field_1849.method_1434();
         if (isMoving) {
            ++this.inventoryMoveVerbose;
            if (this.inventoryMoveVerbose >= 5) {
               String info = "Moving with inventory open";
               this.sendClientGrimFlag("InventoryMove", this.inventoryMoveVerbose, info);
               this.inventoryMoveVerbose = 0;
            }
         } else {
            this.inventoryMoveVerbose = Math.max(this.inventoryMoveVerbose - 1, 0);
         }
      } else {
         this.inventoryMoveVerbose = 0;
      }

   }

   private void checkSpeed() {
      class_2680 blockBelow = mc.field_1687.method_8320(mc.field_1724.method_24515().method_10074());
      if (blockBelow.method_26204().method_9539().contains("slime")) {
         this.speedVerbose = 0;
         this.lastPos = mc.field_1724.method_19538();
      } else if (mc.field_1724.field_6017 > 0.0F) {
         this.speedVerbose = 0;
         this.lastPos = mc.field_1724.method_19538();
      } else {
         class_243 pos = mc.field_1724.method_19538();
         double distance = pos.method_1022(this.lastPos);
         double maxAllowedSpeed = this.getMaxAllowedSpeed();
         boolean hasSpeed = mc.field_1724.method_6059(class_1294.field_5904);
         boolean hasJumpBoost = mc.field_1724.method_6059(class_1294.field_5913);
         boolean hasLevitation = mc.field_1724.method_6059(class_1294.field_5902);
         boolean isInKnockback = mc.field_1724.field_6235 > 0;
         boolean isFlying = mc.field_1724.method_31549().field_7479;
         boolean isElytraFlying = mc.field_1724.method_6128();
         if (!hasSpeed && !hasJumpBoost && !hasLevitation && !isInKnockback && !isFlying && !isElytraFlying) {
            if (distance > maxAllowedSpeed && distance >= 0.71D) {
               ++this.speedVerbose;
               if (this.speedVerbose >= 3) {
                  String info = String.format("%.3f m/s", distance);
                  this.sendClientGrimFlag("Speed", this.speedVerbose, info);
                  this.speedVerbose = 0;
               }
            } else {
               this.speedVerbose = Math.max(this.speedVerbose - 1, 0);
            }
         }

         this.lastPos = pos;
      }
   }

   private void checkTimer() {
      long currentTime = System.currentTimeMillis();
      long elapsed = currentTime - this.lastTimerCheckTime;
      if (elapsed >= 1000L) {
         float ticksPerSecond = (float)this.clientTicks * 1000.0F / (float)elapsed;
         float serverTPS = Managers.SERVER.getTPS();
         if (ticksPerSecond > 55.0F) {
            ++this.timerVerbose;
            if (this.timerVerbose >= 5) {
               String info = String.format("%.2f tps (server %.2f)", ticksPerSecond, serverTPS);
               this.sendClientGrimFlag("Timer", this.timerVerbose, info);
               this.timerVerbose = 0;
            }
         } else {
            this.timerVerbose = Math.max(this.timerVerbose - 1, 0);
         }

         this.clientTicks = 0;
         this.lastTimerCheckTime = currentTime;
      }

   }

   private void checkSimulation() {
      class_2680 blockBelow = mc.field_1687.method_8320(mc.field_1724.method_24515().method_10074());
      if (blockBelow.method_26204().method_9539().contains("slime")) {
         this.simulationVerbose = 0;
         this.lastServerPos = mc.field_1724.method_19538();
      } else if (this.enderPearlThrown && System.currentTimeMillis() - this.lastPearlTime < 1000L) {
         this.simulationVerbose = 0;
         this.lastServerPos = mc.field_1724.method_19538();
      } else if (this.wasKnockedByFireball && System.currentTimeMillis() - this.lastFireballTime < 1000L) {
         this.simulationVerbose = 0;
         this.lastServerPos = mc.field_1724.method_19538();
      } else {
         class_243 serverPos = mc.field_1724.method_19538();
         double posDiff = serverPos.method_1022(this.lastServerPos);
         boolean isInKnockback = mc.field_1724.field_6235 > 0;
         if (!(mc.field_1724.field_6017 > 0.0F) && !isInKnockback) {
            if (posDiff > 0.75D) {
               ++this.simulationVerbose;
               if (this.simulationVerbose >= 5) {
                  String info = String.format("%.3f desync", posDiff);
                  this.sendClientGrimFlag("Simulation", this.simulationVerbose, info);
                  this.simulationVerbose = 0;
               }
            } else {
               this.simulationVerbose = Math.max(this.simulationVerbose - 1, 0);
            }

            this.lastServerPos = serverPos;
         } else {
            this.simulationVerbose = 0;
            this.lastServerPos = serverPos;
         }
      }
   }

   private double getMaxAllowedSpeed() {
      if (!mc.field_1724.method_6128() && !mc.field_1724.method_31549().field_7479) {
         if (mc.field_1724.method_24828()) {
            return mc.field_1724.method_5624() ? 0.3D : 0.25D;
         } else {
            return mc.field_1724.method_5624() ? 0.45D : 0.38D;
         }
      } else {
         return 999.0D;
      }
   }

   private void sendClientGrimFlag(String type, int verbose, String extraInfo) {
      long currentTime = System.currentTimeMillis();
      if (!(Boolean)this.antiFakeFlag.getValue() || currentTime - this.lastPPLPacketTime <= 3000L) {
         String chatMessage = "§7(ClientSide) §dAntiCheat §8>> §f" + mc.field_1724.method_7334().getName() + " §dfailed §f" + type + " (x§c" + verbose + "§f) §7" + extraInfo;
         String notifyMessage = "§dAntiCheat §8>> §f" + mc.field_1724.method_7334().getName() + " §dfailed §f" + type + " (x§c" + verbose + "§f) §7" + extraInfo;
         if ((Boolean)this.notify.getValue()) {
            mc.field_1724.method_7353(class_2561.method_43470(chatMessage), false);
            Managers.NOTIFICATION.publicity("", notifyMessage, 3, Notification.Type.WARNING);
         }

         if ((Boolean)this.song.getValue()) {
            mc.field_1687.method_8396(mc.field_1724, mc.field_1724.method_24515(), class_3417.field_14627, class_3419.field_15245, 1.0F, 1.0F);
         }

      }
   }
}
