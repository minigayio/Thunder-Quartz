package thunder.hack.features.modules.client;

import thunder.hack.features.modules.Module;

public final class OptifineCapes extends Module {
   public OptifineCapes() {
      super("ExploitcoreCapes", Module.Category.CLIENT);
   }
}
