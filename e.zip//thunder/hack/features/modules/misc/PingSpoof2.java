package thunder.hack.features.modules.misc;

import java.util.HashSet;
import java.util.concurrent.ConcurrentHashMap;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2596;
import net.minecraft.class_2827;
import thunder.hack.events.impl.PacketEvent;
import thunder.hack.features.modules.Module;
import thunder.hack.setting.Setting;

public class PingSpoof2 extends Module {
   public final Setting<Float> ping = new Setting("Ping", 500.0F, 1.0F, 1500.0F);
   private final ConcurrentHashMap<class_2827, Long> packets = new ConcurrentHashMap();

   public PingSpoof2() {
      super("PingSpoof2", Module.Category.MISC);
   }

   @EventHandler
   public void onPacketSend(PacketEvent.Send event) {
      class_2596 var3 = event.getPacket();
      if (var3 instanceof class_2827) {
         class_2827 packet = (class_2827)var3;
         if (this.packets.containsKey(packet)) {
            this.packets.remove(packet);
         } else {
            this.packets.put(packet, System.currentTimeMillis());
            event.cancel();
         }
      }
   }

   @EventHandler
   public void onPacketReceive(PacketEvent.Receive event) {
      if (!this.packets.isEmpty()) {
         (new HashSet(this.packets.keySet())).forEach((packet) -> {
            if ((float)(System.currentTimeMillis() - (Long)this.packets.get(packet)) >= (Float)this.ping.getValue()) {
               mc.method_1562().method_52787(packet);
               this.packets.remove(packet);
            }

         });
      }
   }

   public void onDisable() {
      if (!this.packets.isEmpty()) {
         this.packets.keySet().forEach((packet) -> {
            mc.method_1562().method_52787(packet);
         });
         this.packets.clear();
      }

   }
}
