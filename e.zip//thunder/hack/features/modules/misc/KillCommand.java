package thunder.hack.features.modules.misc;

import java.util.Iterator;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1657;
import net.minecraft.class_746;
import thunder.hack.events.impl.EventDeath;
import thunder.hack.features.modules.Module;
import thunder.hack.setting.Setting;
import thunder.hack.utility.Timer;

public class KillCommand extends Module {
   private final Setting<String> commandTemplate = new Setting("CommandTemplate", "msg %s L dsc.gg/mdpstresser najlepsza stressarka + bombamod LLL");
   private final Setting<Boolean> repeat = new Setting("Repeat", false);
   private final Setting<Integer> repeatCount = new Setting("RepeatCount", 1, 1, 10, (v) -> {
      return (Boolean)this.repeat.getValue();
   });
   private final Setting<Integer> repeatDelay = new Setting("RepeatDelay", 500, 100, 5000, (v) -> {
      return (Boolean)this.repeat.getValue();
   });
   private final Setting<Boolean> noKillRandom = new Setting("NoKillRandom", false);
   private final Setting<Integer> randomDelay = new Setting("RandomDelay", 5000, 1000, 30000, (v) -> {
      return (Boolean)this.noKillRandom.getValue();
   });
   private final Timer repeatTimer = new Timer();
   private final Timer randomTimer = new Timer();
   private int repeatIndex = 0;
   private String pendingCommand;

   public KillCommand() {
      super("KillCommand", Module.Category.MISC);
   }

   @EventHandler
   public void onPlayerDeath(EventDeath event) {
      class_1657 player = event.getPlayer();
      if (!(player instanceof class_746)) {
         String playerName = player.method_5477().getString();
         String command = String.format((String)this.commandTemplate.getValue(), playerName);
         this.sendChatCommand(command);
         if ((Boolean)this.repeat.getValue()) {
            this.repeatIndex = 1;
            this.pendingCommand = command;
            this.repeatTimer.reset();
         }

      }
   }

   public void onUpdate() {
      if ((Boolean)this.repeat.getValue() && this.repeatIndex > 0 && this.repeatIndex < (Integer)this.repeatCount.getValue() && this.repeatTimer.passedMs((long)(Integer)this.repeatDelay.getValue())) {
         this.sendChatCommand(this.pendingCommand);
         ++this.repeatIndex;
         this.repeatTimer.reset();
      }

      if ((Boolean)this.noKillRandom.getValue() && this.randomTimer.passedMs((long)(Integer)this.randomDelay.getValue())) {
         Iterator var1 = mc.field_1687.method_18456().iterator();

         while(var1.hasNext()) {
            class_1657 player = (class_1657)var1.next();
            if (player != mc.field_1724 && !player.method_29504() && player.method_5805()) {
               String randomCommand = String.format((String)this.commandTemplate.getValue(), player.method_5477().getString());
               this.sendChatCommand(randomCommand);
               this.randomTimer.reset();
               break;
            }
         }
      }

   }

   public void sendChatCommand(String command) {
      mc.method_1562().method_45730(command);
   }
}
