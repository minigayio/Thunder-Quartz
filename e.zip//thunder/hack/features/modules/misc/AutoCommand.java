package thunder.hack.features.modules.misc;

import thunder.hack.features.modules.Module;
import thunder.hack.setting.Setting;
import thunder.hack.utility.Timer;

public class AutoCommand extends Module {
   private final Setting<String> command = new Setting("Command", "sklep");
   private final Setting<Integer> interval = new Setting("Interval", 20, 0, 600);
   private final Setting<Boolean> repeat = new Setting("Repeat", false);
   private final Timer timer = new Timer();

   public AutoCommand() {
      super("AutoCommand", Module.Category.MISC);
   }

   public void onEnable() {
      mc.field_1724.field_3944.method_45731((String)this.command.getValue());
      if (!(Boolean)this.repeat.getValue()) {
         this.disable();
      }

      this.timer.reset();
   }

   public void onUpdate() {
      if ((Boolean)this.repeat.getValue() && this.timer.passedMs((long)(Integer)this.interval.getValue() * 1000L)) {
         mc.field_1724.field_3944.method_45731((String)this.command.getValue());
         this.timer.reset();
      }

   }
}
