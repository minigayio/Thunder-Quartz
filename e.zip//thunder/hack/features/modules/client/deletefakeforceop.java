package thunder.hack.features.modules.client;

import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_746;
import thunder.hack.features.modules.Module;

public class deletefakeforceop extends Module {
   public deletefakeforceop() {
      super("FakeOp", Module.Category.CLIENT);
   }

   public void onEnable() {
      if (mc.field_1724 != null) {
         this.sendFakeOpMessage(mc.field_1724);
         this.disable();
      }
   }

   private void sendFakeOpMessage(class_746 player) {
      String message = "[Server: Made " + player.method_5477().getString() + " a server operator]";
      player.method_7353(class_2561.method_43470(message).method_27695(new class_124[]{class_124.field_1080, class_124.field_1056}), false);
   }
}
