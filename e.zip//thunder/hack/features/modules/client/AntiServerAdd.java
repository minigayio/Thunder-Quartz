package thunder.hack.features.modules.client;

import thunder.hack.features.modules.Module;

public class AntiServerAdd extends Module {
   public AntiServerAdd() {
      super("AntiServerAdd", Module.Category.CLIENT);
   }
}
