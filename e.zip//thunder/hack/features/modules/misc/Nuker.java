package thunder.hack.features.modules.misc;

import java.awt.Color;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2404;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2846;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_4587;
import net.minecraft.class_239.class_240;
import net.minecraft.class_2846.class_2847;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;
import thunder.hack.core.Managers;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.events.impl.EventAttackBlock;
import thunder.hack.events.impl.EventSetBlockState;
import thunder.hack.events.impl.EventSync;
import thunder.hack.events.impl.PlayerUpdateEvent;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.client.ClientSettings;
import thunder.hack.features.modules.client.HudEditor;
import thunder.hack.features.modules.player.SpeedMine;
import thunder.hack.setting.Setting;
import thunder.hack.setting.impl.ColorSetting;
import thunder.hack.setting.impl.ItemSelectSetting;
import thunder.hack.utility.Timer;
import thunder.hack.utility.player.InteractionUtility;
import thunder.hack.utility.player.PlayerUtility;
import thunder.hack.utility.render.Render2DEngine;
import thunder.hack.utility.render.Render3DEngine;
import thunder.hack.utility.world.ExplosionUtility;

public class Nuker extends Module {
   public final Setting<ItemSelectSetting> selectedBlocks = new Setting("SelectedBlocks", new ItemSelectSetting(new ArrayList()));
   private final Setting<Nuker.Mode> mode;
   private final Setting<Boolean> silentAim;
   private final Setting<Integer> packetLimit;
   private final Setting<Integer> delay;
   private final Setting<Float> customFOV;
   private final Setting<Boolean> autoWalk;
   private final Setting<Nuker.BlockSelection> blocks;
   private final Setting<Boolean> noBack;
   private final Setting<Float> reach;
   private final Setting<Boolean> ignoreWalls;
   private final Setting<Boolean> flatten;
   private final Setting<Boolean> creative;
   private final Setting<Boolean> avoidLava;
   private final Setting<Float> range;
   private final Setting<Nuker.ColorMode> colorMode;
   public final Setting<ColorSetting> color;
   private final Setting<Nuker.BypassMode> bypass;
   private final Setting<Boolean> gencash;
   private Timer packetTimer;
   private class_2248 targetBlockType;
   private Nuker.BlockData blockData;
   private Timer breakTimer;
   private float customFOVValue;
   private int tickCounter;
   private Nuker.NukerThread nukerThread;
   private float rotationYaw;
   private float rotationPitch;

   public Nuker() {
      super("Nuker", Module.Category.MISC);
      this.mode = new Setting("Mode", Nuker.Mode.Default);
      this.silentAim = new Setting("SilentAim", false);
      this.packetLimit = new Setting("PacketLimit", 5, 1, 20);
      this.delay = new Setting("Delay", 25, 0, 1000);
      this.customFOV = new Setting("CustomFOV", 90.0F, 30.0F, 180.0F, (v) -> {
         return this.mode.getValue() == Nuker.Mode.FastSafe;
      });
      this.autoWalk = new Setting("AutoWalk", false, (v) -> {
         return this.mode.getValue() == Nuker.Mode.FastSafe;
      });
      this.blocks = new Setting("Blocks", Nuker.BlockSelection.Select);
      this.noBack = new Setting("NoBack", false, (v) -> {
         return this.mode.getValue() == Nuker.Mode.FastSafe;
      });
      this.reach = new Setting("Reach", 4.2F, 1.5F, 25.0F, (v) -> {
         return this.mode.getValue() == Nuker.Mode.FastSafe;
      });
      this.ignoreWalls = new Setting("IgnoreWalls", false);
      this.flatten = new Setting("Flatten", false);
      this.creative = new Setting("Creative", false);
      this.avoidLava = new Setting("AvoidLava", false);
      this.range = new Setting("Range", 4.2F, 1.5F, 25.0F);
      this.colorMode = new Setting("ColorMode", Nuker.ColorMode.Sync);
      this.color = new Setting("Color", new ColorSetting(575714484), (v) -> {
         return this.colorMode.getValue() == Nuker.ColorMode.Custom;
      });
      this.bypass = new Setting("Bypass", Nuker.BypassMode.None);
      this.gencash = new Setting("GenCash", false);
      this.packetTimer = new Timer();
      this.breakTimer = new Timer();
      this.customFOVValue = 70.0F;
      this.tickCounter = 0;
      this.nukerThread = new Nuker.NukerThread();
   }

   public void onEnable() {
      this.nukerThread = new Nuker.NukerThread();
      this.nukerThread.setName("ThunderHack-NukerThread");
      this.nukerThread.setDaemon(true);
      this.nukerThread.start();
      if ((Boolean)this.autoWalk.getValue()) {
         mc.field_1690.field_1894.method_23481(true);
      }

   }

   public void onDisable() {
      this.nukerThread.interrupt();
      this.customFOVValue = 70.0F;
      mc.field_1690.field_1894.method_23481(false);
   }

   public void onUpdate() {
      if (!this.nukerThread.isAlive()) {
         this.nukerThread = new Nuker.NukerThread();
         this.nukerThread.setName("ThunderHack-NukerThread");
         this.nukerThread.setDaemon(true);
         this.nukerThread.start();
      }

   }

   @EventHandler
   public void onBlockInteract(EventAttackBlock e) {
      if (!mc.field_1687.method_22347(e.getBlockPos())) {
         if (((Nuker.BlockSelection)this.blocks.getValue()).equals(Nuker.BlockSelection.Select) && this.targetBlockType != mc.field_1687.method_8320(e.getBlockPos()).method_26204()) {
            this.targetBlockType = mc.field_1687.method_8320(e.getBlockPos()).method_26204();
            this.sendMessage(ClientSettings.isRu() ? "Выбран блок: " + String.valueOf(class_124.field_1075) + this.targetBlockType.method_9518().getString() : "Selected block: " + String.valueOf(class_124.field_1075) + this.targetBlockType.method_9518().getString());
         }

      }
   }

   @EventHandler
   public void onBlockDestruct(EventSetBlockState e) {
      if (this.blockData != null && e.getPos() == this.blockData.bp && e.getState().method_26215()) {
         this.blockData = null;
         (new Thread(() -> {
            if ((this.targetBlockType != null || ((Nuker.BlockSelection)this.blocks.getValue()).equals(Nuker.BlockSelection.All)) && !mc.field_1690.field_1886.method_1434() && this.blockData == null) {
               this.blockData = this.getNukerBlockPos();
            }

         })).start();
      }

   }

   @EventHandler
   public void onSync(EventSync e) {
      if (this.rotationYaw != -999.0F) {
         mc.field_1724.method_36456(this.rotationYaw);
         mc.field_1724.method_36457(this.rotationPitch);
         this.rotationYaw = -999.0F;
      }

   }

   private boolean isInCustomFOV(class_2338 blockPos) {
      class_243 blockVec = blockPos.method_46558();
      class_243 eyesPos = InteractionUtility.getEyesPos(mc.field_1724);
      class_243 lookVec = mc.field_1724.method_5828(1.0F).method_1029();
      class_243 toBlock = blockVec.method_1020(eyesPos).method_1029();
      double angle = Math.acos(lookVec.method_1026(toBlock)) * 57.29577951308232D;
      return angle <= (double)((Float)this.customFOV.getValue() / 2.0F);
   }

   private void handleAutoWalk() {
      if (this.blockData == null) {
         mc.field_1690.field_1894.method_23481(false);
      } else {
         class_243 playerPos = mc.field_1724.method_19538();
         class_243 direction = mc.field_1724.method_5828(1.0F).method_1029();
         class_2338 frontPos = class_2338.method_49638(playerPos.method_1031(direction.field_1352, 0.0D, direction.field_1350));
         class_2338 aboveFrontPos = frontPos.method_10084();
         if (!this.isAllowed(mc.field_1687.method_8320(frontPos).method_26204())) {
            if (!mc.field_1687.method_8320(frontPos).method_26234(mc.field_1687, frontPos) || !mc.field_1687.method_8320(aboveFrontPos).method_26215()) {
               this.findNewDirection();
               return;
            }

            mc.field_1724.method_6043();
         }

         mc.field_1690.field_1894.method_23481(true);
      }
   }

   private boolean areSelectedBlocksAhead(int blocksToCheck) {
      class_243 direction = mc.field_1724.method_5828(1.0F).method_1029();
      class_243 eyesPos = InteractionUtility.getEyesPos(mc.field_1724);

      for(int i = 1; i <= blocksToCheck; ++i) {
         class_243 checkPos = eyesPos.method_1019(direction.method_1021((double)i));
         class_2338 blockPos = class_2338.method_49638(checkPos);
         if (this.isAllowed(mc.field_1687.method_8320(blockPos).method_26204())) {
            return true;
         }
      }

      return false;
   }

   private boolean hasSelectedBlocksInFOV() {
      int intRange = (int)(Math.floor((double)(Float)this.range.getValue()) + 1.0D);
      Iterable<class_2338> blocks = class_2338.method_25996(new class_2338(class_2338.method_49638(mc.field_1724.method_19538()).method_10084()), intRange, intRange, intRange);
      Iterator var3 = blocks.iterator();

      class_2338 b;
      do {
         if (!var3.hasNext()) {
            return false;
         }

         b = (class_2338)var3.next();
      } while(!this.isAllowed(mc.field_1687.method_8320(b).method_26204()) || !this.isInCustomFOV(b));

      return true;
   }

   private void findNewDirection() {
      int intRange = (int)(Math.floor((double)(Float)this.range.getValue()) + 1.0D);
      Iterable<class_2338> blocks = class_2338.method_25996(new class_2338(class_2338.method_49638(mc.field_1724.method_19538()).method_10084()), intRange, intRange, intRange);
      class_2338 closestBlock = null;
      double closestDistance = Double.MAX_VALUE;
      Iterator var6 = blocks.iterator();

      while(var6.hasNext()) {
         class_2338 b = (class_2338)var6.next();
         if (this.isAllowed(mc.field_1687.method_8320(b).method_26204())) {
            double distance = mc.field_1724.method_5707(b.method_46558());
            if (distance < closestDistance) {
               closestBlock = b;
               closestDistance = distance;
            }
         }
      }

      if (closestBlock != null) {
         class_243 direction = closestBlock.method_46558().method_1020(mc.field_1724.method_19538()).method_1029();
         float targetYaw = (float)(class_3532.method_15349(direction.field_1350, direction.field_1352) * 57.29577951308232D) - 90.0F;
         mc.field_1724.method_36456(targetYaw);
         this.blockData = new Nuker.BlockData(closestBlock, closestBlock.method_46558(), class_2350.field_11036);
      }

   }

   private void smoothRotate(float targetYaw, float targetPitch) {
      float currentYaw = mc.field_1724.method_36454();
      float currentPitch = mc.field_1724.method_36455();
      float deltaYaw = class_3532.method_15393(targetYaw - currentYaw);
      float deltaPitch = targetPitch - currentPitch;
      float maxDelta = 5.0F;
      float smoothYaw = currentYaw + class_3532.method_15363(deltaYaw, -maxDelta, maxDelta);
      float smoothPitch = currentPitch + class_3532.method_15363(deltaPitch, -maxDelta, maxDelta);
      mc.field_1724.method_36456(smoothYaw);
      mc.field_1724.method_36457(smoothPitch);
   }

   @EventHandler
   public void onPlayerUpdate(PlayerUpdateEvent e) {
      if (this.blockData != null) {
         if (mc.field_1687.method_8320(this.blockData.bp).method_26204() != this.targetBlockType && ((Nuker.BlockSelection)this.blocks.getValue()).equals(Nuker.BlockSelection.Select) || (double)PlayerUtility.squaredDistanceFromEyes(this.blockData.bp.method_46558()) > Math.pow((double)(Float)this.reach.getValue(), 2.0D) || !this.isInCustomFOV(this.blockData.bp) || mc.field_1687.method_22347(this.blockData.bp)) {
            this.blockData = null;
         }

         if (this.blockData == null || mc.field_1690.field_1886.method_1434()) {
            return;
         }

         if (this.bypass.getValue() == Nuker.BypassMode.Vulcan) {
            this.handleBypass(this.blockData.bp);
         } else if ((Boolean)this.gencash.getValue() && this.isFullyGrownWheat(this.blockData.bp)) {
            this.breakBlock();
         } else if (!(Boolean)this.gencash.getValue()) {
            this.breakBlock();
         }
      }

      if (this.blockData != null && !mc.field_1690.field_1886.method_1434()) {
         if ((Float)this.customFOV.getValue() != this.customFOVValue) {
            this.customFOVValue = (Float)this.customFOV.getValue();
         }

         if ((Boolean)this.autoWalk.getValue()) {
            this.handleAutoWalk();
         }

         float[] angle = InteractionUtility.calculateAngle(this.blockData.vec3d);
         this.rotationYaw = angle[0];
         this.rotationPitch = angle[1];
         ModuleManager.rotations.fixRotation = this.rotationYaw;
         int intRange;
         Iterable blocks_;
         if (this.mode.getValue() == Nuker.Mode.FastSafe) {
            intRange = (int)(Math.floor((double)(Float)this.range.getValue()) + 1.0D);
            blocks_ = class_2338.method_25996(new class_2338(class_2338.method_49638(mc.field_1724.method_19538()).method_10084()), intRange, intRange, intRange);
            Set<class_2338> processedBlocks = new HashSet();
            int packetsSent = 0;
            Iterator var7 = blocks_.iterator();

            label119:
            while(true) {
               class_2338 b;
               class_2680 state;
               class_243 direction;
               class_243 toBlock;
               do {
                  do {
                     do {
                        if (!var7.hasNext()) {
                           break label119;
                        }

                        b = (class_2338)var7.next();
                        if (packetsSent >= (Integer)this.packetLimit.getValue()) {
                           break label119;
                        }
                     } while((Boolean)this.flatten.getValue() && (double)b.method_10264() < mc.field_1724.method_23318());
                  } while((Boolean)this.avoidLava.getValue() && this.checkLava(b));

                  state = mc.field_1687.method_8320(b);
                  if (!(Boolean)this.noBack.getValue()) {
                     break;
                  }

                  direction = mc.field_1724.method_5828(1.0F);
                  toBlock = (new class_243((double)b.method_10263() + 0.5D, (double)b.method_10264() + 0.5D, (double)b.method_10260() + 0.5D)).method_1020(mc.field_1724.method_19538().method_1031(0.0D, (double)mc.field_1724.method_18381(mc.field_1724.method_18376()), 0.0D));
               } while(direction.method_1026(toBlock.method_1029()) < 0.5D);

               if ((double)PlayerUtility.squaredDistanceFromEyes(b.method_46558()) <= Math.pow((double)(Float)this.reach.getValue(), 2.0D) && this.isAllowed(state.method_26204()) && !processedBlocks.contains(b)) {
                  try {
                     this.sendSequencedPacket((id) -> {
                        return new class_2846(class_2847.field_12968, b, class_2350.field_11036, id);
                     });
                     mc.field_1761.method_2899(b);
                     mc.field_1724.method_6104(class_1268.field_5808);
                     processedBlocks.add(b);
                     ++packetsSent;
                  } catch (Exception var13) {
                  }
               }
            }
         }

         if (this.mode.getValue() == Nuker.Mode.FastAF) {
            intRange = (int)(Math.floor((double)(Float)this.range.getValue()) + 1.0D);
            blocks_ = class_2338.method_25996(new class_2338(class_2338.method_49638(mc.field_1724.method_19538()).method_10084()), intRange, intRange, intRange);
            Iterator var14 = blocks_.iterator();

            while(true) {
               class_2338 b;
               do {
                  do {
                     if (!var14.hasNext()) {
                        return;
                     }

                     b = (class_2338)var14.next();
                  } while((Boolean)this.flatten.getValue() && (double)b.method_10264() < mc.field_1724.method_23318());
               } while((Boolean)this.avoidLava.getValue() && this.checkLava(b));

               class_2680 state = mc.field_1687.method_8320(b);
               if (PlayerUtility.squaredDistanceFromEyes(b.method_46558()) <= this.range.getPow2Value() && this.isAllowed(state.method_26204())) {
                  try {
                     this.sendSequencedPacket((id) -> {
                        return new class_2846(class_2847.field_12968, b, class_2350.field_11036, id);
                     });
                     mc.field_1761.method_2899(b);
                     mc.field_1724.method_6104(class_1268.field_5808);
                  } catch (Exception var12) {
                  }
               }
            }
         }
      }
   }

   private boolean isFullyGrownWheat(class_2338 pos) {
      class_2680 state = mc.field_1687.method_8320(pos);
      return state.method_26204() == class_2246.field_10293 && (Integer)state.method_11654(class_2741.field_12550) == 7;
   }

   public synchronized void breakBlock() {
      if (this.blockData != null && !mc.field_1690.field_1886.method_1434()) {
         if (ModuleManager.speedMine.isEnabled() && ModuleManager.speedMine.mode.getValue() == SpeedMine.Mode.Packet) {
            if (!ModuleManager.speedMine.alreadyActing(this.blockData.bp)) {
               mc.field_1761.method_2910(this.blockData.bp, this.blockData.dir);
               mc.field_1724.method_6104(class_1268.field_5808);
            }
         } else {
            class_2338 cache = this.blockData.bp;
            mc.field_1761.method_2902(this.blockData.bp, this.blockData.dir);
            mc.field_1724.method_6104(class_1268.field_5808);
            if ((Boolean)this.creative.getValue()) {
               mc.field_1761.method_2899(cache);
            }
         }

      }
   }

   public void onRender3D(class_4587 stack) {
      class_2338 renderBp = null;
      if (this.blockData != null && this.blockData.bp != null) {
         renderBp = this.blockData.bp;
      }

      if (renderBp != null) {
         Color color1 = this.colorMode.getValue() == Nuker.ColorMode.Sync ? HudEditor.getColor(1) : ((ColorSetting)this.color.getValue()).getColorObject();
         int colorInt = color1.getRGB();
         Render3DEngine.drawBoxOutline(new class_238(this.blockData.bp), color1, 2.0F);
         Render3DEngine.drawFilledBox(stack, new class_238(this.blockData.bp), Render2DEngine.injectAlpha(color1, 100));
         class_243 start = mc.field_1724.method_19538().method_1031(0.0D, (double)mc.field_1724.method_18381(mc.field_1724.method_18376()), 0.0D);
         class_243 end = this.blockData.vec3d;
         Render3DEngine.drawLine(start, end, 2.0F, colorInt);
      }

      if (this.mode.getValue() == Nuker.Mode.Fast && this.breakTimer.passedMs((long)(Integer)this.delay.getValue())) {
         this.breakBlock();
         this.breakTimer.reset();
      }

   }

   public Nuker.BlockData getNukerBlockPos() {
      int intRange = (int)(Math.floor((double)(Float)this.range.getValue()) + 1.0D);
      Iterable<class_2338> blocks_ = class_2338.method_25996(new class_2338(class_2338.method_49638(mc.field_1724.method_19538()).method_10084()), intRange, intRange, intRange);
      Iterator var3 = blocks_.iterator();

      class_2338 b;
      class_3965 result;
      do {
         while(true) {
            class_2680 state;
            do {
               do {
                  do {
                     do {
                        if (!var3.hasNext()) {
                           return null;
                        }

                        b = (class_2338)var3.next();
                        state = mc.field_1687.method_8320(b);
                     } while((Boolean)this.flatten.getValue() && (double)b.method_10264() < mc.field_1724.method_23318());
                  } while(!(PlayerUtility.squaredDistanceFromEyes(b.method_46558()) <= this.range.getPow2Value()));
               } while((Boolean)this.avoidLava.getValue() && this.checkLava(b));
            } while(!this.isAllowed(state.method_26204()));

            if ((Boolean)this.ignoreWalls.getValue()) {
               result = ExplosionUtility.rayCastBlock(new class_3959(InteractionUtility.getEyesPos(mc.field_1724), b.method_46558(), class_3960.field_17558, class_242.field_1348, mc.field_1724), b);
               break;
            }

            for(float x1 = 0.0F; x1 <= 1.0F; x1 += 0.2F) {
               for(float y1 = 0.0F; y1 <= 1.0F; y1 += 0.2F) {
                  for(float z1 = 0.0F; z1 <= 1.0F; z1 += 0.2F) {
                     class_243 p = new class_243((double)((float)b.method_10263() + x1), (double)((float)b.method_10264() + y1), (double)((float)b.method_10260() + z1));
                     class_3965 bhr = mc.field_1687.method_17742(new class_3959(InteractionUtility.getEyesPos(mc.field_1724), p, class_3960.field_17559, class_242.field_1348, mc.field_1724));
                     if (bhr != null && bhr.method_17783() == class_240.field_1332 && bhr.method_17777().equals(b)) {
                        return new Nuker.BlockData(b, p, bhr.method_17780());
                     }
                  }
               }
            }
         }
      } while(result == null);

      return new Nuker.BlockData(b, result.method_17784(), result.method_17780());
   }

   private boolean checkLava(class_2338 base) {
      class_2350[] var2 = class_2350.values();
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         class_2350 dir = var2[var4];
         if (mc.field_1687.method_8320(base.method_10093(dir)).method_26204() == class_2246.field_10164) {
            return true;
         }
      }

      return false;
   }

   private void handleBypass(class_2338 targetPos) {
      if (this.bypass.getValue() == Nuker.BypassMode.Vulcan) {
         class_243 playerEyes = InteractionUtility.getEyesPos(mc.field_1724);
         class_243 target = new class_243((double)targetPos.method_10263() + 0.5D, (double)targetPos.method_10264() + 0.5D, (double)targetPos.method_10260() + 0.5D);
         float[] rotation = InteractionUtility.calculateAngle(target);
         if ((Boolean)this.silentAim.getValue()) {
            mc.field_1724.field_3944.method_52787(new class_2846(class_2847.field_12968, targetPos, class_2350.field_11036));
            mc.field_1724.field_3944.method_52787(new class_2846(class_2847.field_12973, targetPos, class_2350.field_11036));
            mc.field_1724.method_36456(rotation[0]);
            mc.field_1724.method_36457(rotation[1]);
         }

         mc.field_1724.method_6104(class_1268.field_5808);
         if ((Boolean)this.silentAim.getValue()) {
            mc.field_1724.method_36456(mc.field_1724.field_5982);
            mc.field_1724.method_36457(mc.field_1724.field_6004);
         }

      }
   }

   private boolean isAllowed(class_2248 block) {
      boolean allowed = ((ItemSelectSetting)this.selectedBlocks.getValue()).getItemsById().contains(block.method_9539().replace("block.minecraft.", ""));
      boolean var10000;
      switch(((Nuker.BlockSelection)this.blocks.getValue()).ordinal()) {
      case 0:
         var10000 = block == this.targetBlockType;
         break;
      case 1:
         var10000 = block != class_2246.field_9987 && block != class_2246.field_10124 && block != class_2246.field_10543 && !(block instanceof class_2404);
         break;
      case 2:
      default:
         var10000 = !allowed && block != class_2246.field_9987 && block != class_2246.field_10124 && block != class_2246.field_10543 && !(block instanceof class_2404);
         break;
      case 3:
         var10000 = allowed;
      }

      return var10000;
   }

   private static enum Mode {
      Default,
      Fast,
      FastAF,
      FastSafe;

      // $FF: synthetic method
      private static Nuker.Mode[] $values() {
         return new Nuker.Mode[]{Default, Fast, FastAF, FastSafe};
      }
   }

   private static enum BlockSelection {
      Select,
      All,
      BlackList,
      WhiteList;

      // $FF: synthetic method
      private static Nuker.BlockSelection[] $values() {
         return new Nuker.BlockSelection[]{Select, All, BlackList, WhiteList};
      }
   }

   private static enum ColorMode {
      Custom,
      Sync;

      // $FF: synthetic method
      private static Nuker.ColorMode[] $values() {
         return new Nuker.ColorMode[]{Custom, Sync};
      }
   }

   private static enum BypassMode {
      None,
      Vulcan;

      // $FF: synthetic method
      private static Nuker.BypassMode[] $values() {
         return new Nuker.BypassMode[]{None, Vulcan};
      }
   }

   public class NukerThread extends Thread {
      public void run() {
         while(!Thread.currentThread().isInterrupted()) {
            try {
               if (Module.fullNullCheck()) {
                  Thread.yield();
               } else {
                  while(Managers.ASYNC.ticking.get()) {
                  }

                  if ((Nuker.this.targetBlockType != null || !((Nuker.BlockSelection)Nuker.this.blocks.getValue()).equals(Nuker.BlockSelection.Select)) && !Module.mc.field_1690.field_1886.method_1434() && Nuker.this.blockData == null) {
                     Nuker.this.blockData = Nuker.this.getNukerBlockPos();
                  }
               }
            } catch (Exception var2) {
            }
         }

      }
   }

   public static record BlockData(class_2338 bp, class_243 vec3d, class_2350 dir) {
      public BlockData(class_2338 bp, class_243 vec3d, class_2350 dir) {
         this.bp = bp;
         this.vec3d = vec3d;
         this.dir = dir;
      }

      public class_2338 bp() {
         return this.bp;
      }

      public class_243 vec3d() {
         return this.vec3d;
      }

      public class_2350 dir() {
         return this.dir;
      }
   }
}
