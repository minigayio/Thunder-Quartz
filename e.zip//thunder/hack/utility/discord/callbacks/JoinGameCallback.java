package thunder.hack.utility.discord.callbacks;

import com.sun.jna.Callback;

public interface JoinGameCallback extends Callback {
   void apply(String var1);
}
