package thunder.hack.core.manager;

import net.minecraft.class_310;

public interface IManager {
   class_310 mc = class_310.method_1551();
}
