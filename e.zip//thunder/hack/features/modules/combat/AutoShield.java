package thunder.hack.features.modules.combat;

import java.util.Iterator;
import java.util.List;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_238;
import net.minecraft.class_243;
import thunder.hack.events.impl.EventTick;
import thunder.hack.features.modules.Module;
import thunder.hack.setting.Setting;

public class AutoShield extends Module {
   private final Setting<Float> detectRange = new Setting("DetectRange", 5.0F, 1.0F, 8.0F);
   private boolean isBlocking = false;

   public AutoShield() {
      super("AutoShield", Module.Category.COMBAT);
   }

   @EventHandler
   public void onTick(EventTick event) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         if (!this.isHoldingShield()) {
            this.stopBlocking();
         } else {
            boolean shouldBlock = false;
            List<class_1657> nearbyPlayers = mc.field_1687.method_8390(class_1657.class, this.getBox((Float)this.detectRange.getValue()), this::isEnemy);
            Iterator var4 = nearbyPlayers.iterator();

            while(var4.hasNext()) {
               class_1657 player = (class_1657)var4.next();
               if (this.isLookingAtUs(player)) {
                  shouldBlock = true;
                  break;
               }
            }

            if (shouldBlock) {
               this.startBlocking();
            } else {
               this.stopBlocking();
            }

         }
      }
   }

   private boolean isLookingAtUs(class_1657 player) {
      class_243 eyes = player.method_5836(1.0F);
      class_243 lookVec = player.method_5828(1.0F).method_1029();
      class_243 ourBody = mc.field_1724.method_19538().method_1031(0.0D, (double)(mc.field_1724.method_17682() / 2.0F), 0.0D);
      class_243 toUs = ourBody.method_1020(eyes).method_1029();
      double dot = lookVec.method_1026(toUs);
      return dot > 0.906D;
   }

   private boolean isHoldingShield() {
      return mc.field_1724.method_6079().method_7909() == class_1802.field_8255 || mc.field_1724.method_6047().method_7909() == class_1802.field_8255;
   }

   private boolean isEnemy(class_1657 player) {
      return player != mc.field_1724 && player.method_5805() && !player.method_5767();
   }

   private void startBlocking() {
      if (!this.isBlocking) {
         mc.field_1690.field_1904.method_23481(true);
         this.isBlocking = true;
      }

   }

   private void stopBlocking() {
      if (this.isBlocking) {
         mc.field_1690.field_1904.method_23481(false);
         this.isBlocking = false;
      }

   }

   private class_238 getBox(float range) {
      return new class_238(mc.field_1724.method_23317() - (double)range, mc.field_1724.method_23318() - 2.0D, mc.field_1724.method_23321() - (double)range, mc.field_1724.method_23317() + (double)range, mc.field_1724.method_23318() + 2.0D, mc.field_1724.method_23321() + (double)range);
   }

   public void onDisable() {
      this.stopBlocking();
   }
}
