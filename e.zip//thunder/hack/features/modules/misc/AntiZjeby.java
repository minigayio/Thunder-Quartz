package thunder.hack.features.modules.misc;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_3965;
import thunder.hack.events.impl.EventTick;
import thunder.hack.features.modules.Module;
import thunder.hack.utility.player.InventoryUtility;
import thunder.hack.utility.player.SearchInvResult;

public class AntiZjeby extends Module {
   private boolean retrieveFlag = false;

   public AntiZjeby() {
      super("AntiZjeby", Module.Category.MISC);
   }

   @EventHandler
   public void onTick(EventTick event) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         if (mc.field_1724.method_5809() && !this.retrieveFlag) {
            SearchInvResult waterResult = InventoryUtility.findItemInHotBar(class_1802.field_8705);
            if (waterResult.found()) {
               class_2338 playerPos = mc.field_1724.method_24515();
               this.doWaterDrop(waterResult, playerPos);
            }
         } else if (this.retrieveFlag) {
            this.retrieveWater();
         }

      }
   }

   private void doWaterDrop(SearchInvResult waterResult, class_2338 playerPos) {
      if (mc.field_1687.method_8320(playerPos.method_10074()).method_26215() && mc.field_1687.method_8320(playerPos.method_10074().method_10074()).method_26212(mc.field_1687, playerPos.method_10074().method_10074())) {
         InventoryUtility.saveSlot();
         waterResult.switchTo();
         class_2338 posUnder = playerPos.method_10074();
         class_3965 blockHitResult = new class_3965(mc.field_1724.method_19538().method_1031(0.0D, -1.0D, 0.0D), class_2350.field_11036, posUnder, false);
         mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, blockHitResult);
         mc.field_1724.method_6104(class_1268.field_5808);
         this.retrieveFlag = true;
      }
   }

   private void retrieveWater() {
      SearchInvResult bucketResult = InventoryUtility.findItemInHotBar(class_1802.field_8550);
      if (bucketResult.found()) {
         bucketResult.switchTo();
         mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);
         mc.field_1724.method_6104(class_1268.field_5808);
         InventoryUtility.returnSlot();
         this.retrieveFlag = false;
      }

   }
}
