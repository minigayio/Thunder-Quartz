package thunder.hack.core.manager.client;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.compress.utils.Lists;
import thunder.hack.core.manager.IManager;
import thunder.hack.features.modules.client.ClientSettings;
import thunder.hack.utility.Timer;

public class TelemetryManager implements IManager {
   private final Timer pingTimer = new Timer();
   private List<String> onlinePlayers = new ArrayList();
   private int totalPlayers = 0;

   public void onUpdate() {
      if (this.pingTimer.every(9000L)) {
         this.fetchData();
      }

   }

   public void fetchData() {
      if ((Boolean)ClientSettings.telemetry.getValue()) {
         this.pingServer(mc.method_1548().method_1676());
      }

      this.onlinePlayers = getOnlinePlayersList();
      this.totalPlayers = getTotalPlayers();
   }

   public void pingServer(String name) {
      HttpRequest req = HttpRequest.newBuilder(URI.create("https://api.thunderhack.net/v1/users/online?name=" + name)).POST(BodyPublishers.noBody()).build();

      try {
         HttpClient client = HttpClient.newHttpClient();
         client.send(req, BodyHandlers.ofString());
      } catch (Exception var4) {
      }

   }

   public static int getTotalPlayers() {
      HttpRequest request = HttpRequest.newBuilder(URI.create("https://plagai.org/apimimi/api?viev")).GET().build();

      try {
         HttpClient client = HttpClient.newHttpClient();
         HttpResponse<String> response = client.send(request, BodyHandlers.ofString());
         JsonObject jsonResponse = JsonParser.parseString((String)response.body()).getAsJsonObject();
         if (jsonResponse.has("total_players")) {
            return jsonResponse.get("total_players").getAsInt();
         }
      } catch (Exception var4) {
      }

      return 0;
   }

   public static List<String> getOnlinePlayersList() {
      HttpRequest request = HttpRequest.newBuilder(URI.create("https://plagai.org/apimimi/api?viev")).GET().build();
      ArrayList names = new ArrayList();

      try {
         HttpClient client = HttpClient.newHttpClient();
         HttpResponse<String> response = client.send(request, BodyHandlers.ofString());
         JsonObject jsonResponse = JsonParser.parseString((String)response.body()).getAsJsonObject();
         if (jsonResponse.has("users")) {
            jsonResponse.getAsJsonArray("users").forEach((e) -> {
               JsonObject user = e.getAsJsonObject();
               if (user.has("nick")) {
                  names.add(user.get("nick").getAsString());
               }

            });
         }
      } catch (Exception var5) {
         var5.printStackTrace();
      }

      return names;
   }

   public int getTotalPlayersCount() {
      return this.totalPlayers;
   }

   public List<String> getOnlinePlayers() {
      return Lists.newArrayList(this.onlinePlayers.iterator());
   }
}
