package thunder.hack.features.modules.misc;

import thunder.hack.features.modules.Module;

public class ExtraTab extends Module {
   public ExtraTab() {
      super("ExtraTab", Module.Category.MISC);
   }
}
