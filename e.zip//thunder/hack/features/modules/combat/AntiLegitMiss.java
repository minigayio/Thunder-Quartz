package thunder.hack.features.modules.combat;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_3966;
import thunder.hack.events.impl.EventAttack;
import thunder.hack.events.impl.EventHandleBlockBreaking;
import thunder.hack.features.modules.Module;

public class AntiLegitMiss extends Module {
   public AntiLegitMiss() {
      super("AntiLegitMiss", Module.Category.COMBAT);
   }

   @EventHandler
   public void onAttack(EventAttack e) {
      if (!(mc.field_1765 instanceof class_3966) && e.isPre()) {
         e.cancel();
      }

   }

   @EventHandler
   public void onBlockBreaking(EventHandleBlockBreaking e) {
      if (!(mc.field_1765 instanceof class_3966)) {
         e.cancel();
      }

   }
}
