package thunder.hack.features.modules.misc;

import java.util.Random;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2848;
import net.minecraft.class_2848.class_2849;
import thunder.hack.events.impl.EventTick;
import thunder.hack.features.modules.Module;
import thunder.hack.setting.Setting;

public class Disabler extends Module {
   private final Random random = new Random();
   public final Setting<Boolean> vulcanLimit = new Setting("VulcanLimit", false);

   public Disabler() {
      super("Disabler", Module.Category.MISC);
   }

   @EventHandler
   public void onTick(EventTick e) {
      if ((Boolean)this.vulcanLimit.getValue() && mc.field_1724 != null && mc.method_1562() != null) {
         if (!mc.field_1724.method_5799() && !mc.field_1724.method_5771() && !mc.field_1724.method_29504() && !mc.field_1724.method_6101() && !mc.field_1724.method_31549().field_7479) {
            if (this.isTellyBridging() && mc.field_1724.field_6012 % 9 == 0 && this.random.nextFloat() <= 0.7F) {
               mc.method_1562().method_52787(new class_2848(mc.field_1724, class_2849.field_12984));
            }

            if (mc.field_1724.method_24828() && this.isTowering() && this.random.nextFloat() <= 0.2F) {
               mc.method_1562().method_52787(new class_2848(mc.field_1724, class_2849.field_12984));
            }

            mc.method_1562().method_52787(new class_2848(mc.field_1724, class_2849.field_12981));
            mc.method_1562().method_52787(new class_2848(mc.field_1724, class_2849.field_12985));
            if (mc.field_1724.field_6012 % 9 == 0 && mc.field_1724.method_24828() && !this.isTellyBridging() && !this.isTowering()) {
               mc.method_1562().method_52787(new class_2848(mc.field_1724, class_2849.field_12984));
            }

         }
      }
   }

   private boolean isTellyBridging() {
      return mc.field_1724.method_18798().method_1027() > 0.1D && mc.field_1690.field_1832.method_1434();
   }

   private boolean isTowering() {
      return mc.field_1690.field_1903.method_1434() && mc.field_1724.method_24828();
   }
}
