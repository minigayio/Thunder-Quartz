package thunder.hack.events.impl;

import net.minecraft.class_2558;
import net.minecraft.class_2558.class_2559;

public class ClientClickEvent extends class_2558 {
   public ClientClickEvent(class_2559 action, String value) {
      super(action, value);
   }
}
