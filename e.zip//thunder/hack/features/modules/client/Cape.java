package thunder.hack.features.modules.client;

import net.minecraft.class_1657;
import net.minecraft.class_2960;
import net.minecraft.class_742;
import thunder.hack.core.Managers;
import thunder.hack.features.modules.Module;
import thunder.hack.setting.Setting;

public final class Cape extends Module {
   public final Setting<Cape.CapeType> capeType;
   public final Setting<Boolean> elytraTexture;
   public final Setting<Boolean> onlySelf;
   public final Setting<Boolean> friends;

   public Cape() {
      super("Cape", Module.Category.CLIENT);
      this.capeType = new Setting("Cape", Cape.CapeType.Star);
      this.elytraTexture = new Setting("ElytraTexture", true);
      this.onlySelf = new Setting("OnlySelf", true);
      this.friends = new Setting("Friends", true, (v) -> {
         return (Boolean)this.onlySelf.getValue();
      });
   }

   public class_2960 getCapeTexture(class_742 player) {
      if (this.isEnabled() && this.capeType.getValue() != Cape.CapeType.OFF) {
         return !(Boolean)this.onlySelf.getValue() || player == mc.field_1724 || (Boolean)this.friends.getValue() && Managers.FRIEND.isFriend((class_1657)player) ? class_2960.method_60655("thunderhack", "textures/capes/" + ((Cape.CapeType)this.capeType.getValue()).getFileName()) : null;
      } else {
         return null;
      }
   }

   public static enum CapeType {
      Star("starcape.png"),
      Tester("tester.png"),
      FBGroup("fbgroup.png"),
      Dev("dev.png"),
      Exploitcore("test.png"),
      BKGroup("bkgroup.png"),
      OFF("none");

      private final String fileName;

      private CapeType(String fileName) {
         this.fileName = fileName;
      }

      public String getFileName() {
         return this.fileName;
      }

      // $FF: synthetic method
      private static Cape.CapeType[] $values() {
         return new Cape.CapeType[]{Star, Tester, FBGroup, Dev, Exploitcore, BKGroup, OFF};
      }
   }
}
