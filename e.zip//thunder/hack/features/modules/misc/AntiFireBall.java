package thunder.hack.features.modules.misc;

import java.util.Iterator;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1674;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import thunder.hack.core.Managers;
import thunder.hack.features.modules.Module;
import thunder.hack.gui.notification.Notification;
import thunder.hack.setting.Setting;
import thunder.hack.utility.Timer;

public class AntiFireBall extends Module {
   public final Setting<Float> range = new Setting("Range", 5.0F, 1.0F, 10.0F);
   public final Setting<Boolean> warning = new Setting("Warning", true);
   public final Setting<Float> warningRange = new Setting("WarningRange", 50.0F, 1.0F, 100.0F);
   public final Setting<Boolean> rotation = new Setting("Rotation", true);
   public final Setting<Boolean> notify = new Setting("Notify", true);
   public final Setting<Boolean> song = new Setting("Song", false);
   public final Setting<Boolean> render = new Setting("Render", false);
   private final Timer notifyTimer = new Timer();
   private final Timer attackTimer = new Timer();
   private final Timer soundTimer = new Timer();

   public AntiFireBall() {
      super("AntiFireBall", Module.Category.MISC);
   }

   public void onUpdate() {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         Iterator var1 = mc.field_1687.method_18112().iterator();

         while(var1.hasNext()) {
            class_1297 entity = (class_1297)var1.next();
            if (entity instanceof class_1674) {
               class_1674 fireball = (class_1674)entity;
               float distanceToFireball = mc.field_1724.method_5739(entity);
               if (distanceToFireball <= (Float)this.warningRange.getValue() && (Boolean)this.warning.getValue()) {
                  this.sendFireballWarning(distanceToFireball);
               }

               if ((Boolean)this.notify.getValue() && distanceToFireball <= (Float)this.warningRange.getValue() && this.notifyTimer.passedMs(100L)) {
                  this.notifyFireball(fireball, distanceToFireball);
                  this.notifyTimer.reset();
               }

               if ((Boolean)this.song.getValue() && this.soundTimer.passedMs(50L)) {
                  mc.field_1687.method_8396(mc.field_1724, mc.field_1724.method_24515(), class_3417.field_14627, class_3419.field_15245, 1.0F, 1.0F);
                  this.soundTimer.reset();
               }

               if ((Boolean)this.render.getValue()) {
                  fireball.method_5834(true);
               }

               if (distanceToFireball <= (Float)this.range.getValue()) {
                  if ((Boolean)this.rotation.getValue()) {
                     this.rotateTowardsEntity(fireball);
                  }

                  this.reflectFireball(fireball);
               }
            }
         }

      }
   }

   private void reflectFireball(class_1674 fireball) {
      if (this.attackTimer.passedMs(40L)) {
         mc.field_1761.method_2918(mc.field_1724, fireball);
         mc.field_1724.method_6104(class_1268.field_5808);
         this.attackTimer.reset();
      }
   }

   private void sendFireballWarning(float distance) {
      String var10000 = String.valueOf(class_124.field_1061);
      String message = var10000 + "Fireball detected " + String.format("%.1f", distance) + " blocks away!";
      mc.field_1724.method_7353(class_2561.method_43470(message), false);
   }

   private void notifyFireball(class_1297 fireball, float distance) {
      String var10000 = String.valueOf(class_124.field_1061);
      String message = var10000 + "Fireball detected " + String.format("%.1f", distance) + " blocks away!";
      mc.field_1724.method_7353(class_2561.method_43470(message), false);
      Managers.NOTIFICATION.publicity("AntiFireBall", message, 2, Notification.Type.ERROR);
   }

   private void rotateTowardsEntity(class_1297 entity) {
      class_243 direction = entity.method_19538().method_1020(mc.field_1724.method_19538());
      double yaw = Math.atan2(direction.field_1350, direction.field_1352) * 57.29577951308232D - 90.0D;
      double pitch = -Math.atan2(direction.field_1351, direction.method_1033()) * 57.29577951308232D;
      mc.field_1724.method_36456((float)yaw);
      mc.field_1724.method_36457((float)pitch);
   }
}
