package thunder.hack.features.modules.client;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import thunder.hack.events.impl.EventTick;
import thunder.hack.features.modules.Module;
import thunder.hack.setting.Setting;
import thunder.hack.utility.Timer;
import thunder.hack.utility.player.InteractionUtility;
import thunder.hack.utility.player.InventoryUtility;

public class WSPAM extends Module {
   private final Setting<WSPAM.Mode> mode;
   private final Setting<Integer> placeDelay;
   private final Setting<Integer> retrieveDelay;
   private final Setting<Boolean> autoSwitch;
   private final Setting<Boolean> onlyFalling;
   private final Setting<Float> fallDistance;
   private final Setting<Boolean> autoRetrieve;
   private final Timer actionTimer;
   private boolean itemPlaced;
   private boolean shouldRetrieve;
   private int ticksAfterPlace;
   private int prevSlot;
   private class_2338 placedPos;

   public WSPAM() {
      super("WSPAM", Module.Category.CLIENT);
      this.mode = new Setting("Mode", WSPAM.Mode.Water);
      this.placeDelay = new Setting("PlaceDelay", 2, 1, 10);
      this.retrieveDelay = new Setting("RetrieveDelay", 1, 1, 10);
      this.autoSwitch = new Setting("AutoSwitch", true);
      this.onlyFalling = new Setting("OnlyFalling", false);
      this.fallDistance = new Setting("FallDistance", 3.0F, 1.0F, 10.0F, (v) -> {
         return (Boolean)this.onlyFalling.getValue();
      });
      this.autoRetrieve = new Setting("AutoRetrieve", true, (v) -> {
         return this.mode.getValue() != WSPAM.Mode.Ladder;
      });
      this.actionTimer = new Timer();
      this.itemPlaced = false;
      this.shouldRetrieve = false;
      this.ticksAfterPlace = 0;
      this.prevSlot = -1;
      this.placedPos = null;
   }

   public void onEnable() {
      this.itemPlaced = false;
      this.shouldRetrieve = false;
      this.ticksAfterPlace = 0;
      this.prevSlot = -1;
      this.placedPos = null;
      this.actionTimer.reset();
   }

   public void onDisable() {
      if (this.prevSlot != -1) {
         InventoryUtility.switchTo(this.prevSlot, true);
         this.prevSlot = -1;
      }

   }

   @EventHandler
   public void onTick(EventTick event) {
      if (!fullNullCheck()) {
         if (!(Boolean)this.onlyFalling.getValue() || !(mc.field_1724.field_6017 < (Float)this.fallDistance.getValue())) {
            switch(((WSPAM.Mode)this.mode.getValue()).ordinal()) {
            case 0:
               this.handleWaterSpam();
               break;
            case 1:
               this.handleCobwebSpam();
               break;
            case 2:
               this.handleLadderSpam();
               break;
            case 3:
               this.handleBothSpam();
            }

         }
      }
   }

   private void handleWaterSpam() {
      boolean hasWaterBucket = mc.field_1724.method_6047().method_7909() == class_1802.field_8705 || mc.field_1724.method_6079().method_7909() == class_1802.field_8705;
      boolean hasBucket = mc.field_1724.method_6047().method_7909() == class_1802.field_8550 || mc.field_1724.method_6079().method_7909() == class_1802.field_8550;
      if (!hasWaterBucket && !hasBucket && (Boolean)this.autoSwitch.getValue()) {
         this.switchToItem(class_1802.field_8705, class_1802.field_8550);
      } else if (!mc.field_1690.field_1904.method_1434()) {
         if (this.itemPlaced && this.shouldRetrieve && (Boolean)this.autoRetrieve.getValue()) {
            this.retrieveWater();
         }

      } else {
         if (hasWaterBucket && !this.itemPlaced) {
            if (this.actionTimer.passedMs((long)((Integer)this.placeDelay.getValue() * 50))) {
               this.placeWater();
            }
         } else if (hasBucket && this.itemPlaced) {
            ++this.ticksAfterPlace;
            if (this.ticksAfterPlace >= (Integer)this.retrieveDelay.getValue()) {
               this.shouldRetrieve = true;
            }
         }

         if (this.itemPlaced && this.shouldRetrieve && hasBucket && (Boolean)this.autoRetrieve.getValue()) {
            this.retrieveWater();
         }

      }
   }

   private void handleCobwebSpam() {
      boolean hasCobweb = mc.field_1724.method_6047().method_7909() == class_1802.field_8786 || mc.field_1724.method_6079().method_7909() == class_1802.field_8786;
      if (!hasCobweb && (Boolean)this.autoSwitch.getValue()) {
         this.switchToItem(class_1802.field_8786);
      } else if (!mc.field_1690.field_1904.method_1434()) {
         if (this.itemPlaced && this.shouldRetrieve && (Boolean)this.autoRetrieve.getValue()) {
            this.retrieveCobweb();
         }

      } else {
         if (hasCobweb && !this.itemPlaced) {
            if (this.actionTimer.passedMs((long)((Integer)this.placeDelay.getValue() * 50))) {
               this.placeCobweb();
            }
         } else if (this.itemPlaced) {
            ++this.ticksAfterPlace;
            if (this.ticksAfterPlace >= (Integer)this.retrieveDelay.getValue()) {
               this.shouldRetrieve = true;
            }
         }

         if (this.itemPlaced && this.shouldRetrieve && (Boolean)this.autoRetrieve.getValue()) {
            this.retrieveCobweb();
         }

      }
   }

   private void handleLadderSpam() {
      boolean hasLadder = mc.field_1724.method_6047().method_7909() == class_1802.field_8121 || mc.field_1724.method_6079().method_7909() == class_1802.field_8121;
      if (!hasLadder && (Boolean)this.autoSwitch.getValue()) {
         this.switchToItem(class_1802.field_8121);
      } else if (mc.field_1690.field_1904.method_1434()) {
         if (hasLadder && !this.itemPlaced && this.actionTimer.passedMs((long)((Integer)this.placeDelay.getValue() * 50))) {
            this.placeLadder();
         }

      }
   }

   private void handleBothSpam() {
      boolean hasWaterBucket = mc.field_1724.method_6047().method_7909() == class_1802.field_8705 || mc.field_1724.method_6079().method_7909() == class_1802.field_8705;
      boolean hasBucket = mc.field_1724.method_6047().method_7909() == class_1802.field_8550 || mc.field_1724.method_6079().method_7909() == class_1802.field_8550;
      boolean hasCobweb = mc.field_1724.method_6047().method_7909() == class_1802.field_8786 || mc.field_1724.method_6079().method_7909() == class_1802.field_8786;
      if (!hasWaterBucket && !hasBucket && !hasCobweb && (Boolean)this.autoSwitch.getValue()) {
         this.switchToItem(class_1802.field_8705, class_1802.field_8550, class_1802.field_8786);
      } else if (!mc.field_1690.field_1904.method_1434()) {
         if (this.itemPlaced && this.shouldRetrieve && (Boolean)this.autoRetrieve.getValue()) {
            if (mc.field_1687.method_8320(this.placedPos).method_51176()) {
               this.retrieveWater();
            } else {
               this.retrieveCobweb();
            }
         }

      } else {
         boolean needsWater = this.isOnGround() && mc.field_1724.field_6017 > 2.0F;
         boolean needsCobweb = !needsWater && (this.isMovingFast() || this.isInCombat());
         if (!this.itemPlaced) {
            if (this.actionTimer.passedMs((long)((Integer)this.placeDelay.getValue() * 50))) {
               if (needsWater && (hasWaterBucket || hasBucket)) {
                  if (hasWaterBucket) {
                     this.placeWater();
                  }
               } else if (needsCobweb && hasCobweb) {
                  this.placeCobweb();
               } else if (hasWaterBucket) {
                  this.placeWater();
               } else if (hasCobweb) {
                  this.placeCobweb();
               }
            }
         } else {
            ++this.ticksAfterPlace;
            if (this.ticksAfterPlace >= (Integer)this.retrieveDelay.getValue()) {
               this.shouldRetrieve = true;
            }

            if (this.shouldRetrieve && (Boolean)this.autoRetrieve.getValue()) {
               if (mc.field_1687.method_8320(this.placedPos).method_51176() && hasBucket) {
                  this.retrieveWater();
               } else if (!mc.field_1687.method_22347(this.placedPos)) {
                  this.retrieveCobweb();
               }
            }
         }

      }
   }

   private boolean isOnGround() {
      return mc.field_1687.method_8320(class_2338.method_49638(mc.field_1724.method_19538()).method_10074()).method_51367() || mc.field_1687.method_8320(class_2338.method_49638(mc.field_1724.method_19538()).method_10074().method_10074()).method_51367();
   }

   private boolean isMovingFast() {
      return mc.field_1724.method_18798().method_37267() > 0.2D;
   }

   private boolean isInCombat() {
      return mc.field_1724.method_6065() != null || mc.field_1724.field_6235 > 0;
   }

   private void switchToItem(class_1792... items) {
      class_1792[] var2 = items;
      int var3 = items.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         class_1792 item = var2[var4];
         int itemSlot = InventoryUtility.findItemInHotBar(item).slot();
         if (itemSlot != -1) {
            if (this.prevSlot == -1) {
               this.prevSlot = mc.field_1724.method_31548().field_7545;
            }

            InventoryUtility.switchTo(itemSlot, true);
            return;
         }
      }

   }

   private void placeWater() {
      if (mc.field_1724 != null) {
         class_2338 playerPos = class_2338.method_49638(mc.field_1724.method_19538());
         class_2338 targetPos = null;
         if (mc.field_1687.method_8320(playerPos.method_10074()).method_51367()) {
            targetPos = playerPos;
         } else if (mc.field_1687.method_8320(playerPos.method_10074().method_10074()).method_51367()) {
            targetPos = playerPos.method_10074();
         }

         if (targetPos != null && mc.field_1687.method_22347(targetPos)) {
            mc.field_1724.method_36457(90.0F);
            class_1268 hand = mc.field_1724.method_6047().method_7909() == class_1802.field_8705 ? class_1268.field_5808 : class_1268.field_5810;
            mc.field_1761.method_2919(mc.field_1724, hand);
            mc.field_1724.method_6104(hand);
            this.itemPlaced = true;
            this.placedPos = targetPos;
            this.ticksAfterPlace = 0;
            this.actionTimer.reset();
         }

      }
   }

   private void placeCobweb() {
      if (mc.field_1724 != null) {
         class_2338 playerPos = class_2338.method_49638(mc.field_1724.method_19538());
         class_2338 targetPos = null;
         if (mc.field_1687.method_22347(playerPos)) {
            targetPos = playerPos;
         } else if (mc.field_1687.method_22347(playerPos.method_10074())) {
            targetPos = playerPos.method_10074();
         }

         if (targetPos != null) {
            int cobwebSlot = InventoryUtility.findItemInHotBar(class_1802.field_8786).slot();
            if (cobwebSlot != -1) {
               InteractionUtility.placeBlock(targetPos, InteractionUtility.Rotate.None, InteractionUtility.Interact.Vanilla, InteractionUtility.PlaceMode.Normal, cobwebSlot, false, true);
               this.itemPlaced = true;
               this.placedPos = targetPos;
               this.ticksAfterPlace = 0;
               this.actionTimer.reset();
            }
         }

      }
   }

   private void placeLadder() {
      if (mc.field_1724 != null) {
         class_2338 playerPos = class_2338.method_49638(mc.field_1724.method_19538());
         class_2338 targetPos = playerPos;
         class_2350[] var3 = class_2350.values();
         int var4 = var3.length;

         for(int var5 = 0; var5 < var4; ++var5) {
            class_2350 direction = var3[var5];
            if (direction != class_2350.field_11036 && direction != class_2350.field_11033) {
               class_2338 wallPos = targetPos.method_10093(direction);
               if (mc.field_1687.method_8320(wallPos).method_51367() && mc.field_1687.method_22347(targetPos)) {
                  int ladderSlot = InventoryUtility.findItemInHotBar(class_1802.field_8121).slot();
                  if (ladderSlot != -1) {
                     InteractionUtility.placeBlock(targetPos, InteractionUtility.Rotate.None, InteractionUtility.Interact.Vanilla, InteractionUtility.PlaceMode.Normal, ladderSlot, false, true);
                     this.itemPlaced = true;
                     this.placedPos = targetPos;
                     this.ticksAfterPlace = 0;
                     this.actionTimer.reset();
                     return;
                  }
               }
            }
         }

      }
   }

   private void retrieveWater() {
      if (mc.field_1724 != null && this.placedPos != null) {
         if (mc.field_1687.method_8320(this.placedPos).method_51176()) {
            mc.field_1724.method_36457(90.0F);
            class_1268 hand = mc.field_1724.method_6047().method_7909() == class_1802.field_8550 ? class_1268.field_5808 : class_1268.field_5810;
            mc.field_1761.method_2919(mc.field_1724, hand);
            mc.field_1724.method_6104(hand);
         }

         this.resetState();
      }
   }

   private void retrieveCobweb() {
      if (mc.field_1724 != null && this.placedPos != null) {
         if (!mc.field_1687.method_22347(this.placedPos)) {
            mc.field_1761.method_2910(this.placedPos, class_2350.field_11036);
            mc.field_1724.method_6104(class_1268.field_5808);
         }

         this.resetState();
      }
   }

   private void resetState() {
      this.itemPlaced = false;
      this.shouldRetrieve = false;
      this.ticksAfterPlace = 0;
      this.placedPos = null;
      this.actionTimer.reset();
      if (this.prevSlot != -1) {
         InventoryUtility.switchTo(this.prevSlot, true);
         this.prevSlot = -1;
      }

   }

   public String getDisplayInfo() {
      String modeStr = ((WSPAM.Mode)this.mode.getValue()).toString();
      if (this.itemPlaced) {
         return modeStr + " Placed";
      } else {
         return mc.field_1690.field_1904.method_1434() ? modeStr + " Ready" : modeStr + " Waiting";
      }
   }

   private static enum Mode {
      Water,
      Cobweb,
      Ladder,
      Both;

      // $FF: synthetic method
      private static WSPAM.Mode[] $values() {
         return new WSPAM.Mode[]{Water, Cobweb, Ladder, Both};
      }
   }
}
