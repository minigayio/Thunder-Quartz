package thunder.hack.features.modules.movement;

import thunder.hack.features.modules.Module;

public class SafeWalk extends Module {
   public SafeWalk() {
      super("SafeWalk", Module.Category.MOVEMENT);
   }
}
