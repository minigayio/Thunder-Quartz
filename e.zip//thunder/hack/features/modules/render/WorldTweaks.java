package thunder.hack.features.modules.render;

import java.awt.Color;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2761;
import thunder.hack.events.impl.PacketEvent;
import thunder.hack.features.modules.Module;
import thunder.hack.setting.Setting;
import thunder.hack.setting.impl.BooleanSettingGroup;
import thunder.hack.setting.impl.ColorSetting;

public class WorldTweaks extends Module {
   public static final Setting<BooleanSettingGroup> fogModify = new Setting("FogModify", new BooleanSettingGroup(true));
   public static final Setting<Integer> fogStart;
   public static final Setting<Integer> fogEnd;
   public static final Setting<ColorSetting> fogColor;
   public final Setting<Boolean> ctime = new Setting("ChangeTime", false);
   public final Setting<Integer> ctimeVal = new Setting("Time", 21, 0, 100);
   long oldTime;

   public WorldTweaks() {
      super("TimeChanger", Module.Category.RENDER);
   }

   public void onEnable() {
      this.oldTime = mc.field_1687.method_8510();
   }

   public void onDisable() {
      mc.field_1687.method_8435(this.oldTime);
   }

   @EventHandler
   private void onPacketReceive(PacketEvent.Receive event) {
      if (event.getPacket() instanceof class_2761 && (Boolean)this.ctime.getValue()) {
         this.oldTime = ((class_2761)event.getPacket()).method_11871();
         event.cancel();
      }

   }

   public void onUpdate() {
      if ((Boolean)this.ctime.getValue()) {
         long newTime = (long)((double)(Integer)this.ctimeVal.getValue() / 100.0D * 24000.0D);
         mc.field_1687.method_8435(newTime);
      }

   }

   static {
      fogStart = (new Setting("FogStart", 0, 0, 256)).addToGroup(fogModify);
      fogEnd = (new Setting("FogEnd", 64, 10, 256)).addToGroup(fogModify);
      fogColor = (new Setting("FogColor", new ColorSetting(new Color(11075839)))).addToGroup(fogModify);
   }
}
