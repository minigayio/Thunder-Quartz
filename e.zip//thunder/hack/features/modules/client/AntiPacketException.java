package thunder.hack.features.modules.client;

import thunder.hack.features.modules.Module;

public class AntiPacketException extends Module {
   public AntiPacketException() {
      super("NoPacketException", Module.Category.CLIENT);
   }
}
