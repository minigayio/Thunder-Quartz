package thunder.hack.features.modules.misc;

import java.util.Iterator;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1531;
import net.minecraft.class_1688;
import net.minecraft.class_1694;
import net.minecraft.class_1701;
import net.minecraft.class_1297.class_5529;
import thunder.hack.core.Managers;
import thunder.hack.events.impl.EventSync;
import thunder.hack.features.modules.Module;
import thunder.hack.setting.Setting;

public class AntiTrap extends Module {
   private final Setting<Boolean> tntMinecarts = new Setting("TNTMinecarts", true);
   private final Setting<Boolean> chestMinecarts = new Setting("ChestMinecarts", true);
   private final Setting<Boolean> armorStands = new Setting("ArmorStands", true);
   private final Setting<Boolean> allMinecarts = new Setting("AllMinecarts", false);

   public AntiTrap() {
      super("AntiTrap", Module.Category.MISC);
   }

   @EventHandler
   public void onSync(EventSync e) {
      Iterator var2 = Managers.ASYNC.getAsyncEntities().iterator();

      while(true) {
         while(var2.hasNext()) {
            class_1297 entity = (class_1297)var2.next();
            if (entity instanceof class_1701 && (Boolean)this.tntMinecarts.getValue()) {
               mc.field_1687.method_2945(entity.method_5628(), class_5529.field_26998);
            } else if (entity instanceof class_1694 && (Boolean)this.chestMinecarts.getValue()) {
               mc.field_1687.method_2945(entity.method_5628(), class_5529.field_26998);
            } else if (entity instanceof class_1531 && (Boolean)this.armorStands.getValue()) {
               mc.field_1687.method_2945(entity.method_5628(), class_5529.field_26998);
            } else if (entity instanceof class_1688 && (Boolean)this.allMinecarts.getValue()) {
               mc.field_1687.method_2945(entity.method_5628(), class_5529.field_26998);
            }
         }

         return;
      }
   }
}
