package thunder.hack.features.modules.player;

import thunder.hack.features.modules.Module;

public class AntiBallPlace extends Module {
   public AntiBallPlace() {
      super("AntiBallPlace", Module.Category.PLAYER);
   }
}
