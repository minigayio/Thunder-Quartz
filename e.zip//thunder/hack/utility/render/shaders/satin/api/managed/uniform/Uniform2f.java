package thunder.hack.utility.render.shaders.satin.api.managed.uniform;

import org.joml.Vector2f;

public interface Uniform2f {
   void set(float var1, float var2);

   void set(Vector2f var1);
}
